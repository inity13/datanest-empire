# ---------------------------------------------------------------------------
# Outputs — Azure Data Factory Infrastructure
# Datanest Digital (https://datanest.dev)
# ---------------------------------------------------------------------------

output "data_factory_id" {
  description = "Resource ID of the Azure Data Factory"
  value       = azurerm_data_factory.main.id
}

output "data_factory_name" {
  description = "Name of the Azure Data Factory"
  value       = azurerm_data_factory.main.name
}

output "data_factory_identity_principal_id" {
  description = "Principal ID of the ADF managed identity (use for RBAC and Key Vault access)"
  value       = azurerm_data_factory.main.identity[0].principal_id
}

output "data_factory_identity_tenant_id" {
  description = "Tenant ID of the ADF managed identity"
  value       = azurerm_data_factory.main.identity[0].tenant_id
}

output "self_hosted_ir_auth_key_1" {
  description = "Primary authentication key for the self-hosted integration runtime"
  value       = var.enable_self_hosted_ir ? azurerm_data_factory_integration_runtime_self_hosted.shir[0].primary_authorization_key : null
  sensitive   = true
}

output "self_hosted_ir_auth_key_2" {
  description = "Secondary authentication key for the self-hosted integration runtime"
  value       = var.enable_self_hosted_ir ? azurerm_data_factory_integration_runtime_self_hosted.shir[0].secondary_authorization_key : null
  sensitive   = true
}

output "private_endpoint_ip" {
  description = "Private IP address of the ADF private endpoint"
  value       = var.enable_private_endpoints ? azurerm_private_endpoint.adf[0].private_service_connection[0].private_ip_address : null
}

output "data_factory_portal_url" {
  description = "URL to open ADF Studio in the Azure portal"
  value       = "https://adf.azure.com/en/home?factory=${urlencode(azurerm_data_factory.main.id)}"
}
