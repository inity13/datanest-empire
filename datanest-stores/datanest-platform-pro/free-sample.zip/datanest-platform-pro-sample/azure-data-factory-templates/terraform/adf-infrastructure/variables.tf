# ---------------------------------------------------------------------------
# Variables — Azure Data Factory Infrastructure
# Datanest Digital (https://datanest.dev)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------

variable "resource_group_name" {
  description = "Name of the resource group where ADF will be deployed"
  type        = string
}

variable "data_factory_name" {
  description = "Name of the Azure Data Factory instance"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev, staging, production)"
  type        = string
  default     = "dev"
  validation {
    condition     = contains(["dev", "staging", "production"], var.environment)
    error_message = "Environment must be one of: dev, staging, production."
  }
}

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}

# ---------------------------------------------------------------------------
# Networking
# ---------------------------------------------------------------------------

variable "enable_managed_vnet" {
  description = "Enable ADF managed virtual network"
  type        = bool
  default     = true
}

variable "enable_public_network" {
  description = "Enable public network access to ADF"
  type        = bool
  default     = false
}

variable "enable_private_endpoints" {
  description = "Create private endpoint for ADF"
  type        = bool
  default     = false
}

variable "virtual_network_name" {
  description = "Virtual network name for private endpoints"
  type        = string
  default     = ""
}

variable "private_endpoint_subnet_name" {
  description = "Subnet name for private endpoints"
  type        = string
  default     = ""
}

variable "network_resource_group_name" {
  description = "Resource group containing the virtual network"
  type        = string
  default     = ""
}

# ---------------------------------------------------------------------------
# Integration Runtimes
# ---------------------------------------------------------------------------

variable "enable_self_hosted_ir" {
  description = "Create a self-hosted integration runtime"
  type        = bool
  default     = false
}

variable "self_hosted_ir_name" {
  description = "Name of the self-hosted integration runtime"
  type        = string
  default     = "SelfHostedIntegrationRuntime"
}

variable "managed_ir_compute_type" {
  description = "Compute type for managed IR (General, ComputeOptimized, MemoryOptimized)"
  type        = string
  default     = "General"
  validation {
    condition     = contains(["General", "ComputeOptimized", "MemoryOptimized"], var.managed_ir_compute_type)
    error_message = "Compute type must be General, ComputeOptimized, or MemoryOptimized."
  }
}

variable "managed_ir_core_count" {
  description = "Core count for managed integration runtime (8, 16, 32, 48, 80, 144, 272)"
  type        = number
  default     = 8
}

variable "managed_ir_ttl_minutes" {
  description = "Time to live in minutes for managed IR compute (0 = no caching)"
  type        = number
  default     = 10
}

# ---------------------------------------------------------------------------
# Key Vault
# ---------------------------------------------------------------------------

variable "key_vault_name" {
  description = "Name of the Azure Key Vault for secret management"
  type        = string
  default     = ""
}

variable "key_vault_resource_group" {
  description = "Resource group of the Key Vault (defaults to ADF resource group)"
  type        = string
  default     = ""
}

# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------

variable "storage_account_name" {
  description = "Name of the primary storage account"
  type        = string
  default     = ""
}

variable "storage_account_id" {
  description = "Resource ID of the storage account for RBAC assignment"
  type        = string
  default     = ""
}

variable "adls_account_id" {
  description = "Resource ID of the ADLS Gen2 account for RBAC assignment"
  type        = string
  default     = ""
}

# ---------------------------------------------------------------------------
# Source Control Integration
# ---------------------------------------------------------------------------

variable "github_account_name" {
  description = "GitHub account name for Git integration"
  type        = string
  default     = ""
}

variable "github_repo_name" {
  description = "GitHub repository name (leave empty to skip GitHub integration)"
  type        = string
  default     = ""
}

variable "github_branch_name" {
  description = "GitHub collaboration branch"
  type        = string
  default     = "main"
}

variable "github_root_folder" {
  description = "Root folder in the GitHub repository for ADF resources"
  type        = string
  default     = "/adf"
}

variable "azure_devops_account_name" {
  description = "Azure DevOps organization name"
  type        = string
  default     = ""
}

variable "azure_devops_project_name" {
  description = "Azure DevOps project name (leave empty to skip Azure DevOps integration)"
  type        = string
  default     = ""
}

variable "azure_devops_repo_name" {
  description = "Azure DevOps repository name"
  type        = string
  default     = ""
}

variable "azure_devops_branch_name" {
  description = "Azure DevOps collaboration branch"
  type        = string
  default     = "main"
}

variable "azure_devops_root_folder" {
  description = "Root folder in the Azure DevOps repository for ADF resources"
  type        = string
  default     = "/adf"
}

# ---------------------------------------------------------------------------
# Monitoring & Alerts
# ---------------------------------------------------------------------------

variable "log_analytics_workspace_id" {
  description = "Resource ID of the Log Analytics workspace for diagnostics"
  type        = string
  default     = ""
}

variable "enable_alerts" {
  description = "Enable Azure Monitor alert rules for pipeline failures"
  type        = bool
  default     = true
}

variable "action_group_id" {
  description = "Resource ID of the action group for alert notifications"
  type        = string
  default     = ""
}
