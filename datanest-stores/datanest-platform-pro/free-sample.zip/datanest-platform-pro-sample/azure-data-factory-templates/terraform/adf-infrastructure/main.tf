# ---------------------------------------------------------------------------
# Azure Data Factory Infrastructure — Terraform Configuration
# Datanest Digital (https://datanest.dev)
#
# Provisions: ADF instance, managed identity, RBAC, diagnostics, private
# endpoints, self-hosted integration runtime, and supporting resources.
# ---------------------------------------------------------------------------

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.80"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 2.45"
    }
  }

  backend "azurerm" {
    # Configure in backend.tfvars or via CLI:
    # terraform init -backend-config=backend.tfvars
  }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy = false
    }
  }
}

# ---------------------------------------------------------------------------
# Data Sources
# ---------------------------------------------------------------------------

data "azurerm_client_config" "current" {}

data "azurerm_resource_group" "main" {
  name = var.resource_group_name
}

data "azurerm_subnet" "private_endpoint" {
  count                = var.enable_private_endpoints ? 1 : 0
  name                 = var.private_endpoint_subnet_name
  virtual_network_name = var.virtual_network_name
  resource_group_name  = var.network_resource_group_name
}

# ---------------------------------------------------------------------------
# Azure Data Factory
# ---------------------------------------------------------------------------

resource "azurerm_data_factory" "main" {
  name                = var.data_factory_name
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name

  managed_virtual_network_enabled = var.enable_managed_vnet
  public_network_enabled          = var.enable_public_network

  identity {
    type = "SystemAssigned"
  }

  dynamic "github_configuration" {
    for_each = var.github_repo_name != "" ? [1] : []
    content {
      account_name    = var.github_account_name
      repository_name = var.github_repo_name
      branch_name     = var.github_branch_name
      root_folder     = var.github_root_folder
      git_url         = "https://github.com"
    }
  }

  dynamic "vsts_configuration" {
    for_each = var.azure_devops_project_name != "" ? [1] : []
    content {
      account_name    = var.azure_devops_account_name
      project_name    = var.azure_devops_project_name
      repository_name = var.azure_devops_repo_name
      branch_name     = var.azure_devops_branch_name
      root_folder     = var.azure_devops_root_folder
      tenant_id       = data.azurerm_client_config.current.tenant_id
    }
  }

  global_parameter {
    name  = "gp_environment"
    type  = "String"
    value = var.environment
  }

  global_parameter {
    name  = "gp_key_vault_url"
    type  = "String"
    value = "https://${var.key_vault_name}.vault.azure.net/"
  }

  global_parameter {
    name  = "gp_storage_account_name"
    type  = "String"
    value = var.storage_account_name
  }

  tags = merge(var.tags, {
    managed_by  = "terraform"
    product     = "datanest-adf-templates"
    environment = var.environment
  })
}

# ---------------------------------------------------------------------------
# Self-Hosted Integration Runtime
# ---------------------------------------------------------------------------

resource "azurerm_data_factory_integration_runtime_self_hosted" "shir" {
  count           = var.enable_self_hosted_ir ? 1 : 0
  name            = var.self_hosted_ir_name
  data_factory_id = azurerm_data_factory.main.id
  description     = "Self-hosted IR for on-premises and private network data source connectivity"
}

# ---------------------------------------------------------------------------
# Azure Integration Runtime (Managed VNet)
# ---------------------------------------------------------------------------

resource "azurerm_data_factory_integration_runtime_azure" "managed" {
  count                   = var.enable_managed_vnet ? 1 : 0
  name                    = "ManagedVNetIntegrationRuntime"
  data_factory_id         = azurerm_data_factory.main.id
  location                = data.azurerm_resource_group.main.location
  virtual_network_enabled = true
  compute_type            = var.managed_ir_compute_type
  core_count              = var.managed_ir_core_count
  time_to_live_min        = var.managed_ir_ttl_minutes
  description             = "Managed VNet integration runtime for secure data movement"
}

# ---------------------------------------------------------------------------
# Key Vault Access for ADF Managed Identity
# ---------------------------------------------------------------------------

data "azurerm_key_vault" "main" {
  count               = var.key_vault_name != "" ? 1 : 0
  name                = var.key_vault_name
  resource_group_name = var.key_vault_resource_group != "" ? var.key_vault_resource_group : var.resource_group_name
}

resource "azurerm_key_vault_access_policy" "adf" {
  count        = var.key_vault_name != "" ? 1 : 0
  key_vault_id = data.azurerm_key_vault.main[0].id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = azurerm_data_factory.main.identity[0].principal_id

  secret_permissions = [
    "Get",
    "List"
  ]
}

# ---------------------------------------------------------------------------
# RBAC: Storage Blob Data Contributor for ADF
# ---------------------------------------------------------------------------

resource "azurerm_role_assignment" "adf_storage_contributor" {
  count                = var.storage_account_id != "" ? 1 : 0
  scope                = var.storage_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_data_factory.main.identity[0].principal_id
}

resource "azurerm_role_assignment" "adf_adls_contributor" {
  count                = var.adls_account_id != "" ? 1 : 0
  scope                = var.adls_account_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_data_factory.main.identity[0].principal_id
}

# ---------------------------------------------------------------------------
# Diagnostic Settings — Log Analytics
# ---------------------------------------------------------------------------

resource "azurerm_monitor_diagnostic_setting" "adf" {
  count                      = var.log_analytics_workspace_id != "" ? 1 : 0
  name                       = "${var.data_factory_name}-diagnostics"
  target_resource_id         = azurerm_data_factory.main.id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  enabled_log {
    category = "PipelineRuns"
  }

  enabled_log {
    category = "TriggerRuns"
  }

  enabled_log {
    category = "ActivityRuns"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# ---------------------------------------------------------------------------
# Private Endpoint (optional)
# ---------------------------------------------------------------------------

resource "azurerm_private_endpoint" "adf" {
  count               = var.enable_private_endpoints ? 1 : 0
  name                = "${var.data_factory_name}-pe"
  location            = data.azurerm_resource_group.main.location
  resource_group_name = data.azurerm_resource_group.main.name
  subnet_id           = data.azurerm_subnet.private_endpoint[0].id

  private_service_connection {
    name                           = "${var.data_factory_name}-psc"
    private_connection_resource_id = azurerm_data_factory.main.id
    is_manual_connection           = false
    subresource_names              = ["dataFactory"]
  }

  tags = var.tags
}

# ---------------------------------------------------------------------------
# Alert Rule — Pipeline Failure
# ---------------------------------------------------------------------------

resource "azurerm_monitor_metric_alert" "pipeline_failure" {
  count               = var.enable_alerts && var.action_group_id != "" ? 1 : 0
  name                = "${var.data_factory_name}-pipeline-failure-alert"
  resource_group_name = data.azurerm_resource_group.main.name
  scopes              = [azurerm_data_factory.main.id]
  description         = "Alert when ADF pipeline runs fail"
  severity            = 1
  frequency           = "PT5M"
  window_size         = "PT15M"

  criteria {
    metric_namespace = "Microsoft.DataFactory/factories"
    metric_name      = "PipelineFailedRuns"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = var.action_group_id
  }

  tags = var.tags
}
