# Error Handling & Retry Patterns for ADF

**Datanest Digital — [datanest.dev](https://datanest.dev)**

---

## Overview

Azure Data Factory pipelines fail. Sources go offline, APIs throttle, clusters run out of memory. This guide covers the patterns you need to build resilient pipelines that handle failure gracefully, retry intelligently, and alert operators when human intervention is required.

---

## 1. Activity-Level Retry Configuration

Every ADF activity supports a built-in retry policy:

```json
{
  "policy": {
    "timeout": "0.01:00:00",
    "retry": 3,
    "retryIntervalInSeconds": 60,
    "secureOutput": false,
    "secureInput": false
  }
}
```

### Recommended Retry Settings

| Activity Type | Retry Count | Interval | Timeout | Rationale |
|---------------|------------|----------|---------|-----------|
| Copy (small) | 3 | 30s | 30m | Transient network failures |
| Copy (large) | 2 | 120s | 4h | Source throttling |
| REST API call | 3 | 60s | 10m | API rate limits |
| Lookup | 3 | 30s | 5m | Database connection pools |
| Stored Procedure | 2 | 30s | 10m | Lock contention |
| Databricks Notebook | 2 | 120s | 2h | Cluster provisioning |
| Web Activity | 3 | 30s | 2m | Webhook timeouts |

### Key Behaviors

- Retries are **exponential** — ADF doubles the interval on each retry
- The timeout applies to **each attempt**, not the total duration
- Retries only trigger on **transient errors** (HTTP 429, 500, 503, timeouts)
- **Non-transient errors** (HTTP 400, 401, 404) fail immediately without retry

---

## 2. Dependency Conditions

Each activity can depend on upstream activities with four conditions:

| Condition | When It Fires |
|-----------|---------------|
| `Succeeded` | Upstream completed successfully |
| `Failed` | Upstream failed after all retries exhausted |
| `Completed` | Upstream finished (success or failure) |
| `Skipped` | Upstream was skipped due to its own dependency condition |

### Error Handling Branch Pattern

```
[Main Activity]
    ├── (Succeeded) → [Next Step]
    └── (Failed)    → [Log Error] → [Send Alert] → [Fail Pipeline]
```

Implementation:

```json
{
  "name": "LogError",
  "dependsOn": [
    {
      "activity": "CopyData",
      "dependencyConditions": ["Failed"]
    }
  ]
}
```

### Accessing Error Details

```
@activity('CopyData').error.message
@activity('CopyData').error.errorCode
@string(activity('CopyData').error)
```

---

## 3. Try-Catch-Finally Pattern

ADF does not have native try-catch, but you can implement it using dependency conditions:

```
[Try: Main Copy]
    ├── (Succeeded) → [Finally: Log Success]
    └── (Failed)    → [Catch: Handle Error] → [Finally: Log Completion]
```

The "Finally" activity uses a `Completed` dependency condition so it runs regardless of success or failure:

```json
{
  "name": "FinallyLogCompletion",
  "dependsOn": [
    { "activity": "MainCopy", "dependencyConditions": ["Completed"] },
    { "activity": "HandleError", "dependencyConditions": ["Completed"] }
  ]
}
```

---

## 4. Circuit Breaker Pattern

For pipelines that call external APIs, implement a circuit breaker to avoid overwhelming a struggling service:

1. **Before each API call**, check a failure counter in your metadata database
2. If the failure count exceeds a threshold within a time window, **skip the call** and log a circuit-open event
3. After a cooldown period, allow a **single probe request** through
4. If the probe succeeds, reset the counter

```json
{
  "name": "CheckCircuitBreaker",
  "type": "Lookup",
  "typeProperties": {
    "source": {
      "type": "AzureSqlSource",
      "sqlReaderQuery": "SELECT CASE WHEN failure_count >= 5 AND last_failure > DATEADD(MINUTE, -15, GETUTCDATE()) THEN 1 ELSE 0 END AS circuit_open FROM dbo.circuit_breaker WHERE source_name = '@{pipeline().parameters.p_source_name}'"
    }
  }
}
```

---

## 5. Dead Letter Queue Pattern

When processing multiple files or records, don't let one failure abort the entire batch:

1. Use **ForEach** with error handling inside each iteration
2. Failed items log to a **dead letter table** with the error details
3. Successful items proceed normally
4. A separate **reprocessing pipeline** picks up dead letter items

```json
{
  "name": "ProcessFile",
  "type": "Copy",
  "dependsOn": []
},
{
  "name": "LogToDeadLetter",
  "type": "SqlServerStoredProcedure",
  "dependsOn": [
    { "activity": "ProcessFile", "dependencyConditions": ["Failed"] }
  ],
  "typeProperties": {
    "storedProcedureName": "[dbo].[usp_insert_dead_letter]",
    "storedProcedureParameters": {
      "file_name": { "value": "@item().name" },
      "error_message": { "value": "@string(activity('ProcessFile').error)" },
      "retry_count": { "value": 0 }
    }
  }
}
```

---

## 6. Alerting Patterns

### Webhook Alerts (Teams / Slack)

```json
{
  "name": "SendAlert",
  "type": "WebActivity",
  "typeProperties": {
    "url": "@pipeline().parameters.p_webhook_url",
    "method": "POST",
    "body": {
      "value": "@json(concat('{\"text\": \"Pipeline ', pipeline().Pipeline, ' failed. Run ID: ', pipeline().RunId, '. Error: ', replace(string(activity('MainCopy').error.message), '\"', '\\\"'), '\"}'))",
      "type": "Expression"
    }
  }
}
```

### Azure Monitor Alerts

Configure metric alerts in Terraform (see `main.tf`):
- **PipelineFailedRuns** > 0 within 15 minutes
- **ActivityFailedRuns** > threshold for specific activity types

### Alert Fatigue Prevention

- Set minimum alert intervals (don't alert on every retry, only on final failure)
- Group related failures into a single alert using pipeline-level error handling
- Use severity levels: P1 for production data pipelines, P3 for dev/test

---

## 7. Pipeline Failure Propagation

### Fail the Pipeline on Error

Use a `Fail` activity (ADF V2) to explicitly fail the pipeline with a custom error:

```json
{
  "name": "FailPipeline",
  "type": "Fail",
  "dependsOn": [
    { "activity": "LogError", "dependencyConditions": ["Succeeded"] }
  ],
  "typeProperties": {
    "message": {
      "value": "@concat('Pipeline failed: ', activity('MainCopy').error.message)",
      "type": "Expression"
    },
    "errorCode": {
      "value": "@activity('MainCopy').error.errorCode",
      "type": "Expression"
    }
  }
}
```

### Swallow Errors Gracefully

For non-critical steps, use the `Completed` dependency condition to continue regardless:

```json
{
  "name": "OptionalEnrichment",
  "dependsOn": [
    { "activity": "CoreProcessing", "dependencyConditions": ["Succeeded"] }
  ]
},
{
  "name": "NextStep",
  "dependsOn": [
    { "activity": "OptionalEnrichment", "dependencyConditions": ["Completed"] }
  ]
}
```

---

## 8. Testing Error Handling

Validate your error handling works before production:

1. **Force failures** by pointing to non-existent sources or invalid credentials
2. **Simulate timeouts** by setting unrealistically short timeout values
3. **Test retry exhaustion** by pointing to a permanently unavailable endpoint
4. **Verify alerts fire** by triggering each failure path
5. **Check dead letter entries** contain sufficient detail for reprocessing

---

© 2026 Datanest Digital. All rights reserved.
