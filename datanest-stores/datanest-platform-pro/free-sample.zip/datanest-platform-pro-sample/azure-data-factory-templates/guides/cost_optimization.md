# ADF Cost Optimization Guide

**Datanest Digital — [datanest.dev](https://datanest.dev)**

---

## Overview

Azure Data Factory billing is based on four cost dimensions: pipeline orchestration (activity runs), data movement (DIU-hours), data flow execution (vCore-hours), and integration runtime (SHIR uptime). This guide provides actionable strategies to reduce costs across all dimensions.

---

## 1. Understanding ADF Pricing Dimensions

| Dimension | Unit | Approximate Cost |
|-----------|------|-----------------|
| Pipeline activity runs | Per 1,000 runs | $1.00 |
| Data movement (Azure IR) | Per DIU-hour | $0.25 |
| Data movement (SHIR) | Per hour | $0.10 |
| Data flow (General) | Per vCore-hour | $0.268 |
| Data flow (Compute Optimized) | Per vCore-hour | $0.212 |
| Data flow (Memory Optimized) | Per vCore-hour | $0.335 |

*Prices are approximate and region-dependent. Check Azure pricing calculator for current rates.*

---

## 2. Pipeline Activity Run Optimization

### Reduce Activity Count

Every activity execution incurs a charge. Consolidate where possible:

- **Combine multiple Copy activities** into a single parameterized Copy with wildcard paths
- **Use ForEach** instead of duplicating activities for similar operations
- **Avoid unnecessary Lookup activities** — pass values as parameters instead of querying every run
- **Remove diagnostic SetVariable activities** from production pipelines

### Batch Metadata Lookups

Instead of one Lookup per table in a ForEach loop:

```
BAD:  ForEach → [Lookup Config] → [Copy Data]   (2 activities × N tables)
GOOD: [Lookup All Configs] → ForEach → [Copy Data]   (1 + N activities)
```

### Schedule Consolidation

- Consolidate pipelines that run at the same frequency into a single master pipeline
- Use tumbling window triggers instead of schedule triggers for backfill-heavy workloads (tumbling windows handle reruns efficiently)

---

## 3. Data Integration Unit (DIU) Optimization

DIUs determine the compute power allocated to Copy activities. More DIUs = faster copies but higher cost.

### Right-Sizing DIU Allocation

| Data Volume | Recommended DIU | Notes |
|-------------|----------------|-------|
| < 100 MB | 2 (minimum) | Default is fine |
| 100 MB - 1 GB | 4 | Slight improvement over 2 |
| 1 - 10 GB | 4-8 | Monitor throughput vs. cost |
| 10 - 100 GB | 8-16 | Diminishing returns above 16 |
| 100+ GB | 16-32 | Test; not always linear scaling |

### Auto DIU vs. Fixed DIU

ADF defaults to "Auto" (up to 256 DIUs). For cost control:

```json
{
  "dataIntegrationUnits": 4
}
```

Set this explicitly in your Copy activity. Monitor the actual DIU usage in pipeline run output:

```
activity('CopyData').output.usedDataIntegrationUnits
```

If actual usage is consistently below your setting, reduce it.

### Parallel Copies

The `parallelCopies` property controls concurrent read/write threads within a single Copy activity:

```json
{
  "parallelCopies": 4
}
```

- Default is `null` (ADF auto-determines)
- For database sources, keep at 4-8 to avoid overwhelming the source
- For blob/ADLS, higher values (16-32) can improve throughput

---

## 4. Self-Hosted Integration Runtime Sizing

SHIR is billed per node, per hour — whether active or idle.

### Sizing Guidelines

| Concurrent Pipelines | SHIR Nodes | CPU Cores | RAM |
|---------------------|------------|-----------|-----|
| 1-5 | 1 | 4 | 8 GB |
| 5-20 | 2 | 4 | 16 GB |
| 20-50 | 2-4 | 8 | 32 GB |
| 50+ | 4+ | 8+ | 32+ GB |

### Cost Reduction Strategies

1. **Auto-shutdown for non-production** — Use Azure Automation to stop SHIR VMs outside business hours:

   ```powershell
   # Azure Automation runbook
   $vms = Get-AzVM -ResourceGroupName "rg-shir" -Status
   foreach ($vm in $vms) {
       if ($vm.PowerState -eq "VM running") {
           Stop-AzVM -Name $vm.Name -ResourceGroupName "rg-shir" -Force
       }
   }
   ```

2. **Shared SHIR** — A single SHIR node can be shared across multiple ADF instances (up to 4). Use this for dev/test environments.

3. **Right-size VMs** — Start with Standard_D2s_v3 and scale up only if you see queue times in SHIR monitoring.

4. **Use Azure IR where possible** — If your source is publicly accessible or in Azure, prefer Azure IR over SHIR.

---

## 5. Concurrency Tuning

### Pipeline Concurrency

Limit concurrent pipeline runs to prevent resource contention and cost spikes:

```json
{
  "policy": {
    "pipelineConcurrency": 5
  }
}
```

### ForEach Batch Size

Default `batchCount` is 20 (max 50). Lower this to reduce peak resource consumption:

```json
{
  "type": "ForEach",
  "typeProperties": {
    "batchCount": 5,
    "isSequential": false
  }
}
```

### Trigger Staggering

If multiple pipelines trigger at the same time (e.g., hourly on the hour), stagger them:

| Pipeline | Schedule |
|----------|----------|
| Ingest Orders | :00 past the hour |
| Ingest Customers | :05 past the hour |
| Ingest Products | :10 past the hour |

This flattens the SHIR load curve and avoids queueing.

---

## 6. Data Flow Cost Optimization

Data flows are the most expensive ADF component. Optimize aggressively.

### Use Copy Activity Instead of Data Flow

If your transformation is simple (column mapping, type conversion, filtering), a Copy activity with column mapping is 10-50x cheaper than a data flow.

**Use Data Flows for:**
- Complex joins across multiple sources
- Window functions and aggregations
- Slowly changing dimensions
- Schema drift handling

**Use Copy Activity for:**
- Direct source-to-sink copies
- Simple column selection/renaming
- File format conversion (CSV → Parquet)

### TTL (Time to Live)

Data flow clusters take 3-5 minutes to start. TTL keeps the cluster warm:

```json
{
  "timeToLive": 10
}
```

- Set TTL to 10 minutes if data flows run every 15 minutes (avoids repeated startup)
- Set TTL to 0 for infrequent runs (don't pay for idle compute)

### Right-Size Compute

Start with **General Purpose, 8 cores** and scale based on actual execution metrics:

```
activity('DataFlowActivity').output.runStatus.metrics.sink1.rowsWritten
activity('DataFlowActivity').output.runStatus.profile.compute.coreCount
```

---

## 7. Monitoring Costs

### ADF Metrics to Track

Set up Azure Monitor dashboards for:

- `PipelineSucceededRuns` / `PipelineFailedRuns` — track failure-driven reruns
- `ActivitySucceededRuns` — total billable activity executions
- `IntegrationRuntimeCpuPercentage` — SHIR utilization (low = over-provisioned)
- `IntegrationRuntimeAvailableMemory` — SHIR memory headroom

### Cost Analysis Queries

Use Log Analytics to identify expensive pipelines:

```kusto
ADFActivityRun
| where TimeGenerated > ago(30d)
| summarize RunCount = count(), TotalDurationMin = sum(Duration) / 60000 by PipelineName
| order by RunCount desc
| take 20
```

### Monthly Cost Estimation Formula

```
Monthly Cost ≈
  (Activity Runs / 1000 × $1.00)
  + (DIU-Hours × $0.25)
  + (SHIR Node Hours × $0.10)
  + (Data Flow vCore-Hours × $0.268)
```

---

## 8. Quick Wins Checklist

- [ ] Set explicit DIU values on all Copy activities (don't rely on Auto)
- [ ] Consolidate small Lookup activities into batch queries
- [ ] Shut down SHIR VMs in dev/test outside business hours
- [ ] Replace simple Data Flows with Copy + column mapping
- [ ] Set pipeline concurrency limits on resource-intensive pipelines
- [ ] Stagger trigger schedules to flatten peak load
- [ ] Enable data flow TTL only for frequently-triggered flows
- [ ] Review failed pipeline runs — reruns double your cost
- [ ] Use `parallelCopies` to optimize throughput per DIU
- [ ] Monitor SHIR CPU — if consistently < 30%, downsize the VM

---

© 2026 Datanest Digital. All rights reserved.
