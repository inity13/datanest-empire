# Azure Data Factory Integration Templates

**By [Datanest Digital](https://datanest.dev) — Production-Ready ADF Pipelines & Infrastructure**

---

## Overview

A comprehensive collection of Azure Data Factory pipeline templates, linked service configurations, Terraform infrastructure-as-code, and operational guides designed for enterprise data integration workloads. Every template follows Microsoft best practices for error handling, retry logic, parameterization, and cost optimization.

## What's Included

### Pipelines (6 Templates)

| Template | Description |
|----------|-------------|
| `rest_api_ingestion.json` | REST API ingestion with pagination, retry policies, and incremental load support |
| `sftp_file_ingestion.json` | SFTP file pickup with pattern matching, archival, and processing validation |
| `sql_server_cdc.json` | SQL Server change data capture with watermark tracking and merge operations |
| `blob_copy_with_metadata.json` | Parameterized blob-to-blob copy with metadata tracking and audit logging |
| `event_driven_trigger.json` | Event Grid triggered pipeline for real-time file processing |
| `databricks_notebook_activity.json` | ADF-to-Databricks notebook orchestration with cluster management |

### Linked Services (10 Templates)

Pre-configured linked service templates for:

- Azure SQL Database
- Azure Blob Storage
- Azure Data Lake Storage Gen2
- REST API (OAuth2 / API Key)
- SFTP
- Azure Databricks
- Azure Key Vault
- Azure Synapse Analytics
- On-Premises SQL Server (Self-Hosted IR)
- Azure Event Hubs

### Terraform Infrastructure

- `main.tf` — Full ADF resource provisioning with managed identity, diagnostics, and networking
- `variables.tf` — Parameterized variables with sensible defaults
- `outputs.tf` — Key resource outputs for downstream automation

### Guides

- **ADF-to-Databricks Integration Patterns** — Architecture patterns, cluster strategies, parameter passing
- **Error Handling & Retry Patterns** — Circuit breakers, dead-letter queues, alerting strategies
- **Cost Optimization** — Self-hosted IR sizing, concurrency tuning, pipeline optimization

### CI/CD

- `adf-devops-pipeline.yml` — Azure DevOps pipeline for ADF ARM template deployment across environments

## Getting Started

### Prerequisites

- Azure subscription with Data Factory resource provider registered
- Terraform >= 1.5.0 (for infrastructure provisioning)
- Azure CLI >= 2.50.0
- Azure DevOps project (for CI/CD pipeline)

### Quick Start

1. **Provision Infrastructure**

   ```bash
   cd terraform/adf-infrastructure
   cp terraform.tfvars.example terraform.tfvars
   # Edit terraform.tfvars with your values
   terraform init
   terraform plan -out=tfplan
   terraform apply tfplan
   ```

2. **Import Pipeline Templates**

   Using Azure CLI:

   ```bash
   az datafactory pipeline create \
     --resource-group <rg-name> \
     --factory-name <adf-name> \
     --name "RestApiIngestion" \
     --pipeline @pipelines/rest_api_ingestion.json
   ```

   Or import directly via ADF Studio:
   - Open ADF Studio > Author > Pipelines
   - Select "Import from pipeline template"
   - Upload the desired `.json` file

3. **Configure Linked Services**

   Update the linked service templates in `linked-services/` with your connection details, then deploy:

   ```bash
   az datafactory linked-service create \
     --resource-group <rg-name> \
     --factory-name <adf-name> \
     --linked-service-name "AzureSqlDatabase" \
     --properties @linked-services/linked_service_templates.json
   ```

4. **Set Up CI/CD**

   Copy `cicd/adf-devops-pipeline.yml` to your Azure DevOps repository and configure the required variable groups.

## Configuration

All pipelines use ADF parameters and global parameters for environment-specific values. No hardcoded connection strings or secrets — all sensitive values reference Azure Key Vault.

### Parameter Conventions

| Parameter Pattern | Description |
|-------------------|-------------|
| `p_*` | Pipeline parameters |
| `gp_*` | Global parameters |
| `v_*` | Pipeline variables |

### Environment Strategy

Templates support multi-environment deployment via:

- Terraform workspace or variable files per environment
- ADF global parameters overridden per environment in CI/CD
- ARM template parameter files for dev / staging / production

## Support

- Documentation: [https://datanest.dev/docs](https://datanest.dev/docs)
- Issues: [https://datanest.dev/support](https://datanest.dev/support)

## License

Commercial license — single-team use. See LICENSE file for full terms.

© 2026 Datanest Digital. All rights reserved.
