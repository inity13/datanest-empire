# Datanest Platform Pro — Free Sample Pack

Thank you for downloading the free sample pack!

## What's Included

- **Azure Data Factory Integration Templates** — 15 production-ready ADF pipeline templates for REST API, SFTP, SQL Server, and Event-driven ingestion into Databricks la...
- **Azure Synapse-Databricks Integration Kit** — Integration patterns for organizations running both Synapse and Databricks. Serverless views, Power BI setup, and cost c...

## Get the Full Collection

This sample includes a preview of what's available in Datanest Platform Pro.
The full store has 20 products covering Production-ready data platform templates, frameworks, and toolkits for Databricks and Azure.

Visit: https://inity13.github.io/datanest-platform-pro/

Use code **COMMUNITY** for 15% off your first purchase.
Students/bootcamp grads: use code **STUDENT** for 50% off.

## Contact

Questions? Reach out at megafolder122122@hotmail.com
