# =============================================================================
# Variables: Joint Azure Synapse + Databricks Infrastructure
# Azure Synapse-Databricks Integration Kit
# Datanest Digital | https://datanest.dev
# =============================================================================

# =============================================================================
# General
# =============================================================================

variable "prefix" {
  description = "Naming prefix for all resources (e.g., 'dataplatform', 'analytics')."
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,19}$", var.prefix))
    error_message = "Prefix must be 3-20 lowercase alphanumeric characters or hyphens, starting with a letter."
  }
}

variable "resource_group_name" {
  description = "Name of the Azure resource group."
  type        = string
}

variable "location" {
  description = "Azure region for all resources."
  type        = string
  default     = "eastus2"
}

variable "tags" {
  description = "Tags applied to all resources."
  type        = map(string)
  default = {
    ManagedBy = "Terraform"
    Product   = "Azure Synapse-Databricks Integration Kit"
    Vendor    = "Datanest Digital"
  }
}

# =============================================================================
# Networking
# =============================================================================

variable "vnet_address_space" {
  description = "Address space for the virtual network."
  type        = string
  default     = "10.0.0.0/16"
}

variable "databricks_host_subnet_cidr" {
  description = "CIDR block for the Databricks host (public) subnet."
  type        = string
  default     = "10.0.1.0/24"
}

variable "databricks_container_subnet_cidr" {
  description = "CIDR block for the Databricks container (private) subnet."
  type        = string
  default     = "10.0.2.0/24"
}

variable "private_endpoint_subnet_cidr" {
  description = "CIDR block for private endpoints."
  type        = string
  default     = "10.0.3.0/24"
}

variable "synapse_subnet_cidr" {
  description = "CIDR block for the Synapse managed subnet."
  type        = string
  default     = "10.0.4.0/24"
}

variable "enable_private_endpoints" {
  description = "Enable private endpoints for storage, Key Vault, and Synapse."
  type        = bool
  default     = false
}

# =============================================================================
# Storage Account (ADLS Gen2)
# =============================================================================

variable "storage_account_name" {
  description = "Globally unique name for the ADLS Gen2 storage account. Must be 3-24 lowercase alphanumeric."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9]{3,24}$", var.storage_account_name))
    error_message = "Storage account name must be 3-24 lowercase alphanumeric characters."
  }
}

variable "storage_replication_type" {
  description = "Storage replication type (LRS, GRS, ZRS, GZRS)."
  type        = string
  default     = "LRS"

  validation {
    condition     = contains(["LRS", "GRS", "ZRS", "GZRS", "RAGRS", "RAGZRS"], var.storage_replication_type)
    error_message = "Must be one of: LRS, GRS, ZRS, GZRS, RAGRS, RAGZRS."
  }
}

variable "lake_containers" {
  description = "List of ADLS Gen2 containers to create (medallion layers + workspace)."
  type        = list(string)
  default     = ["bronze", "silver", "gold", "synapse-shared", "synapse-workspace", "snapshots"]
}

# =============================================================================
# Azure Databricks
# =============================================================================

variable "databricks_sku" {
  description = "Databricks workspace SKU (standard or premium). Premium required for Unity Catalog."
  type        = string
  default     = "premium"

  validation {
    condition     = contains(["standard", "premium"], var.databricks_sku)
    error_message = "Must be 'standard' or 'premium'. Premium is required for Unity Catalog."
  }
}

variable "databricks_no_public_ip" {
  description = "Disable public IPs on Databricks cluster nodes (secure cluster connectivity)."
  type        = bool
  default     = true
}

variable "databricks_sql_warehouse_size" {
  description = "T-shirt size for the Databricks SQL warehouse (2X-Small, X-Small, Small, Medium, Large, etc.)."
  type        = string
  default     = "Small"
}

variable "databricks_sql_warehouse_max_clusters" {
  description = "Maximum number of clusters for SQL warehouse autoscaling."
  type        = number
  default     = 2

  validation {
    condition     = var.databricks_sql_warehouse_max_clusters >= 1 && var.databricks_sql_warehouse_max_clusters <= 30
    error_message = "Must be between 1 and 30."
  }
}

variable "databricks_sql_warehouse_auto_stop" {
  description = "Minutes of inactivity before SQL warehouse auto-stops."
  type        = number
  default     = 15

  validation {
    condition     = var.databricks_sql_warehouse_auto_stop >= 5
    error_message = "Must be at least 5 minutes."
  }
}

variable "databricks_sql_serverless" {
  description = "Enable serverless compute for the SQL warehouse."
  type        = bool
  default     = false
}

# =============================================================================
# Azure Synapse
# =============================================================================

variable "synapse_sql_admin_username" {
  description = "SQL administrator username for the Synapse workspace."
  type        = string
  default     = "synapseadmin"

  validation {
    condition     = !contains(["admin", "administrator", "sa", "root", "dbmanager", "loginmanager", "dbo", "guest", "public"], lower(var.synapse_sql_admin_username))
    error_message = "Cannot use reserved SQL usernames."
  }
}

variable "synapse_sql_admin_password" {
  description = "SQL administrator password for the Synapse workspace. Must meet complexity requirements."
  type        = string
  sensitive   = true

  validation {
    condition     = length(var.synapse_sql_admin_password) >= 12
    error_message = "Password must be at least 12 characters."
  }
}

variable "enable_dedicated_sql_pool" {
  description = "Deploy a Synapse dedicated SQL pool."
  type        = bool
  default     = false
}

variable "dedicated_pool_name" {
  description = "Name for the Synapse dedicated SQL pool."
  type        = string
  default     = "dwh"
}

variable "dedicated_pool_sku" {
  description = "SKU (DWU level) for the dedicated SQL pool (e.g., DW100c, DW200c, DW500c)."
  type        = string
  default     = "DW100c"

  validation {
    condition     = can(regex("^DW\\d+c$", var.dedicated_pool_sku))
    error_message = "Must be a valid dedicated pool SKU (e.g., DW100c, DW200c, DW500c)."
  }
}

variable "enable_data_exfiltration_protection" {
  description = "Enable Synapse data exfiltration protection (restricts outbound traffic)."
  type        = bool
  default     = false
}
