# =============================================================================
# Joint Azure Synapse + Databricks Infrastructure
# Azure Synapse-Databricks Integration Kit
# Datanest Digital | https://datanest.dev
# =============================================================================
#
# This Terraform configuration deploys:
#   - Resource Group
#   - ADLS Gen2 Storage Account (shared data lake)
#   - Azure Databricks Workspace (with Unity Catalog support)
#   - Azure Synapse Workspace (serverless + optional dedicated pool)
#   - Azure Key Vault (shared secrets)
#   - Managed Identities and RBAC assignments
#   - Virtual Network with subnets for both services
#   - Private Endpoints (optional, controlled by variable)
#
# =============================================================================

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.80"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 2.47"
    }
    databricks = {
      source  = "databricks/databricks"
      version = "~> 1.30"
    }
  }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy = false
    }
  }
}

provider "azuread" {}

provider "databricks" {
  host = azurerm_databricks_workspace.main.workspace_url
}

# =============================================================================
# Data Sources
# =============================================================================

data "azurerm_client_config" "current" {}

data "azuread_client_config" "current" {}

# =============================================================================
# Resource Group
# =============================================================================

resource "azurerm_resource_group" "main" {
  name     = var.resource_group_name
  location = var.location

  tags = var.tags
}

# =============================================================================
# Virtual Network
# =============================================================================

resource "azurerm_virtual_network" "main" {
  name                = "${var.prefix}-vnet"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  address_space       = [var.vnet_address_space]

  tags = var.tags
}

# Subnet: Databricks host (public)
resource "azurerm_subnet" "databricks_host" {
  name                 = "${var.prefix}-dbx-host"
  resource_group_name  = azurerm_resource_group.main.name
  virtual_network_name = azurerm_virtual_network.main.name
  address_prefixes     = [var.databricks_host_subnet_cidr]

  delegation {
    name = "databricks-host"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

# Subnet: Databricks container (private)
resource "azurerm_subnet" "databricks_container" {
  name                 = "${var.prefix}-dbx-container"
  resource_group_name  = azurerm_resource_group.main.name
  virtual_network_name = azurerm_virtual_network.main.name
  address_prefixes     = [var.databricks_container_subnet_cidr]

  delegation {
    name = "databricks-container"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

# Subnet: Private endpoints
resource "azurerm_subnet" "private_endpoints" {
  name                 = "${var.prefix}-private-endpoints"
  resource_group_name  = azurerm_resource_group.main.name
  virtual_network_name = azurerm_virtual_network.main.name
  address_prefixes     = [var.private_endpoint_subnet_cidr]
}

# Subnet: Synapse managed
resource "azurerm_subnet" "synapse" {
  name                 = "${var.prefix}-synapse"
  resource_group_name  = azurerm_resource_group.main.name
  virtual_network_name = azurerm_virtual_network.main.name
  address_prefixes     = [var.synapse_subnet_cidr]
}

# NSG for Databricks subnets
resource "azurerm_network_security_group" "databricks" {
  name                = "${var.prefix}-dbx-nsg"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name

  tags = var.tags
}

resource "azurerm_subnet_network_security_group_association" "databricks_host" {
  subnet_id                 = azurerm_subnet.databricks_host.id
  network_security_group_id = azurerm_network_security_group.databricks.id
}

resource "azurerm_subnet_network_security_group_association" "databricks_container" {
  subnet_id                 = azurerm_subnet.databricks_container.id
  network_security_group_id = azurerm_network_security_group.databricks.id
}

# =============================================================================
# ADLS Gen2 Storage Account (Shared Data Lake)
# =============================================================================

resource "azurerm_storage_account" "datalake" {
  name                     = var.storage_account_name
  resource_group_name      = azurerm_resource_group.main.name
  location                 = azurerm_resource_group.main.location
  account_tier             = "Standard"
  account_replication_type = var.storage_replication_type
  account_kind             = "StorageV2"
  is_hns_enabled           = true # Required for ADLS Gen2
  min_tls_version          = "TLS1_2"

  # Disable public access in production (enable private endpoints)
  public_network_access_enabled = var.enable_private_endpoints ? false : true

  tags = var.tags
}

# Data lake containers (medallion architecture)
resource "azurerm_storage_container" "containers" {
  for_each              = toset(var.lake_containers)
  name                  = each.value
  storage_account_name  = azurerm_storage_account.datalake.name
  container_access_type = "private"
}

# =============================================================================
# Azure Key Vault
# =============================================================================

resource "azurerm_key_vault" "main" {
  name                       = "${var.prefix}-kv"
  location                   = azurerm_resource_group.main.location
  resource_group_name        = azurerm_resource_group.main.name
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "standard"
  soft_delete_retention_days = 7
  purge_protection_enabled   = true

  # Allow deployer access
  access_policy {
    tenant_id = data.azurerm_client_config.current.tenant_id
    object_id = data.azurerm_client_config.current.object_id

    secret_permissions = [
      "Get", "List", "Set", "Delete", "Purge",
    ]
  }

  tags = var.tags
}

# =============================================================================
# Azure Databricks Workspace
# =============================================================================

resource "azurerm_databricks_workspace" "main" {
  name                        = "${var.prefix}-dbx"
  resource_group_name         = azurerm_resource_group.main.name
  location                    = azurerm_resource_group.main.location
  sku                         = var.databricks_sku
  managed_resource_group_name = "${var.prefix}-dbx-managed-rg"

  custom_parameters {
    no_public_ip                                         = var.databricks_no_public_ip
    virtual_network_id                                   = azurerm_virtual_network.main.id
    private_subnet_name                                  = azurerm_subnet.databricks_container.name
    private_subnet_network_security_group_association_id = azurerm_subnet_network_security_group_association.databricks_container.id
    public_subnet_name                                   = azurerm_subnet.databricks_host.name
    public_subnet_network_security_group_association_id  = azurerm_subnet_network_security_group_association.databricks_host.id
    storage_account_name                                 = "${var.prefix}dbxsa"
  }

  tags = var.tags
}

# =============================================================================
# Databricks: Unity Catalog Storage Credential
# =============================================================================

resource "azurerm_user_assigned_identity" "databricks_storage" {
  name                = "${var.prefix}-dbx-storage-mi"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location

  tags = var.tags
}

# Grant the Databricks MI access to the data lake
resource "azurerm_role_assignment" "databricks_storage_contributor" {
  scope                = azurerm_storage_account.datalake.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_user_assigned_identity.databricks_storage.principal_id
}

# Register as Unity Catalog storage credential
resource "databricks_storage_credential" "datalake" {
  name = "datalake-credential"

  azure_managed_identity {
    access_connector_id = azurerm_databricks_access_connector.main.id
  }

  depends_on = [
    azurerm_role_assignment.databricks_storage_contributor,
  ]
}

# Databricks Access Connector for Unity Catalog
resource "azurerm_databricks_access_connector" "main" {
  name                = "${var.prefix}-dbx-access-connector"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location

  identity {
    type         = "UserAssigned"
    identity_ids = [azurerm_user_assigned_identity.databricks_storage.id]
  }

  tags = var.tags
}

# Unity Catalog external locations for each container
resource "databricks_external_location" "containers" {
  for_each = toset(var.lake_containers)

  name            = "${each.value}-location"
  url             = "abfss://${each.value}@${azurerm_storage_account.datalake.name}.dfs.core.windows.net/"
  credential_name = databricks_storage_credential.datalake.name

  depends_on = [
    databricks_storage_credential.datalake,
  ]
}

# =============================================================================
# Azure Synapse Workspace
# =============================================================================

resource "azurerm_synapse_workspace" "main" {
  name                                 = "${var.prefix}-synapse"
  resource_group_name                  = azurerm_resource_group.main.name
  location                             = azurerm_resource_group.main.location
  storage_data_lake_gen2_filesystem_id = azurerm_storage_container.containers["synapse-workspace"].id

  sql_administrator_login          = var.synapse_sql_admin_username
  sql_administrator_login_password = var.synapse_sql_admin_password

  managed_virtual_network_enabled = true
  data_exfiltration_protection_enabled = var.enable_data_exfiltration_protection

  identity {
    type = "SystemAssigned"
  }

  tags = var.tags
}

# Grant Synapse MI access to the data lake
resource "azurerm_role_assignment" "synapse_storage_contributor" {
  scope                = azurerm_storage_account.datalake.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_synapse_workspace.main.identity[0].principal_id
}

# Grant Synapse MI access to Key Vault
resource "azurerm_key_vault_access_policy" "synapse" {
  key_vault_id = azurerm_key_vault.main.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = azurerm_synapse_workspace.main.identity[0].principal_id

  secret_permissions = [
    "Get", "List",
  ]
}

# Synapse firewall: allow Azure services
resource "azurerm_synapse_firewall_rule" "allow_azure" {
  name                 = "AllowAllWindowsAzureIps"
  synapse_workspace_id = azurerm_synapse_workspace.main.id
  start_ip_address     = "0.0.0.0"
  end_ip_address       = "0.0.0.0"
}

# =============================================================================
# Synapse Dedicated SQL Pool (optional)
# =============================================================================

resource "azurerm_synapse_sql_pool" "dedicated" {
  count = var.enable_dedicated_sql_pool ? 1 : 0

  name                 = var.dedicated_pool_name
  synapse_workspace_id = azurerm_synapse_workspace.main.id
  sku_name             = var.dedicated_pool_sku
  create_mode          = "Default"

  tags = var.tags
}

# =============================================================================
# Databricks SQL Warehouse
# =============================================================================

resource "databricks_sql_endpoint" "main" {
  name             = "${var.prefix}-sql-warehouse"
  cluster_size     = var.databricks_sql_warehouse_size
  max_num_clusters = var.databricks_sql_warehouse_max_clusters
  auto_stop_mins   = var.databricks_sql_warehouse_auto_stop

  warehouse_type          = "PRO"
  enable_photon           = true
  enable_serverless_compute = var.databricks_sql_serverless

  tags {
    custom_tags {
      key   = "ManagedBy"
      value = "Terraform"
    }
  }

  depends_on = [
    azurerm_databricks_workspace.main,
  ]
}

# =============================================================================
# Private Endpoints (conditional)
# =============================================================================

# Storage Account - Blob private endpoint
resource "azurerm_private_endpoint" "storage_blob" {
  count = var.enable_private_endpoints ? 1 : 0

  name                = "${var.prefix}-pe-storage-blob"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  subnet_id           = azurerm_subnet.private_endpoints.id

  private_service_connection {
    name                           = "${var.prefix}-psc-storage-blob"
    private_connection_resource_id = azurerm_storage_account.datalake.id
    subresource_names              = ["blob"]
    is_manual_connection           = false
  }

  tags = var.tags
}

# Storage Account - DFS private endpoint
resource "azurerm_private_endpoint" "storage_dfs" {
  count = var.enable_private_endpoints ? 1 : 0

  name                = "${var.prefix}-pe-storage-dfs"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  subnet_id           = azurerm_subnet.private_endpoints.id

  private_service_connection {
    name                           = "${var.prefix}-psc-storage-dfs"
    private_connection_resource_id = azurerm_storage_account.datalake.id
    subresource_names              = ["dfs"]
    is_manual_connection           = false
  }

  tags = var.tags
}

# Key Vault private endpoint
resource "azurerm_private_endpoint" "keyvault" {
  count = var.enable_private_endpoints ? 1 : 0

  name                = "${var.prefix}-pe-keyvault"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  subnet_id           = azurerm_subnet.private_endpoints.id

  private_service_connection {
    name                           = "${var.prefix}-psc-keyvault"
    private_connection_resource_id = azurerm_key_vault.main.id
    subresource_names              = ["vault"]
    is_manual_connection           = false
  }

  tags = var.tags
}

# Synapse private endpoint (SQL)
resource "azurerm_private_endpoint" "synapse_sql" {
  count = var.enable_private_endpoints ? 1 : 0

  name                = "${var.prefix}-pe-synapse-sql"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  subnet_id           = azurerm_subnet.private_endpoints.id

  private_service_connection {
    name                           = "${var.prefix}-psc-synapse-sql"
    private_connection_resource_id = azurerm_synapse_workspace.main.id
    subresource_names              = ["Sql"]
    is_manual_connection           = false
  }

  tags = var.tags
}

# Synapse private endpoint (SqlOnDemand / serverless)
resource "azurerm_private_endpoint" "synapse_sqlondemand" {
  count = var.enable_private_endpoints ? 1 : 0

  name                = "${var.prefix}-pe-synapse-sqlod"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  subnet_id           = azurerm_subnet.private_endpoints.id

  private_service_connection {
    name                           = "${var.prefix}-psc-synapse-sqlod"
    private_connection_resource_id = azurerm_synapse_workspace.main.id
    subresource_names              = ["SqlOnDemand"]
    is_manual_connection           = false
  }

  tags = var.tags
}
