# =============================================================================
# Outputs: Joint Azure Synapse + Databricks Infrastructure
# Azure Synapse-Databricks Integration Kit
# Datanest Digital | https://datanest.dev
# =============================================================================

# =============================================================================
# Resource Group
# =============================================================================

output "resource_group_name" {
  description = "Name of the deployed resource group."
  value       = azurerm_resource_group.main.name
}

output "resource_group_id" {
  description = "Resource ID of the deployed resource group."
  value       = azurerm_resource_group.main.id
}

# =============================================================================
# Storage Account (ADLS Gen2)
# =============================================================================

output "storage_account_name" {
  description = "Name of the ADLS Gen2 storage account."
  value       = azurerm_storage_account.datalake.name
}

output "storage_account_id" {
  description = "Resource ID of the ADLS Gen2 storage account."
  value       = azurerm_storage_account.datalake.id
}

output "storage_dfs_endpoint" {
  description = "DFS endpoint for ADLS Gen2 (used in abfss:// URIs)."
  value       = azurerm_storage_account.datalake.primary_dfs_endpoint
}

output "storage_blob_endpoint" {
  description = "Blob endpoint for the storage account."
  value       = azurerm_storage_account.datalake.primary_blob_endpoint
}

output "lake_container_names" {
  description = "Names of the ADLS Gen2 containers created."
  value       = [for c in azurerm_storage_container.containers : c.name]
}

# =============================================================================
# Azure Databricks
# =============================================================================

output "databricks_workspace_name" {
  description = "Name of the Databricks workspace."
  value       = azurerm_databricks_workspace.main.name
}

output "databricks_workspace_url" {
  description = "URL of the Databricks workspace."
  value       = "https://${azurerm_databricks_workspace.main.workspace_url}"
}

output "databricks_workspace_id" {
  description = "Resource ID of the Databricks workspace."
  value       = azurerm_databricks_workspace.main.id
}

output "databricks_managed_rg" {
  description = "Name of the Databricks managed resource group."
  value       = azurerm_databricks_workspace.main.managed_resource_group_name
}

output "databricks_storage_credential_name" {
  description = "Name of the Unity Catalog storage credential."
  value       = databricks_storage_credential.datalake.name
}

output "databricks_sql_warehouse_id" {
  description = "ID of the Databricks SQL warehouse."
  value       = databricks_sql_endpoint.main.id
}

output "databricks_sql_warehouse_jdbc_url" {
  description = "JDBC URL for connecting to the Databricks SQL warehouse."
  value       = "jdbc:databricks://${azurerm_databricks_workspace.main.workspace_url}:443/default;transportMode=http;ssl=1;httpPath=${databricks_sql_endpoint.main.odbc_params[0].path}"
}

output "databricks_access_connector_id" {
  description = "Resource ID of the Databricks access connector (for Unity Catalog)."
  value       = azurerm_databricks_access_connector.main.id
}

output "databricks_storage_identity_id" {
  description = "Resource ID of the user-assigned managed identity for Databricks storage access."
  value       = azurerm_user_assigned_identity.databricks_storage.id
}

output "databricks_storage_identity_client_id" {
  description = "Client ID of the Databricks storage managed identity."
  value       = azurerm_user_assigned_identity.databricks_storage.client_id
}

# =============================================================================
# Azure Synapse
# =============================================================================

output "synapse_workspace_name" {
  description = "Name of the Synapse workspace."
  value       = azurerm_synapse_workspace.main.name
}

output "synapse_workspace_id" {
  description = "Resource ID of the Synapse workspace."
  value       = azurerm_synapse_workspace.main.id
}

output "synapse_serverless_endpoint" {
  description = "Serverless SQL endpoint for the Synapse workspace."
  value       = "${azurerm_synapse_workspace.main.name}-ondemand.sql.azuresynapse.net"
}

output "synapse_dedicated_endpoint" {
  description = "Dedicated SQL endpoint for the Synapse workspace."
  value       = "${azurerm_synapse_workspace.main.name}.sql.azuresynapse.net"
}

output "synapse_managed_identity_principal_id" {
  description = "Principal ID of the Synapse workspace managed identity."
  value       = azurerm_synapse_workspace.main.identity[0].principal_id
}

output "synapse_dedicated_pool_name" {
  description = "Name of the Synapse dedicated SQL pool (if enabled)."
  value       = var.enable_dedicated_sql_pool ? azurerm_synapse_sql_pool.dedicated[0].name : "Not deployed"
}

# =============================================================================
# Key Vault
# =============================================================================

output "key_vault_name" {
  description = "Name of the Azure Key Vault."
  value       = azurerm_key_vault.main.name
}

output "key_vault_uri" {
  description = "URI of the Azure Key Vault."
  value       = azurerm_key_vault.main.vault_uri
}

# =============================================================================
# Networking
# =============================================================================

output "vnet_id" {
  description = "Resource ID of the virtual network."
  value       = azurerm_virtual_network.main.id
}

output "vnet_name" {
  description = "Name of the virtual network."
  value       = azurerm_virtual_network.main.name
}

output "private_endpoint_subnet_id" {
  description = "Subnet ID for private endpoints."
  value       = azurerm_subnet.private_endpoints.id
}

# =============================================================================
# Connection Strings (for downstream configuration)
# =============================================================================

output "synapse_serverless_connection_string" {
  description = "ADO.NET connection string template for Synapse serverless SQL."
  value       = "Server=tcp:${azurerm_synapse_workspace.main.name}-ondemand.sql.azuresynapse.net,1433;Database=delta_lakehouse;Authentication=Active Directory Default;Encrypt=True;TrustServerCertificate=False;"
}

output "adls_abfss_prefix" {
  description = "ABFSS URI prefix for accessing the data lake (append container/path)."
  value       = "abfss://<container>@${azurerm_storage_account.datalake.name}.dfs.core.windows.net/"
}
