#!/usr/bin/env python3
"""
Cost Comparison Calculator: Azure Synapse vs Databricks
Azure Synapse-Databricks Integration Kit
Datanest Digital | https://datanest.dev

CLI tool that compares estimated monthly costs for common workloads across
Azure Synapse Analytics and Azure Databricks. Uses Azure public pricing as
of early 2025. Actual costs vary by region, EA/CSP agreements, and reserved
capacity.

Usage:
    python cost_comparison_calculator.py compare --data-volume-tb 10 --daily-queries 500 --etl-hours 8
    python cost_comparison_calculator.py breakdown --workload etl --hours-per-day 6 --cluster-nodes 4
    python cost_comparison_calculator.py --help
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field, asdict
from typing import Optional


# =============================================================================
# Pricing Constants (East US 2, Pay-As-You-Go, as of early 2025)
# Adjust these for your region and agreement type.
# =============================================================================

PRICING = {
    # Synapse Serverless SQL: per TB scanned
    "synapse_serverless_per_tb": 5.00,
    # Synapse Dedicated SQL Pool: per DWU per hour
    "synapse_dedicated_dwu_per_hour": {
        "DW100c": 1.20,
        "DW200c": 2.40,
        "DW500c": 6.00,
        "DW1000c": 12.00,
        "DW2000c": 24.00,
        "DW3000c": 36.00,
        "DW5000c": 60.00,
    },
    # Synapse Spark Pool: per vCore per hour
    "synapse_spark_per_vcore_hour": 0.16,
    # Databricks: DBU prices (per DBU per hour)
    "databricks_jobs_dbu": 0.15,       # Jobs Compute
    "databricks_all_purpose_dbu": 0.40, # All-Purpose (interactive)
    "databricks_sql_pro_dbu": 0.22,    # SQL Pro
    "databricks_sql_serverless_dbu": 0.70,  # SQL Serverless
    # Databricks: DBUs per hour by cluster size (approximate for Standard_DS4_v2)
    "databricks_dbus_per_node_hour": 2.0,
    # Azure VM costs (Standard_DS4_v2 - typical Spark worker)
    "azure_vm_ds4v2_per_hour": 0.192,
    # Storage: ADLS Gen2 per GB per month
    "adls_storage_per_gb_month": 0.018,
    # Storage: transactions per 10,000
    "adls_read_per_10k": 0.004,
    "adls_write_per_10k": 0.05,
}

HOURS_PER_MONTH = 730  # Average hours in a month


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class WorkloadProfile:
    """Defines a workload for cost comparison."""
    data_volume_tb: float = 1.0
    daily_queries: int = 100
    avg_scan_per_query_gb: float = 10.0
    etl_hours_per_day: int = 4
    etl_cluster_nodes: int = 4
    sql_warehouse_hours_per_day: float = 10.0
    dedicated_pool_sku: str = "DW500c"
    dedicated_pool_hours_per_day: float = 12.0
    spark_vcores_per_node: int = 4
    storage_tb: float = 10.0
    monthly_read_transactions_millions: float = 5.0
    monthly_write_transactions_millions: float = 1.0


@dataclass
class CostEstimate:
    """Monthly cost estimate for a single service configuration."""
    service: str
    workload_type: str
    monthly_cost: float
    cost_components: dict = field(default_factory=dict)
    notes: list = field(default_factory=list)


@dataclass
class ComparisonResult:
    """Side-by-side comparison of Synapse vs Databricks costs."""
    workload_profile: dict
    synapse_estimates: list[dict] = field(default_factory=list)
    databricks_estimates: list[dict] = field(default_factory=list)
    synapse_total: float = 0.0
    databricks_total: float = 0.0
    combined_optimal_total: float = 0.0
    recommendations: list[str] = field(default_factory=list)


# =============================================================================
# Cost Calculators
# =============================================================================

def estimate_synapse_serverless(
    daily_queries: int,
    avg_scan_per_query_gb: float,
) -> CostEstimate:
    """Estimate Synapse serverless SQL monthly cost."""
    monthly_queries = daily_queries * 30
    monthly_scan_tb = (monthly_queries * avg_scan_per_query_gb) / 1024.0
    monthly_cost = monthly_scan_tb * PRICING["synapse_serverless_per_tb"]

    return CostEstimate(
        service="Synapse Serverless SQL",
        workload_type="Ad-hoc / BI Queries",
        monthly_cost=round(monthly_cost, 2),
        cost_components={
            "monthly_queries": monthly_queries,
            "monthly_scan_tb": round(monthly_scan_tb, 2),
            "price_per_tb": PRICING["synapse_serverless_per_tb"],
        },
        notes=[
            "Cost scales with data scanned, not cluster time.",
            "Partition pruning reduces scan volume significantly.",
            "Zero cost when idle.",
        ],
    )


def estimate_synapse_dedicated(
    sku: str,
    hours_per_day: float,
) -> CostEstimate:
    """Estimate Synapse dedicated SQL pool monthly cost."""
    price_per_hour = PRICING["synapse_dedicated_dwu_per_hour"].get(sku, 12.0)
    monthly_hours = hours_per_day * 30
    monthly_cost = monthly_hours * price_per_hour

    return CostEstimate(
        service="Synapse Dedicated SQL Pool",
        workload_type="Data Warehousing",
        monthly_cost=round(monthly_cost, 2),
        cost_components={
            "sku": sku,
            "price_per_hour": price_per_hour,
            "hours_per_day": hours_per_day,
            "monthly_hours": monthly_hours,
        },
        notes=[
            f"Based on {sku} running {hours_per_day}h/day.",
            "Implement pause/resume to reduce costs during off-hours.",
            "Reserved capacity (1yr/3yr) can save 40-65%.",
        ],
    )


def estimate_synapse_spark(
    hours_per_day: int,
    cluster_nodes: int,
    vcores_per_node: int,
) -> CostEstimate:
    """Estimate Synapse Spark pool monthly cost."""
    total_vcores = cluster_nodes * vcores_per_node
    monthly_hours = hours_per_day * 30
    compute_cost = monthly_hours * total_vcores * PRICING["synapse_spark_per_vcore_hour"]

    return CostEstimate(
        service="Synapse Spark Pool",
        workload_type="ETL / Spark Processing",
        monthly_cost=round(compute_cost, 2),
        cost_components={
            "cluster_nodes": cluster_nodes,
            "vcores_per_node": vcores_per_node,
            "total_vcores": total_vcores,
            "hours_per_day": hours_per_day,
            "monthly_hours": monthly_hours,
            "price_per_vcore_hour": PRICING["synapse_spark_per_vcore_hour"],
        },
        notes=[
            "Synapse Spark pools charge per vCore-hour.",
            "No Photon acceleration available.",
            "Consider migrating to Databricks for heavy Spark workloads.",
        ],
    )


def estimate_databricks_jobs(
    hours_per_day: int,
    cluster_nodes: int,
) -> CostEstimate:
    """Estimate Databricks Jobs Compute monthly cost (ETL workloads)."""
    monthly_hours = hours_per_day * 30
    # VM cost + DBU cost
    vm_cost = monthly_hours * cluster_nodes * PRICING["azure_vm_ds4v2_per_hour"]
    dbu_cost = (
        monthly_hours
        * cluster_nodes
        * PRICING["databricks_dbus_per_node_hour"]
        * PRICING["databricks_jobs_dbu"]
    )
    total = vm_cost + dbu_cost

    return CostEstimate(
        service="Databricks Jobs Compute",
        workload_type="ETL / Spark Processing",
        monthly_cost=round(total, 2),
        cost_components={
            "cluster_nodes": cluster_nodes,
            "hours_per_day": hours_per_day,
            "monthly_hours": monthly_hours,
            "vm_cost": round(vm_cost, 2),
            "dbu_cost": round(dbu_cost, 2),
            "dbu_rate": PRICING["databricks_jobs_dbu"],
        },
        notes=[
            "Jobs compute is cheaper than All-Purpose for scheduled ETL.",
            "Photon engine can reduce runtime 2-8x on Delta Lake.",
            "Spot instances can reduce VM costs by 60-80%.",
        ],
    )


def estimate_databricks_sql(
    hours_per_day: float,
    size_dbus_per_hour: float = 10.0,
    serverless: bool = False,
) -> CostEstimate:
    """Estimate Databricks SQL warehouse monthly cost."""
    monthly_hours = hours_per_day * 30
    dbu_rate = (
        PRICING["databricks_sql_serverless_dbu"]
        if serverless
        else PRICING["databricks_sql_pro_dbu"]
    )
    dbu_cost = monthly_hours * size_dbus_per_hour * dbu_rate

    # SQL Pro also has VM costs; serverless does not
    vm_cost = 0.0
    if not serverless:
        # Approximate VM cost for a "Small" SQL warehouse
        vm_cost = monthly_hours * 2 * PRICING["azure_vm_ds4v2_per_hour"]

    total = dbu_cost + vm_cost

    warehouse_type = "Serverless" if serverless else "Pro"

    return CostEstimate(
        service=f"Databricks SQL Warehouse ({warehouse_type})",
        workload_type="SQL Analytics / BI Queries",
        monthly_cost=round(total, 2),
        cost_components={
            "warehouse_type": warehouse_type,
            "hours_per_day": hours_per_day,
            "monthly_hours": monthly_hours,
            "dbus_per_hour": size_dbus_per_hour,
            "dbu_rate": dbu_rate,
            "dbu_cost": round(dbu_cost, 2),
            "vm_cost": round(vm_cost, 2),
        },
        notes=[
            "Serverless SQL warehouses have higher DBU cost but zero VM cost.",
            f"Auto-stop reduces cost when warehouse is idle.",
            "DirectQuery from Power BI keeps the warehouse active during business hours.",
        ],
    )


def estimate_storage(
    storage_tb: float,
    read_transactions_millions: float,
    write_transactions_millions: float,
) -> CostEstimate:
    """Estimate ADLS Gen2 storage cost (shared between services)."""
    storage_gb = storage_tb * 1024
    storage_cost = storage_gb * PRICING["adls_storage_per_gb_month"]
    read_cost = (read_transactions_millions * 1_000_000 / 10_000) * PRICING["adls_read_per_10k"]
    write_cost = (write_transactions_millions * 1_000_000 / 10_000) * PRICING["adls_write_per_10k"]
    total = storage_cost + read_cost + write_cost

    return CostEstimate(
        service="ADLS Gen2 Storage",
        workload_type="Data Lake Storage",
        monthly_cost=round(total, 2),
        cost_components={
            "storage_tb": storage_tb,
            "storage_cost": round(storage_cost, 2),
            "read_transactions_m": read_transactions_millions,
            "read_cost": round(read_cost, 2),
            "write_transactions_m": write_transactions_millions,
            "write_cost": round(write_cost, 2),
        },
        notes=[
            "Storage cost is shared between Synapse and Databricks.",
            "Delta Lake VACUUM reduces storage of old versions.",
            "Consider lifecycle management policies for bronze data.",
        ],
    )


# =============================================================================
# Comparison Engine
# =============================================================================

def compare_workloads(profile: WorkloadProfile) -> ComparisonResult:
    """Run full cost comparison between Synapse and Databricks."""
    result = ComparisonResult(workload_profile=asdict(profile))

    # --- Synapse Estimates ---
    synapse_serverless = estimate_synapse_serverless(
        daily_queries=profile.daily_queries,
        avg_scan_per_query_gb=profile.avg_scan_per_query_gb,
    )
    result.synapse_estimates.append(asdict(synapse_serverless))

    synapse_dedicated = estimate_synapse_dedicated(
        sku=profile.dedicated_pool_sku,
        hours_per_day=profile.dedicated_pool_hours_per_day,
    )
    result.synapse_estimates.append(asdict(synapse_dedicated))

    synapse_spark = estimate_synapse_spark(
        hours_per_day=profile.etl_hours_per_day,
        cluster_nodes=profile.etl_cluster_nodes,
        vcores_per_node=profile.spark_vcores_per_node,
    )
    result.synapse_estimates.append(asdict(synapse_spark))

    # --- Databricks Estimates ---
    dbx_jobs = estimate_databricks_jobs(
        hours_per_day=profile.etl_hours_per_day,
        cluster_nodes=profile.etl_cluster_nodes,
    )
    result.databricks_estimates.append(asdict(dbx_jobs))

    dbx_sql_pro = estimate_databricks_sql(
        hours_per_day=profile.sql_warehouse_hours_per_day,
        serverless=False,
    )
    result.databricks_estimates.append(asdict(dbx_sql_pro))

    dbx_sql_serverless = estimate_databricks_sql(
        hours_per_day=profile.sql_warehouse_hours_per_day,
        serverless=True,
    )
    result.databricks_estimates.append(asdict(dbx_sql_serverless))

    # --- Shared: Storage ---
    storage = estimate_storage(
        storage_tb=profile.storage_tb,
        read_transactions_millions=profile.monthly_read_transactions_millions,
        write_transactions_millions=profile.monthly_write_transactions_millions,
    )

    # --- Totals ---
    result.synapse_total = round(
        synapse_serverless.monthly_cost
        + synapse_dedicated.monthly_cost
        + synapse_spark.monthly_cost
        + storage.monthly_cost,
        2,
    )

    result.databricks_total = round(
        dbx_jobs.monthly_cost
        + dbx_sql_pro.monthly_cost
        + storage.monthly_cost,
        2,
    )

    # --- Combined Optimal ---
    # Use whichever is cheaper for each workload category
    optimal_etl = min(synapse_spark.monthly_cost, dbx_jobs.monthly_cost)
    optimal_sql = min(
        synapse_serverless.monthly_cost + synapse_dedicated.monthly_cost,
        dbx_sql_pro.monthly_cost,
    )
    result.combined_optimal_total = round(optimal_etl + optimal_sql + storage.monthly_cost, 2)

    # --- Recommendations ---
    if dbx_jobs.monthly_cost < synapse_spark.monthly_cost:
        savings = synapse_spark.monthly_cost - dbx_jobs.monthly_cost
        result.recommendations.append(
            f"ETL: Databricks Jobs saves ${savings:,.0f}/month vs Synapse Spark."
        )
    else:
        savings = dbx_jobs.monthly_cost - synapse_spark.monthly_cost
        result.recommendations.append(
            f"ETL: Synapse Spark saves ${savings:,.0f}/month vs Databricks Jobs."
        )

    if synapse_serverless.monthly_cost < dbx_sql_pro.monthly_cost:
        savings = dbx_sql_pro.monthly_cost - synapse_serverless.monthly_cost
        result.recommendations.append(
            f"Ad-hoc SQL: Synapse Serverless saves ${savings:,.0f}/month vs Databricks SQL Pro."
        )
    else:
        savings = synapse_serverless.monthly_cost - dbx_sql_pro.monthly_cost
        result.recommendations.append(
            f"Ad-hoc SQL: Databricks SQL Pro saves ${savings:,.0f}/month vs Synapse Serverless."
        )

    result.recommendations.append(
        f"Combined optimal architecture: ${result.combined_optimal_total:,.0f}/month "
        f"(vs ${result.synapse_total:,.0f} all-Synapse, ${result.databricks_total:,.0f} all-Databricks)."
    )

    if profile.etl_hours_per_day >= 4:
        result.recommendations.append(
            "With 4+ hours/day Spark ETL, Databricks Photon typically provides 2-4x throughput improvement."
        )

    if profile.daily_queries < 50 and profile.avg_scan_per_query_gb < 50:
        result.recommendations.append(
            "Low query volume with small scans: Synapse Serverless is most cost-effective for ad-hoc queries."
        )

    return result


# =============================================================================
# CLI Formatting
# =============================================================================

def format_currency(amount: float) -> str:
    """Format a number as USD currency."""
    return f"${amount:,.2f}"


def print_comparison(result: ComparisonResult) -> None:
    """Print formatted comparison to stdout."""
    print("=" * 72)
    print("  COST COMPARISON: Azure Synapse vs Databricks")
    print("  Datanest Digital | https://datanest.dev")
    print("=" * 72)
    print()

    wp = result.workload_profile
    print("WORKLOAD PROFILE:")
    print(f"  Data volume:         {wp['data_volume_tb']} TB")
    print(f"  Daily queries:       {wp['daily_queries']}")
    print(f"  Avg scan/query:      {wp['avg_scan_per_query_gb']} GB")
    print(f"  ETL hours/day:       {wp['etl_hours_per_day']}")
    print(f"  ETL cluster nodes:   {wp['etl_cluster_nodes']}")
    print(f"  SQL warehouse hours: {wp['sql_warehouse_hours_per_day']}")
    print(f"  Dedicated pool SKU:  {wp['dedicated_pool_sku']}")
    print(f"  Storage:             {wp['storage_tb']} TB")
    print()

    print("-" * 72)
    print("SYNAPSE ESTIMATES (Monthly):")
    print("-" * 72)
    for est in result.synapse_estimates:
        print(f"  {est['service']:40s} {format_currency(est['monthly_cost']):>12s}")
        for note in est.get("notes", []):
            print(f"    - {note}")
        print()

    print("-" * 72)
    print("DATABRICKS ESTIMATES (Monthly):")
    print("-" * 72)
    for est in result.databricks_estimates:
        print(f"  {est['service']:40s} {format_currency(est['monthly_cost']):>12s}")
        for note in est.get("notes", []):
            print(f"    - {note}")
        print()

    print("=" * 72)
    print("TOTALS (Monthly):")
    print(f"  All-Synapse:            {format_currency(result.synapse_total):>12s}")
    print(f"  All-Databricks:         {format_currency(result.databricks_total):>12s}")
    print(f"  Combined Optimal:       {format_currency(result.combined_optimal_total):>12s}")
    print("=" * 72)
    print()

    print("RECOMMENDATIONS:")
    for rec in result.recommendations:
        print(f"  * {rec}")
    print()


def print_breakdown(estimate: CostEstimate) -> None:
    """Print a single workload cost breakdown."""
    print("=" * 60)
    print(f"  {estimate.service}")
    print(f"  Workload: {estimate.workload_type}")
    print("=" * 60)
    print(f"  Monthly Cost: {format_currency(estimate.monthly_cost)}")
    print()
    print("  Components:")
    for key, value in estimate.cost_components.items():
        if isinstance(value, float):
            print(f"    {key:30s}: {value:>12.2f}")
        else:
            print(f"    {key:30s}: {str(value):>12s}")
    print()
    print("  Notes:")
    for note in estimate.notes:
        print(f"    - {note}")
    print()


# =============================================================================
# CLI Entry Point
# =============================================================================

def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser."""
    parser = argparse.ArgumentParser(
        description="Cost Comparison Calculator: Azure Synapse vs Databricks",
        epilog="Datanest Digital | https://datanest.dev",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- compare command ---
    compare_parser = subparsers.add_parser(
        "compare", help="Full cost comparison between Synapse and Databricks"
    )
    compare_parser.add_argument("--data-volume-tb", type=float, default=1.0, help="Total data volume in TB")
    compare_parser.add_argument("--daily-queries", type=int, default=100, help="Average daily SQL queries")
    compare_parser.add_argument("--avg-scan-gb", type=float, default=10.0, help="Average data scanned per query in GB")
    compare_parser.add_argument("--etl-hours", type=int, default=4, help="Daily ETL/Spark processing hours")
    compare_parser.add_argument("--etl-nodes", type=int, default=4, help="Number of Spark cluster nodes")
    compare_parser.add_argument("--sql-hours", type=float, default=10.0, help="Daily SQL warehouse active hours")
    compare_parser.add_argument("--dedicated-sku", type=str, default="DW500c", help="Synapse dedicated pool SKU")
    compare_parser.add_argument("--dedicated-hours", type=float, default=12.0, help="Daily dedicated pool active hours")
    compare_parser.add_argument("--storage-tb", type=float, default=10.0, help="Total ADLS storage in TB")
    compare_parser.add_argument("--json", action="store_true", help="Output in JSON format")

    # --- breakdown command ---
    breakdown_parser = subparsers.add_parser(
        "breakdown", help="Detailed cost breakdown for a single workload"
    )
    breakdown_parser.add_argument(
        "--workload",
        required=True,
        choices=[
            "synapse-serverless", "synapse-dedicated", "synapse-spark",
            "databricks-jobs", "databricks-sql-pro", "databricks-sql-serverless",
            "storage",
        ],
        help="Workload type to analyze",
    )
    breakdown_parser.add_argument("--hours-per-day", type=float, default=8.0)
    breakdown_parser.add_argument("--cluster-nodes", type=int, default=4)
    breakdown_parser.add_argument("--daily-queries", type=int, default=100)
    breakdown_parser.add_argument("--avg-scan-gb", type=float, default=10.0)
    breakdown_parser.add_argument("--dedicated-sku", type=str, default="DW500c")
    breakdown_parser.add_argument("--storage-tb", type=float, default=10.0)
    breakdown_parser.add_argument("--json", action="store_true", help="Output in JSON format")

    return parser


def main() -> None:
    """Main entry point."""
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "compare":
        profile = WorkloadProfile(
            data_volume_tb=args.data_volume_tb,
            daily_queries=args.daily_queries,
            avg_scan_per_query_gb=args.avg_scan_gb,
            etl_hours_per_day=args.etl_hours,
            etl_cluster_nodes=args.etl_nodes,
            sql_warehouse_hours_per_day=args.sql_hours,
            dedicated_pool_sku=args.dedicated_sku,
            dedicated_pool_hours_per_day=args.dedicated_hours,
            storage_tb=args.storage_tb,
        )
        result = compare_workloads(profile)

        if args.json:
            print(json.dumps(asdict(result), indent=2))
        else:
            print_comparison(result)

    elif args.command == "breakdown":
        estimate: Optional[CostEstimate] = None

        if args.workload == "synapse-serverless":
            estimate = estimate_synapse_serverless(args.daily_queries, args.avg_scan_gb)
        elif args.workload == "synapse-dedicated":
            estimate = estimate_synapse_dedicated(args.dedicated_sku, args.hours_per_day)
        elif args.workload == "synapse-spark":
            estimate = estimate_synapse_spark(int(args.hours_per_day), args.cluster_nodes, 4)
        elif args.workload == "databricks-jobs":
            estimate = estimate_databricks_jobs(int(args.hours_per_day), args.cluster_nodes)
        elif args.workload == "databricks-sql-pro":
            estimate = estimate_databricks_sql(args.hours_per_day, serverless=False)
        elif args.workload == "databricks-sql-serverless":
            estimate = estimate_databricks_sql(args.hours_per_day, serverless=True)
        elif args.workload == "storage":
            estimate = estimate_storage(args.storage_tb, 5.0, 1.0)

        if estimate:
            if args.json:
                print(json.dumps(asdict(estimate), indent=2))
            else:
                print_breakdown(estimate)


if __name__ == "__main__":
    main()
