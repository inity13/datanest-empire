# Cross-Service Authentication Patterns: Synapse & Databricks

**Datanest Digital** | [datanest.dev](https://datanest.dev)

---

## Overview

This guide covers authentication and authorization patterns for environments running
both Azure Synapse Analytics and Azure Databricks. The goal is to eliminate stored
credentials wherever possible using Azure Managed Identity, service principals,
and Unity Catalog.

---

## Authentication Architecture

```
                        +-------------------+
                        | Azure AD (Entra)  |
                        +--------+----------+
                                 |
            +--------------------+--------------------+
            |                    |                    |
   +--------v--------+  +-------v--------+  +--------v--------+
   | Managed Identity |  | Service        |  | User Identity   |
   | (System/User)    |  | Principal      |  | (Interactive)   |
   +--------+---------+  +-------+--------+  +--------+--------+
            |                    |                    |
   +--------v---------+  +------v---------+  +-------v---------+
   | Synapse Workspace |  | Databricks     |  | Power BI /      |
   | ADLS Gen2 Access  |  | Workspace      |  | Dev Tools       |
   +-------------------+  +----------------+  +-----------------+
```

---

## Pattern 1: Managed Identity for ADLS Gen2 (Shared Storage)

Both Synapse and Databricks access ADLS Gen2. Use Managed Identity to avoid storage keys.

### Synapse Workspace Managed Identity

Synapse creates a system-assigned managed identity automatically.

**Grant ADLS Gen2 access:**

```bash
# Get Synapse workspace managed identity object ID
SYNAPSE_MI=$(az synapse workspace show \
    --name <synapse-workspace> \
    --resource-group <rg> \
    --query identity.principalId -o tsv)

# Assign Storage Blob Data Contributor on the storage account
az role assignment create \
    --assignee-object-id "$SYNAPSE_MI" \
    --assignee-principal-type ServicePrincipal \
    --role "Storage Blob Data Contributor" \
    --scope "/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Storage/storageAccounts/<storage>"
```

**Use in Synapse serverless SQL:**

```sql
-- No credentials needed when using workspace managed identity
CREATE DATABASE SCOPED CREDENTIAL WorkspaceIdentity
WITH IDENTITY = 'Managed Identity';

CREATE EXTERNAL DATA SOURCE DeltaLake
WITH (
    LOCATION = 'abfss://datalake@<storage>.dfs.core.windows.net/',
    CREDENTIAL = WorkspaceIdentity
);
```

### Databricks with User-Assigned Managed Identity

For Databricks, use a user-assigned managed identity via Unity Catalog storage credentials.

**Create the managed identity:**

```bash
# Create user-assigned managed identity
az identity create \
    --name databricks-storage-identity \
    --resource-group <rg>

# Get the identity details
IDENTITY_ID=$(az identity show \
    --name databricks-storage-identity \
    --resource-group <rg> \
    --query id -o tsv)

CLIENT_ID=$(az identity show \
    --name databricks-storage-identity \
    --resource-group <rg> \
    --query clientId -o tsv)

# Assign Storage Blob Data Contributor
az role assignment create \
    --assignee "$CLIENT_ID" \
    --role "Storage Blob Data Contributor" \
    --scope "/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Storage/storageAccounts/<storage>"
```

**Register in Unity Catalog:**

```sql
-- Create storage credential using the managed identity
CREATE STORAGE CREDENTIAL adls_managed_identity
WITH (AZURE_MANAGED_IDENTITY = '<IDENTITY_ID>');

-- Create external location
CREATE EXTERNAL LOCATION datalake_root
URL 'abfss://datalake@<storage>.dfs.core.windows.net/'
WITH (STORAGE CREDENTIAL adls_managed_identity);

-- Grant access to specific groups
GRANT READ FILES ON EXTERNAL LOCATION datalake_root TO `data_engineers`;
GRANT WRITE FILES ON EXTERNAL LOCATION datalake_root TO `data_engineers`;
```

---

## Pattern 2: Service Principal for Cross-Service API Calls

When Synapse pipelines need to trigger Databricks jobs or vice versa, use a service
principal.

### Create the Service Principal

```bash
# Create service principal
az ad sp create-for-rbac \
    --name "synapse-databricks-integration" \
    --role "Contributor" \
    --scopes "/subscriptions/<sub>/resourceGroups/<rg>"

# Output:
# {
#   "appId": "<client-id>",
#   "password": "<client-secret>",
#   "tenant": "<tenant-id>"
# }
```

### Store Credentials in Key Vault

```bash
# Create Key Vault (if not exists)
az keyvault create \
    --name <kv-name> \
    --resource-group <rg>

# Store the service principal secret
az keyvault secret set \
    --vault-name <kv-name> \
    --name "sp-databricks-secret" \
    --value "<client-secret>"

# Grant Synapse managed identity access to Key Vault
az keyvault set-policy \
    --name <kv-name> \
    --object-id "$SYNAPSE_MI" \
    --secret-permissions get list
```

### Synapse Pipeline Calling Databricks

In Synapse Pipeline, create a Databricks linked service using the service principal:

```json
{
    "name": "DatabricksLinkedService",
    "type": "AzureDatabricks",
    "typeProperties": {
        "domain": "https://adb-<workspace-id>.azuredatabricks.net",
        "authentication": "MSI",
        "workspaceResourceId": "/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Databricks/workspaces/<workspace>"
    }
}
```

### Databricks Calling Synapse SQL

```python
# In a Databricks notebook -- use service principal for Synapse SQL access

from pyspark.sql import SparkSession
import adal

# Get token for Synapse SQL
authority = "https://login.microsoftonline.com/<tenant-id>"
resource = "https://database.windows.net/"

client_id = dbutils.secrets.get(scope="integration", key="sp-client-id")
client_secret = dbutils.secrets.get(scope="integration", key="sp-client-secret")

context = adal.AuthenticationContext(authority)
token = context.acquire_token_with_client_credentials(
    resource, client_id, client_secret
)
access_token = token["accessToken"]

# Read from Synapse dedicated pool
jdbc_url = (
    "jdbc:sqlserver://<synapse>.sql.azuresynapse.net:1433;"
    "database=<dedicated_pool>;"
    "encrypt=true;"
    "trustServerCertificate=false;"
    "hostNameInCertificate=*.sql.azuresynapse.net;"
    "loginTimeout=30"
)

df = spark.read.jdbc(
    url=jdbc_url,
    table="schema_name.table_name",
    properties={"accessToken": access_token}
)
```

---

## Pattern 3: Synapse Serverless Accessing Databricks-Managed Delta Tables

This is the most common integration pattern. Synapse serverless queries Delta Lake
tables that Databricks manages.

### Authentication Flow

```
Synapse Serverless Query
    |
    v
Workspace Managed Identity (or database-scoped credential)
    |
    v
ADLS Gen2 (reads Delta Lake files directly)
```

### Setup

```sql
-- Step 1: Create master key (one-time)
CREATE MASTER KEY ENCRYPTION BY PASSWORD = '<strong-password>';

-- Step 2: Credential using workspace identity
CREATE DATABASE SCOPED CREDENTIAL ManagedIdentityCredential
WITH IDENTITY = 'Managed Identity';

-- Step 3: External data source pointing to Delta Lake root
CREATE EXTERNAL DATA SOURCE DatabricksDeltaLake
WITH (
    LOCATION = 'abfss://gold@<storage>.dfs.core.windows.net/',
    CREDENTIAL = ManagedIdentityCredential
);

-- Step 4: Query Delta tables
SELECT *
FROM OPENROWSET(
    BULK 'customers/',
    DATA_SOURCE = 'DatabricksDeltaLake',
    FORMAT = 'DELTA'
) AS customers;
```

### Permissions Required

The Synapse workspace managed identity needs:
- `Storage Blob Data Reader` on the ADLS Gen2 account (minimum for read)
- `Storage Blob Data Contributor` if Synapse also writes to the lake

---

## Pattern 4: Unity Catalog and Synapse Alignment

Unity Catalog governs access in Databricks. Synapse does not read Unity Catalog
directly, but you can align access patterns.

### Approach: Parallel Permission Model

```
Unity Catalog (Databricks side)          Synapse (SQL side)
├── catalog.schema.table                 ├── CREATE VIEW over Delta path
│   GRANT SELECT TO group_a              │   GRANT SELECT TO synapse_role
│                                        │
├── catalog.schema.sensitive_table       ├── No view created (blocked)
│   GRANT SELECT TO group_b only         │
```

### Automation: Sync Unity Catalog Grants to Synapse Views

```python
# Conceptual approach: generate Synapse view DDL from Unity Catalog metadata
# Run this in Databricks to produce Synapse SQL scripts

tables = spark.sql("""
    SELECT table_catalog, table_schema, table_name, table_type,
           storage_path
    FROM system.information_schema.tables
    WHERE table_catalog = 'production'
      AND table_schema = 'gold'
      AND table_type = 'EXTERNAL'
""").collect()

for table in tables:
    view_ddl = f"""
    CREATE OR ALTER VIEW [{table.table_schema}].[{table.table_name}]
    AS SELECT *
    FROM OPENROWSET(
        BULK '{table.table_name}/',
        DATA_SOURCE = 'DatabricksDeltaLake',
        FORMAT = 'DELTA'
    ) AS [{table.table_name}];
    """
    print(view_ddl)
```

---

## Pattern 5: Private Endpoint Connectivity

For production environments, both services should use private endpoints.

### Network Architecture

```
VNET (Hub)
├── Subnet: private-endpoints
│   ├── Synapse private endpoint (SQL)
│   ├── Synapse private endpoint (Dev)
│   ├── Databricks private endpoint (workspace)
│   ├── ADLS Gen2 private endpoint (blob, dfs)
│   └── Key Vault private endpoint
│
├── Subnet: databricks-host (delegated)
│   └── Databricks cluster driver/worker nodes
│
└── Subnet: databricks-container (delegated)
    └── Databricks cluster containers
```

### Key Configuration

```hcl
# See terraform/synapse-databricks/main.tf for full implementation

# Databricks requires two dedicated subnets
# Synapse requires private link hubs for Studio access
# ADLS Gen2 requires both blob and dfs private endpoints
# Key Vault private endpoint for secret access
```

---

## Security Checklist

### Storage Layer
- [ ] ADLS Gen2 firewall enabled, public access disabled
- [ ] Private endpoints configured for blob and dfs
- [ ] Storage keys rotated and not used in application code
- [ ] Managed Identity used for both Synapse and Databricks access
- [ ] RBAC roles are scoped to specific containers, not the full account

### Synapse
- [ ] Workspace managed identity enabled
- [ ] Serverless SQL uses database-scoped credentials (not SAS tokens)
- [ ] Dedicated pool uses AAD authentication
- [ ] Synapse Studio access via private link hub
- [ ] Data exfiltration protection enabled

### Databricks
- [ ] Unity Catalog enabled with external storage credentials
- [ ] No storage keys in cluster Spark config
- [ ] Secret scopes backed by Azure Key Vault
- [ ] Cluster policies enforced (no credential passthrough without approval)
- [ ] IP access lists configured for workspace access

### Cross-Service
- [ ] Service principal credentials stored in Key Vault only
- [ ] Key Vault access policies follow least privilege
- [ ] No shared storage keys between services
- [ ] Audit logging enabled on Key Vault, ADLS, Synapse, and Databricks
- [ ] Network connectivity uses private endpoints end-to-end

---

*Datanest Digital -- [datanest.dev](https://datanest.dev)*
