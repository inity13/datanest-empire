# Migration Guide: Synapse Spark Pools to Azure Databricks

**Datanest Digital** | [datanest.dev](https://datanest.dev)

---

## Overview

This guide covers the end-to-end migration from Azure Synapse Spark pools to Azure
Databricks. The migration preserves your existing data in ADLS Gen2 (no data movement
required) and focuses on compute, code, and orchestration changes.

---

## Migration Phases

```
Phase 1: Assessment & Planning        (1-2 weeks)
Phase 2: Infrastructure Provisioning   (1 week)
Phase 3: Code Migration               (2-4 weeks)
Phase 4: Orchestration Migration       (1-2 weeks)
Phase 5: Validation & Cutover         (1-2 weeks)
```

---

## Phase 1: Assessment & Planning

### 1.1 Inventory Current Synapse Spark Assets

Catalog every Spark asset in your Synapse workspace:

| Asset Type | Count | Migration Complexity |
|-----------|-------|---------------------|
| Spark notebooks | | Low-Medium |
| Spark job definitions | | Medium |
| Spark pools (configurations) | | Low |
| Linked services (Spark-related) | | Medium |
| Synapse pipeline Spark activities | | Medium |
| Spark SQL databases/tables | | Low |
| Custom libraries (.whl, .jar) | | Low |
| Spark configurations | | Low |

### 1.2 Identify Synapse-Specific APIs

Search your notebooks for Synapse-specific APIs that need translation:

| Synapse API | Databricks Equivalent |
|------------|----------------------|
| `mssparkutils.fs.*` | `dbutils.fs.*` |
| `mssparkutils.notebook.run()` | `dbutils.notebook.run()` |
| `mssparkutils.credentials.getSecret()` | `dbutils.secrets.get()` |
| `mssparkutils.env.getWorkspaceName()` | `spark.conf.get("spark.databricks.workspaceUrl")` |
| `spark.read.synapsesql()` | JDBC connection or lakehouse tables |
| `df.write.synapsesql()` | JDBC connection or lakehouse tables |
| `TokenLibrary.getConnectionString()` | `dbutils.secrets.get()` or Unity Catalog connections |
| Synapse linked service references | Databricks secrets or Unity Catalog |

### 1.3 Assess Spark Pool Configurations

Map each Synapse Spark pool to a Databricks cluster configuration:

| Synapse Setting | Databricks Equivalent |
|----------------|----------------------|
| Node size (Small/Medium/Large) | Worker instance type |
| Autoscale (min/max nodes) | Autoscale (min/max workers) |
| Spark version | Databricks Runtime version |
| Python version | Included in DBR |
| Required libraries | Cluster libraries or init scripts |
| Spark config properties | Cluster Spark config |
| Dynamic executor allocation | Databricks autoscaling |

**Node size mapping (approximate):**

| Synapse Node Size | vCores | Memory | Databricks VM (Azure) |
|------------------|--------|--------|----------------------|
| Small | 4 | 32 GB | Standard_DS4_v2 |
| Medium | 8 | 64 GB | Standard_DS5_v2 |
| Large | 16 | 128 GB | Standard_E16s_v3 |
| XLarge | 32 | 256 GB | Standard_E32s_v3 |
| XXLarge | 64 | 512 GB | Standard_E64s_v3 |

---

## Phase 2: Infrastructure Provisioning

### 2.1 Deploy Databricks Workspace

Use the included Terraform module at `terraform/synapse-databricks/main.tf` to deploy:
- Databricks workspace in the same region as your ADLS Gen2 account
- Unity Catalog metastore (if not already provisioned)
- Managed identity for ADLS Gen2 access
- Private endpoint connectivity (recommended)

### 2.2 Configure Storage Access

The most critical step. Your ADLS Gen2 accounts must be accessible from Databricks.

**Option A: Unity Catalog External Locations (recommended)**

```sql
-- In Databricks SQL
CREATE STORAGE CREDENTIAL adls_credential
WITH (AZURE_MANAGED_IDENTITY = '<managed-identity-id>');

CREATE EXTERNAL LOCATION bronze_lake
URL 'abfss://bronze@<storage>.dfs.core.windows.net/'
WITH (STORAGE CREDENTIAL adls_credential);
```

**Option B: Cluster-Level ADLS Access**

```python
# Spark config on cluster or in notebook
spark.conf.set(
    "fs.azure.account.key.<storage>.dfs.core.windows.net",
    dbutils.secrets.get(scope="storage", key="account-key")
)
```

### 2.3 Migrate Spark SQL Metadata

If you used Synapse Spark SQL databases and tables, recreate them in Databricks:

```sql
-- Create Unity Catalog schema matching Synapse Spark database
CREATE SCHEMA IF NOT EXISTS catalog_name.schema_name;

-- Register existing Delta tables (no data copy needed)
CREATE TABLE catalog_name.schema_name.table_name
USING DELTA
LOCATION 'abfss://container@storage.dfs.core.windows.net/path/to/table';
```

### 2.4 Migrate Custom Libraries

Upload custom `.whl` and `.jar` files to:
- Unity Catalog Volumes (recommended): `CREATE VOLUME catalog.schema.libs`
- DBFS: `/FileStore/jars/` (legacy approach)
- Workspace files: `/Workspace/Shared/libs/`

---

## Phase 3: Code Migration

### 3.1 Notebook Translation

**Step 1: Export from Synapse**

Export notebooks from Synapse Studio as `.ipynb` or `.py` files. Use the Synapse REST API
for bulk export:

```bash
# List all notebooks
az synapse notebook list \
    --workspace-name <workspace> \
    --query "[].name" -o tsv

# Export each notebook
az synapse notebook export \
    --workspace-name <workspace> \
    --name <notebook_name> \
    --output-folder ./exported_notebooks/
```

**Step 2: API Translation**

Apply these find-and-replace patterns across all exported notebooks:

```python
# mssparkutils.fs -> dbutils.fs
# Direct replacement -- API is nearly identical
# mssparkutils.fs.ls()        -> dbutils.fs.ls()
# mssparkutils.fs.cp()        -> dbutils.fs.cp()
# mssparkutils.fs.mv()        -> dbutils.fs.mv()
# mssparkutils.fs.rm()        -> dbutils.fs.rm()
# mssparkutils.fs.mkdirs()    -> dbutils.fs.mkdirs()
# mssparkutils.fs.head()      -> dbutils.fs.head()

# Secrets
# mssparkutils.credentials.getSecret("kv-name", "secret-name")
# -> dbutils.secrets.get(scope="kv-name", key="secret-name")

# Notebook orchestration
# mssparkutils.notebook.run("path", timeout, {"param": "val"})
# -> dbutils.notebook.run("path", timeout, {"param": "val"})

# Exit values
# mssparkutils.notebook.exit("value")
# -> dbutils.notebook.exit("value")
```

**Step 3: Handle Synapse SQL Connector**

Replace `synapsesql` connector calls with JDBC or lakehouse patterns:

```python
# BEFORE (Synapse)
df = spark.read.synapsesql("pool.schema.table")
df.write.synapsesql("pool.schema.table", mode="overwrite")

# AFTER (Databricks) -- Option 1: JDBC
jdbc_url = "jdbc:sqlserver://<synapse-endpoint>:1433;database=<db>"
df = spark.read.jdbc(url=jdbc_url, table="schema.table",
                     properties={"accessToken": token})

# AFTER (Databricks) -- Option 2: Unity Catalog lakehouse table
df = spark.read.table("catalog.schema.table")
df.write.mode("overwrite").saveAsTable("catalog.schema.table")
```

**Step 4: Import to Databricks**

```bash
# Use Databricks CLI for bulk import
databricks workspace import-dir \
    ./exported_notebooks/ \
    /Workspace/Shared/migrated/ \
    --overwrite
```

### 3.2 Spark Job Definition Migration

Convert Synapse Spark job definitions to Databricks job definitions:

```json
// Databricks Job JSON equivalent
{
    "name": "etl_daily_pipeline",
    "tasks": [
        {
            "task_key": "ingest",
            "notebook_task": {
                "notebook_path": "/Workspace/Shared/migrated/ingest",
                "base_parameters": {
                    "date": "{{job.trigger_time.iso_date}}"
                }
            },
            "job_cluster_key": "etl_cluster"
        }
    ],
    "job_clusters": [
        {
            "job_cluster_key": "etl_cluster",
            "new_cluster": {
                "spark_version": "14.3.x-scala2.12",
                "node_type_id": "Standard_DS4_v2",
                "autoscale": {
                    "min_workers": 2,
                    "max_workers": 8
                }
            }
        }
    ]
}
```

---

## Phase 4: Orchestration Migration

### 4.1 Synapse Pipeline Spark Activities

Replace Synapse pipeline Spark activities with Databricks activities:

| Synapse Pipeline Activity | Replacement |
|--------------------------|-------------|
| Synapse Notebook activity | Databricks Notebook activity (in ADF/Synapse Pipeline) |
| Spark job definition activity | Databricks JAR / Python activity |
| Spark SQL activity | Databricks notebook with `%sql` cells |

If using Azure Data Factory, add a Databricks linked service and replace activity
references. The pipeline structure can remain identical.

### 4.2 Moving to Databricks Workflows (Optional)

If you want to consolidate orchestration into Databricks:

1. Map each pipeline to a Databricks multi-task job
2. Convert pipeline parameters to job parameters
3. Map pipeline triggers to Databricks job triggers
4. Replace ADF data flow activities with Spark notebooks

---

## Phase 5: Validation & Cutover

### 5.1 Parallel Run Validation

Run both Synapse Spark and Databricks pipelines in parallel for 1-2 weeks:

```python
# Validation notebook -- compare outputs
synapse_output = spark.read.delta("abfss://...synapse_output_path...")
databricks_output = spark.read.delta("abfss://...databricks_output_path...")

# Row count comparison
assert synapse_output.count() == databricks_output.count(), \
    f"Row count mismatch: {synapse_output.count()} vs {databricks_output.count()}"

# Schema comparison
assert synapse_output.schema == databricks_output.schema, \
    "Schema mismatch detected"

# Data comparison (sample-based for large datasets)
diff = synapse_output.exceptAll(databricks_output)
assert diff.count() == 0, f"Data differences found: {diff.count()} rows"
```

### 5.2 Performance Baseline

Compare execution metrics:

| Metric | Synapse Spark | Databricks | Delta |
|--------|--------------|------------|-------|
| Job duration | | | |
| Data processed (GB) | | | |
| Cluster spin-up time | | | |
| Cost per run | | | |

### 5.3 Cutover Checklist

- [ ] All notebooks migrated and tested
- [ ] All job definitions recreated in Databricks
- [ ] Orchestration pipelines updated
- [ ] Storage access verified from Databricks
- [ ] Secrets migrated to Databricks secret scopes
- [ ] Custom libraries uploaded and tested
- [ ] Unity Catalog tables registered
- [ ] Monitoring and alerting configured
- [ ] Synapse Spark pools paused (do not delete yet)
- [ ] Parallel run validation passed for all pipelines
- [ ] Downstream consumers (Synapse SQL, Power BI) verified
- [ ] Runbook updated for operations team

### 5.4 Decommission Synapse Spark Pools

After 2-4 weeks of stable Databricks operation:

1. Delete Synapse Spark pool configurations
2. Remove Spark-related linked services
3. Archive exported Synapse notebooks
4. Update documentation and runbooks
5. Retain Synapse workspace if still using SQL pools or pipelines

---

## Common Migration Issues

| Issue | Resolution |
|-------|-----------|
| `mssparkutils` not found | Replace with `dbutils` equivalents |
| Linked service auth failures | Use Databricks secret scopes or Unity Catalog connections |
| Different Spark version behavior | Pin Databricks Runtime to compatible version |
| Missing Python packages | Add to cluster libraries or requirements.txt |
| ADLS Gen2 permission denied | Configure storage credential in Unity Catalog |
| Different default file formats | Explicitly specify format in read/write calls |
| Timezone differences | Set `spark.sql.session.timeZone` explicitly |

---

## Post-Migration Optimization

Once migrated, take advantage of Databricks features not available in Synapse Spark:

1. **Enable Photon** -- 2-8x speedup on Delta Lake queries
2. **Use Unity Catalog** -- Centralized governance
3. **Delta Live Tables** -- Declarative ETL pipelines
4. **Structured Streaming** -- Replace batch with streaming where applicable
5. **MLflow** -- Integrated ML experiment tracking
6. **Databricks Asset Bundles** -- CI/CD for notebooks and jobs

---

*Datanest Digital -- [datanest.dev](https://datanest.dev)*
