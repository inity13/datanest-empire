# Azure Synapse-Databricks Integration Kit

**Product ID:** `azure-synapse-integration-kit`
**Version:** 1.0.0
**Author:** [Datanest Digital](https://datanest.dev)
**Price:** $49 USD

---

## Overview

The Azure Synapse-Databricks Integration Kit provides production-ready templates, guides, and automation for organizations running both Azure Synapse Analytics and Azure Databricks. Rather than treating these services as competitors, this kit enables you to leverage the strengths of each platform in a unified architecture.

Most Azure data platforms eventually adopt both services. Synapse excels at T-SQL workloads, serverless exploration, and Power BI integration. Databricks excels at large-scale Spark processing, ML workflows, and Delta Lake management. This kit eliminates the guesswork in making them work together.

## What's Included

### Architecture & Migration Guides

| Guide | Description |
|-------|-------------|
| `guides/architecture_decision_guide.md` | Decision tree for when to use Synapse vs Databricks vs both |
| `guides/migration_synapse_to_databricks.md` | Step-by-step migration from Synapse Spark pools to Databricks |
| `guides/security_cross_service.md` | Cross-service authentication with Managed Identity and service principals |

### SQL Templates

| File | Description |
|------|-------------|
| `sql/serverless_views_over_delta.sql` | 10+ Synapse serverless SQL view patterns over Delta Lake tables |
| `sql/dedicated_pool_integration.sql` | Synapse dedicated SQL pool integration queries and external table patterns |

### Databricks Notebooks

| Notebook | Description |
|----------|-------------|
| `notebooks/power_bi_directquery_setup.py` | Configure Power BI DirectQuery over Databricks SQL endpoints |
| `notebooks/data_sharing_patterns.py` | Data sharing between Synapse and Unity Catalog |

### Infrastructure as Code

| File | Description |
|------|-------------|
| `terraform/synapse-databricks/main.tf` | Joint Synapse + Databricks Terraform deployment |
| `terraform/synapse-databricks/variables.tf` | Configurable variables for the deployment |
| `terraform/synapse-databricks/outputs.tf` | Output values for downstream consumption |

### Tools

| Tool | Description |
|------|-------------|
| `tools/cost_comparison_calculator.py` | CLI tool comparing Synapse vs Databricks costs for common workloads |

## Prerequisites

- Azure subscription with Contributor access
- Terraform >= 1.5.0 (for infrastructure deployment)
- Python >= 3.9 (for CLI tools)
- Azure CLI >= 2.50.0
- Familiarity with Azure Synapse Analytics and Azure Databricks

## Quick Start

### 1. Review the Architecture Decision Guide

Start with `guides/architecture_decision_guide.md` to understand which workloads belong where. This guide uses a decision-tree format to help you map your current workloads to the right service.

### 2. Deploy Infrastructure

```bash
cd terraform/synapse-databricks
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your values
terraform init
terraform plan
terraform apply
```

### 3. Configure Cross-Service Authentication

Follow `guides/security_cross_service.md` to set up Managed Identity authentication between Synapse and Databricks. This eliminates the need for stored credentials.

### 4. Set Up Serverless Views

Apply the SQL templates in `sql/serverless_views_over_delta.sql` to create Synapse serverless views over your Delta Lake tables managed by Databricks.

### 5. Run the Cost Calculator

```bash
python tools/cost_comparison_calculator.py --help
python tools/cost_comparison_calculator.py compare \
    --data-volume-tb 10 \
    --daily-queries 500 \
    --etl-hours 8
```

## Architecture Pattern

The kit is designed around the following reference architecture:

```
                    +------------------+
                    |    Power BI      |
                    +--------+---------+
                             |
              +--------------+--------------+
              |                             |
    +---------v----------+     +------------v-----------+
    | Synapse Serverless  |     | Databricks SQL         |
    | SQL Pool            |     | Warehouse / Endpoint   |
    +----------+----------+     +------------+-----------+
               |                             |
               +-------------+---------------+
                             |
                    +--------v---------+
                    |   ADLS Gen2      |
                    |   (Delta Lake)   |
                    +--------+---------+
                             |
              +--------------+--------------+
              |                             |
    +---------v----------+     +------------v-----------+
    | Synapse Dedicated   |     | Databricks Spark       |
    | SQL Pool (DWH)      |     | Clusters / Jobs        |
    +---------------------+     +------------------------+
```

**ADLS Gen2 as the shared storage layer** is the key integration point. Databricks writes Delta Lake tables to ADLS Gen2, and Synapse reads them via serverless SQL pools or loads them into dedicated pools.

## File Structure

```
07-azure-synapse-integration-kit/
├── README.md
├── manifest.json
├── guides/
│   ├── architecture_decision_guide.md
│   ├── migration_synapse_to_databricks.md
│   └── security_cross_service.md
├── sql/
│   ├── serverless_views_over_delta.sql
│   └── dedicated_pool_integration.sql
├── notebooks/
│   ├── power_bi_directquery_setup.py
│   └── data_sharing_patterns.py
├── terraform/
│   └── synapse-databricks/
│       ├── main.tf
│       ├── variables.tf
│       └── outputs.tf
└── tools/
    └── cost_comparison_calculator.py
```

## Support

- Documentation: [https://datanest.dev/docs](https://datanest.dev/docs)
- Issues: [https://datanest.dev/support](https://datanest.dev/support)

## License

This product is licensed for use by the purchasing individual or organization. Redistribution is not permitted. See the license terms at [https://datanest.dev/license](https://datanest.dev/license).

---

Built by [Datanest Digital](https://datanest.dev)
