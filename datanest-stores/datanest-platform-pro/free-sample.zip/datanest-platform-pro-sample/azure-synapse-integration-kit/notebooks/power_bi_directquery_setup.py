# Databricks notebook source
# MAGIC %md
# MAGIC # Power BI DirectQuery Setup for Databricks SQL Endpoints
# MAGIC
# MAGIC **Datanest Digital** | [datanest.dev](https://datanest.dev)
# MAGIC
# MAGIC This notebook configures and validates Databricks SQL endpoints for Power BI
# MAGIC DirectQuery connectivity. It creates optimized serving views, validates endpoint
# MAGIC readiness, and generates connection strings for Power BI Desktop.
# MAGIC
# MAGIC ## Prerequisites
# MAGIC - Databricks SQL Warehouse (serverless or pro)
# MAGIC - Unity Catalog enabled
# MAGIC - Power BI Pro or Premium license

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

# Configurable parameters
CATALOG_NAME = "production"
SCHEMA_NAME = "power_bi_serving"
SQL_WAREHOUSE_NAME = "power_bi_warehouse"

# Storage / Delta Lake paths (used for validation only)
GOLD_LAYER_PATH = "abfss://gold@<storage_account>.dfs.core.windows.net/"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 1: Create Serving Schema for Power BI

# COMMAND ----------

spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG_NAME}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG_NAME}.{SCHEMA_NAME}")
spark.sql(f"""
    COMMENT ON SCHEMA {CATALOG_NAME}.{SCHEMA_NAME}
    IS 'Optimized serving layer for Power BI DirectQuery. Managed by Datanest Digital integration kit.'
""")
print(f"Schema {CATALOG_NAME}.{SCHEMA_NAME} ready.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 2: Create Optimized Serving Views
# MAGIC
# MAGIC These views sit on top of gold-layer Delta tables and are specifically
# MAGIC designed for DirectQuery performance. Key optimizations:
# MAGIC - Pre-selected columns (reduce I/O)
# MAGIC - Proper data types for Power BI compatibility
# MAGIC - Pre-computed metrics where helpful

# COMMAND ----------

serving_views = {
    "dim_customers": """
        CREATE OR REPLACE VIEW {catalog}.{schema}.dim_customers AS
        SELECT
            customer_id,
            customer_name,
            COALESCE(segment, 'Unknown')    AS segment,
            COALESCE(region, 'Unknown')     AS region,
            created_date,
            CASE WHEN is_active = true THEN 'Active' ELSE 'Inactive' END AS status
        FROM {catalog}.gold.customers
        WHERE is_active IS NOT NULL
    """,
    "dim_products": """
        CREATE OR REPLACE VIEW {catalog}.{schema}.dim_products AS
        SELECT
            product_id,
            product_name,
            category,
            subcategory,
            CAST(unit_price AS DECIMAL(10, 2)) AS unit_price,
            CASE WHEN is_discontinued THEN 'Discontinued' ELSE 'Active' END AS product_status
        FROM {catalog}.gold.products
    """,
    "dim_date": """
        CREATE OR REPLACE VIEW {catalog}.{schema}.dim_date AS
        SELECT
            date_key,
            full_date,
            year,
            quarter,
            month_number,
            month_name,
            week_of_year,
            day_of_week,
            day_name,
            is_weekend,
            is_holiday,
            fiscal_year,
            fiscal_quarter
        FROM {catalog}.gold.date_dimension
    """,
    "fact_orders": """
        CREATE OR REPLACE VIEW {catalog}.{schema}.fact_orders AS
        SELECT
            order_id,
            customer_id,
            product_id,
            CAST(order_date AS DATE)                    AS order_date,
            quantity,
            CAST(unit_price AS DECIMAL(10, 2))          AS unit_price,
            CAST(total_amount AS DECIMAL(18, 2))        AS total_amount,
            CAST(discount_amount AS DECIMAL(18, 2))     AS discount_amount,
            order_status,
            region
        FROM {catalog}.gold.orders
    """,
    "fact_daily_revenue": """
        CREATE OR REPLACE VIEW {catalog}.{schema}.fact_daily_revenue AS
        SELECT
            CAST(order_date AS DATE)            AS revenue_date,
            region,
            COUNT(DISTINCT order_id)            AS order_count,
            COUNT(DISTINCT customer_id)         AS unique_customers,
            CAST(SUM(total_amount) AS DECIMAL(18, 2))   AS gross_revenue,
            CAST(SUM(discount_amount) AS DECIMAL(18, 2)) AS total_discounts,
            CAST(SUM(total_amount - discount_amount) AS DECIMAL(18, 2)) AS net_revenue
        FROM {catalog}.gold.orders
        GROUP BY CAST(order_date AS DATE), region
    """,
}

for view_name, ddl_template in serving_views.items():
    ddl = ddl_template.format(catalog=CATALOG_NAME, schema=SCHEMA_NAME)
    try:
        spark.sql(ddl)
        print(f"  Created view: {CATALOG_NAME}.{SCHEMA_NAME}.{view_name}")
    except Exception as e:
        print(f"  WARNING: Could not create {view_name}: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 3: Validate Serving Views

# COMMAND ----------

validation_results = []

for view_name in serving_views.keys():
    fqn = f"{CATALOG_NAME}.{SCHEMA_NAME}.{view_name}"
    try:
        row_count = spark.sql(f"SELECT COUNT(*) AS cnt FROM {fqn}").collect()[0]["cnt"]
        columns = spark.sql(f"DESCRIBE {fqn}").count()
        validation_results.append({
            "view": fqn,
            "row_count": row_count,
            "column_count": columns,
            "status": "OK" if row_count > 0 else "EMPTY"
        })
    except Exception as e:
        validation_results.append({
            "view": fqn,
            "row_count": -1,
            "column_count": -1,
            "status": f"ERROR: {e}"
        })

validation_df = spark.createDataFrame(validation_results)
display(validation_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 4: SQL Warehouse Configuration Validation

# COMMAND ----------

import requests
import json

def get_sql_warehouse_info(warehouse_name: str) -> dict:
    """Retrieve SQL warehouse configuration via Databricks REST API."""
    host = spark.conf.get("spark.databricks.workspaceUrl")
    token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

    response = requests.get(
        f"https://{host}/api/2.0/sql/warehouses",
        headers={"Authorization": f"Bearer {token}"},
        timeout=30,
    )
    response.raise_for_status()

    warehouses = response.json().get("warehouses", [])
    for wh in warehouses:
        if wh["name"] == warehouse_name:
            return wh
    return {}

warehouse_info = get_sql_warehouse_info(SQL_WAREHOUSE_NAME)

if warehouse_info:
    print(f"Warehouse: {warehouse_info['name']}")
    print(f"  ID:           {warehouse_info['id']}")
    print(f"  State:        {warehouse_info.get('state', 'UNKNOWN')}")
    print(f"  Cluster Size: {warehouse_info.get('cluster_size', 'N/A')}")
    print(f"  Max Clusters: {warehouse_info.get('max_num_clusters', 'N/A')}")
    print(f"  Auto Stop:    {warehouse_info.get('auto_stop_mins', 'N/A')} mins")
    print(f"  Type:         {warehouse_info.get('warehouse_type', 'N/A')}")
    print(f"  Photon:       {warehouse_info.get('enable_photon', False)}")

    # Power BI specific recommendations
    recommendations = []
    if warehouse_info.get("auto_stop_mins", 0) < 15:
        recommendations.append("Consider auto_stop_mins >= 15 to avoid frequent cold starts with DirectQuery.")
    if not warehouse_info.get("enable_photon", False):
        recommendations.append("Enable Photon for better DirectQuery query performance.")
    if warehouse_info.get("max_num_clusters", 1) < 2:
        recommendations.append("Consider max_num_clusters >= 2 for concurrent Power BI user queries.")

    if recommendations:
        print("\nRecommendations for Power BI:")
        for r in recommendations:
            print(f"  - {r}")
    else:
        print("\nWarehouse configuration looks good for Power BI DirectQuery.")
else:
    print(f"WARNING: Warehouse '{SQL_WAREHOUSE_NAME}' not found.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 5: Generate Power BI Connection Details

# COMMAND ----------

def generate_connection_details(warehouse_info: dict) -> dict:
    """Generate connection details for Power BI Desktop."""
    if not warehouse_info:
        return {"error": "No warehouse info available"}

    host = spark.conf.get("spark.databricks.workspaceUrl")
    http_path = warehouse_info.get("odbc_params", {}).get("path", "")
    warehouse_id = warehouse_info.get("id", "")

    return {
        "server_hostname": host,
        "http_path": http_path,
        "port": 443,
        "protocol": "HTTPS",
        "catalog": CATALOG_NAME,
        "schema": SCHEMA_NAME,
        "auth_type": "Azure Active Directory",
        "power_bi_desktop_steps": [
            "1. Open Power BI Desktop",
            "2. Get Data > Azure Databricks",
            f"3. Server Hostname: {host}",
            f"4. HTTP Path: {http_path}",
            "5. Data Connectivity Mode: DirectQuery",
            "6. Sign in with Azure AD credentials",
            f"7. Navigate to: {CATALOG_NAME} > {SCHEMA_NAME}",
            "8. Select the serving views created by this notebook",
        ],
        "jdbc_url": (
            f"jdbc:databricks://{host}:443/default;"
            f"transportMode=http;ssl=1;httpPath={http_path};"
            f"AuthMech=11;Auth_Flow=0"
        ),
    }

conn = generate_connection_details(warehouse_info)

print("=" * 70)
print("POWER BI CONNECTION DETAILS")
print("=" * 70)
print(f"Server Hostname : {conn.get('server_hostname', 'N/A')}")
print(f"HTTP Path       : {conn.get('http_path', 'N/A')}")
print(f"Port            : {conn.get('port', 'N/A')}")
print(f"Catalog         : {conn.get('catalog', 'N/A')}")
print(f"Schema          : {conn.get('schema', 'N/A')}")
print(f"Auth Type       : {conn.get('auth_type', 'N/A')}")
print()
print("Steps in Power BI Desktop:")
for step in conn.get("power_bi_desktop_steps", []):
    print(f"  {step}")
print()
print(f"JDBC URL (for reference):")
print(f"  {conn.get('jdbc_url', 'N/A')}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 6: Grant Permissions to Power BI Service Principal

# COMMAND ----------

# Service principal application ID for Power BI (set this to your SP)
POWER_BI_SP_APP_ID = "<power-bi-service-principal-app-id>"

# Grant usage on catalog and schema
permission_statements = [
    f"GRANT USE CATALOG ON CATALOG {CATALOG_NAME} TO `{POWER_BI_SP_APP_ID}`",
    f"GRANT USE SCHEMA ON SCHEMA {CATALOG_NAME}.{SCHEMA_NAME} TO `{POWER_BI_SP_APP_ID}`",
    f"GRANT SELECT ON SCHEMA {CATALOG_NAME}.{SCHEMA_NAME} TO `{POWER_BI_SP_APP_ID}`",
]

for stmt in permission_statements:
    try:
        spark.sql(stmt)
        print(f"  Granted: {stmt}")
    except Exception as e:
        print(f"  NOTE: {e}")

print()
print("If using AAD user authentication instead of SP, grant to AAD group:")
print(f"  GRANT USE CATALOG ON CATALOG {CATALOG_NAME} TO `power_bi_users`")
print(f"  GRANT USE SCHEMA ON SCHEMA {CATALOG_NAME}.{SCHEMA_NAME} TO `power_bi_users`")
print(f"  GRANT SELECT ON SCHEMA {CATALOG_NAME}.{SCHEMA_NAME} TO `power_bi_users`")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 7: DirectQuery Performance Baseline

# COMMAND ----------

import time

benchmark_queries = {
    "simple_count": f"SELECT COUNT(*) FROM {CATALOG_NAME}.{SCHEMA_NAME}.fact_orders",
    "filtered_agg": f"""
        SELECT region, SUM(total_amount) AS revenue
        FROM {CATALOG_NAME}.{SCHEMA_NAME}.fact_orders
        WHERE order_date >= '2025-01-01'
        GROUP BY region
    """,
    "join_query": f"""
        SELECT c.segment, SUM(o.total_amount) AS revenue
        FROM {CATALOG_NAME}.{SCHEMA_NAME}.fact_orders o
        JOIN {CATALOG_NAME}.{SCHEMA_NAME}.dim_customers c ON o.customer_id = c.customer_id
        GROUP BY c.segment
    """,
    "daily_trend": f"""
        SELECT revenue_date, net_revenue
        FROM {CATALOG_NAME}.{SCHEMA_NAME}.fact_daily_revenue
        WHERE revenue_date >= '2025-01-01'
        ORDER BY revenue_date
    """,
}

print("DirectQuery Performance Baseline")
print("=" * 60)
for name, query in benchmark_queries.items():
    start = time.time()
    try:
        result = spark.sql(query).collect()
        elapsed = time.time() - start
        print(f"  {name:20s} : {elapsed:6.2f}s  ({len(result)} rows)")
    except Exception as e:
        elapsed = time.time() - start
        print(f"  {name:20s} : ERROR after {elapsed:.2f}s - {e}")

print()
print("Target: All queries < 5s for acceptable DirectQuery UX.")
print("If queries exceed 5s, consider:")
print("  - Enabling Photon on the SQL warehouse")
print("  - Adding liquid clustering to underlying Delta tables")
print("  - Pre-aggregating in the serving view")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary
# MAGIC
# MAGIC This notebook has:
# MAGIC 1. Created a dedicated Power BI serving schema in Unity Catalog
# MAGIC 2. Built optimized views over gold-layer Delta tables
# MAGIC 3. Validated view accessibility and row counts
# MAGIC 4. Checked SQL warehouse configuration for Power BI readiness
# MAGIC 5. Generated connection details for Power BI Desktop
# MAGIC 6. Applied permissions for Power BI service principal / user groups
# MAGIC 7. Established a DirectQuery performance baseline
# MAGIC
# MAGIC **Next steps:**
# MAGIC - Open Power BI Desktop and connect using the details above
# MAGIC - Build your data model using the serving views
# MAGIC - Publish to Power BI Service and configure scheduled refresh (for import)
# MAGIC   or verify DirectQuery performance in the service
