# Databricks notebook source
# MAGIC %md
# MAGIC # Data Sharing Patterns: Synapse and Unity Catalog
# MAGIC
# MAGIC **Datanest Digital** | [datanest.dev](https://datanest.dev)
# MAGIC
# MAGIC This notebook demonstrates patterns for sharing data between Azure Synapse Analytics
# MAGIC and Databricks Unity Catalog. The shared storage layer is ADLS Gen2 with Delta Lake.
# MAGIC
# MAGIC ## Patterns Covered
# MAGIC 1. Unity Catalog tables accessible from Synapse serverless
# MAGIC 2. Synapse dedicated pool data accessible from Databricks
# MAGIC 3. Delta Sharing for cross-environment access
# MAGIC 4. Metadata synchronization between catalogs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

# Unity Catalog settings
UC_CATALOG = "production"
UC_SCHEMA_GOLD = "gold"
UC_SCHEMA_SHARED = "synapse_shared"

# ADLS Gen2 settings
STORAGE_ACCOUNT = "<storage_account>"
GOLD_CONTAINER = "gold"
SHARED_CONTAINER = "synapse-shared"

# Synapse settings (for JDBC connectivity)
SYNAPSE_ENDPOINT = "<synapse_workspace>.sql.azuresynapse.net"
SYNAPSE_DATABASE = "dedicated_pool"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pattern 1: Publish Unity Catalog Tables for Synapse Consumption
# MAGIC
# MAGIC Unity Catalog external tables store data in ADLS Gen2. Synapse serverless can
# MAGIC read these Delta files directly — no data copy required.

# COMMAND ----------

def publish_table_for_synapse(
    source_table: str,
    target_table: str,
    storage_path: str,
    partition_columns: list[str] | None = None,
) -> dict:
    """
    Create or replace a Unity Catalog external table at a well-known ADLS path
    that Synapse serverless can query directly.

    Args:
        source_table: Fully qualified source table (catalog.schema.table).
        target_table: Target table name (will be created in UC_SCHEMA_SHARED).
        storage_path: ADLS Gen2 path for the external table data.
        partition_columns: Optional list of columns to partition by.

    Returns:
        Dict with table metadata and Synapse OPENROWSET query template.
    """
    full_target = f"{UC_CATALOG}.{UC_SCHEMA_SHARED}.{target_table}"
    full_path = f"abfss://{SHARED_CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/{storage_path}"

    # Read source data
    source_df = spark.read.table(source_table)
    row_count = source_df.count()

    # Write to well-known path as Delta
    writer = source_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
    if partition_columns:
        writer = writer.partitionBy(*partition_columns)
    writer.save(full_path)

    # Register as Unity Catalog external table
    spark.sql(f"DROP TABLE IF EXISTS {full_target}")

    partition_clause = ""
    if partition_columns:
        partition_clause = f"PARTITIONED BY ({', '.join(partition_columns)})"

    spark.sql(f"""
        CREATE TABLE {full_target}
        USING DELTA
        {partition_clause}
        LOCATION '{full_path}'
    """)

    # Generate Synapse OPENROWSET template
    synapse_query = f"""
    -- Synapse serverless query for {target_table}
    SELECT *
    FROM OPENROWSET(
        BULK '{storage_path}/',
        DATA_SOURCE = 'SharedDeltaLake',
        FORMAT = 'DELTA'
    ) AS [{target_table}];
    """

    print(f"Published: {full_target}")
    print(f"  Rows: {row_count}")
    print(f"  Path: {full_path}")
    print(f"  Partitions: {partition_columns or 'None'}")

    return {
        "table": full_target,
        "path": full_path,
        "row_count": row_count,
        "synapse_query": synapse_query,
    }

# COMMAND ----------

# Create shared schema
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {UC_CATALOG}.{UC_SCHEMA_SHARED}")
spark.sql(f"""
    COMMENT ON SCHEMA {UC_CATALOG}.{UC_SCHEMA_SHARED}
    IS 'Tables published for Synapse serverless consumption. Do not modify externally.'
""")

# Publish gold tables for Synapse access
published_tables = []

tables_to_publish = [
    {
        "source": f"{UC_CATALOG}.{UC_SCHEMA_GOLD}.customers",
        "target": "customers",
        "path": "customers",
        "partitions": None,
    },
    {
        "source": f"{UC_CATALOG}.{UC_SCHEMA_GOLD}.orders",
        "target": "orders",
        "path": "orders",
        "partitions": ["order_date"],
    },
    {
        "source": f"{UC_CATALOG}.{UC_SCHEMA_GOLD}.products",
        "target": "products",
        "path": "products",
        "partitions": None,
    },
]

for tbl in tables_to_publish:
    try:
        result = publish_table_for_synapse(
            source_table=tbl["source"],
            target_table=tbl["target"],
            storage_path=tbl["path"],
            partition_columns=tbl["partitions"],
        )
        published_tables.append(result)
    except Exception as e:
        print(f"  WARNING: Could not publish {tbl['target']}: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pattern 2: Read Synapse Dedicated Pool Data from Databricks
# MAGIC
# MAGIC When Synapse dedicated pool contains data not in the lake (e.g., legacy DWH tables),
# MAGIC read it into Databricks via JDBC.

# COMMAND ----------

def read_synapse_table(
    schema: str,
    table: str,
    fetch_size: int = 10000,
    partition_column: str | None = None,
    num_partitions: int = 8,
) -> "pyspark.sql.DataFrame":
    """
    Read a table from Synapse dedicated SQL pool via JDBC with AAD auth.

    Args:
        schema: Source schema name in Synapse.
        table: Source table name.
        fetch_size: JDBC fetch size for batching.
        partition_column: Column to parallelize reads (should be numeric).
        num_partitions: Number of parallel JDBC readers.

    Returns:
        Spark DataFrame with the table contents.
    """
    # Retrieve service principal credentials from Databricks secrets
    client_id = dbutils.secrets.get(scope="synapse", key="sp-client-id")
    client_secret = dbutils.secrets.get(scope="synapse", key="sp-client-secret")
    tenant_id = dbutils.secrets.get(scope="synapse", key="tenant-id")

    # Build JDBC URL with AAD service principal auth
    jdbc_url = (
        f"jdbc:sqlserver://{SYNAPSE_ENDPOINT}:1433;"
        f"database={SYNAPSE_DATABASE};"
        f"encrypt=true;"
        f"trustServerCertificate=false;"
        f"hostNameInCertificate=*.sql.azuresynapse.net;"
        f"loginTimeout=30;"
        f"authentication=ActiveDirectoryServicePrincipal"
    )

    connection_properties = {
        "user": client_id,
        "password": client_secret,
        "tenantId": tenant_id,
        "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
        "fetchSize": str(fetch_size),
    }

    reader = spark.read.jdbc(
        url=jdbc_url,
        table=f"{schema}.{table}",
        properties=connection_properties,
    )

    # Enable parallel reads if partition column provided
    if partition_column:
        bounds = spark.read.jdbc(
            url=jdbc_url,
            table=f"(SELECT MIN({partition_column}) AS lb, MAX({partition_column}) AS ub FROM {schema}.{table}) t",
            properties=connection_properties,
        ).collect()[0]

        reader = spark.read.jdbc(
            url=jdbc_url,
            table=f"{schema}.{table}",
            column=partition_column,
            lowerBound=int(bounds["lb"]),
            upperBound=int(bounds["ub"]),
            numPartitions=num_partitions,
            properties=connection_properties,
        )

    return reader

# Example: Read Synapse DWH table into Databricks
# synapse_df = read_synapse_table("dbo", "legacy_fact_sales", partition_column="sale_id")
# synapse_df.write.format("delta").mode("overwrite").saveAsTable(f"{UC_CATALOG}.staging.legacy_sales")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pattern 3: Delta Sharing for External Access
# MAGIC
# MAGIC Delta Sharing provides an open protocol for sharing data without copying.
# MAGIC External consumers (including Synapse via compatible connectors) can read
# MAGIC shared tables.

# COMMAND ----------

def setup_delta_sharing(
    share_name: str,
    schema_name: str,
    tables: list[str],
    recipients: list[str],
) -> None:
    """
    Create a Delta Share and add tables and recipients.

    Args:
        share_name: Name for the Delta Share.
        schema_name: Source schema containing tables to share.
        tables: List of table names to include in the share.
        recipients: List of recipient names to grant access.
    """
    # Create share
    spark.sql(f"CREATE SHARE IF NOT EXISTS {share_name}")
    spark.sql(f"""
        COMMENT ON SHARE {share_name}
        IS 'Shared dataset for cross-platform consumption. Managed by integration kit.'
    """)

    # Add tables to share
    for table in tables:
        full_table = f"{UC_CATALOG}.{schema_name}.{table}"
        try:
            spark.sql(f"ALTER SHARE {share_name} ADD TABLE {full_table}")
            print(f"  Added {full_table} to share {share_name}")
        except Exception as e:
            if "already exists" in str(e).lower():
                print(f"  Table {full_table} already in share {share_name}")
            else:
                print(f"  WARNING: Could not add {full_table}: {e}")

    # Create recipients and grant access
    for recipient in recipients:
        try:
            spark.sql(f"CREATE RECIPIENT IF NOT EXISTS `{recipient}`")
            spark.sql(f"GRANT SELECT ON SHARE {share_name} TO RECIPIENT `{recipient}`")
            print(f"  Granted {recipient} access to share {share_name}")
        except Exception as e:
            print(f"  WARNING: Could not grant to {recipient}: {e}")


# Example usage:
# setup_delta_sharing(
#     share_name="synapse_analytics_share",
#     schema_name="gold",
#     tables=["customers", "orders", "products"],
#     recipients=["synapse_workspace_sp"],
# )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pattern 4: Metadata Synchronization
# MAGIC
# MAGIC Keep a metadata registry of tables available across both platforms.
# MAGIC This helps maintain an inventory of what's shared and where.

# COMMAND ----------

from datetime import datetime

def build_cross_platform_inventory(catalog: str, schemas: list[str]) -> "pyspark.sql.DataFrame":
    """
    Build an inventory of Unity Catalog tables with their ADLS paths,
    enabling Synapse teams to discover available data.

    Args:
        catalog: Unity Catalog name to inventory.
        schemas: List of schemas to include.

    Returns:
        DataFrame with table inventory.
    """
    inventory_rows = []

    for schema in schemas:
        try:
            tables = spark.sql(f"SHOW TABLES IN {catalog}.{schema}").collect()
        except Exception as e:
            print(f"  WARNING: Could not list tables in {catalog}.{schema}: {e}")
            continue

        for table_row in tables:
            table_name = table_row["tableName"]
            full_name = f"{catalog}.{schema}.{table_name}"

            try:
                detail = spark.sql(f"DESCRIBE DETAIL {full_name}").collect()[0]
                columns = spark.sql(f"DESCRIBE {full_name}").collect()

                inventory_rows.append({
                    "catalog": catalog,
                    "schema": schema,
                    "table_name": table_name,
                    "full_name": full_name,
                    "location": detail["location"] or "managed",
                    "format": detail["format"],
                    "num_files": detail["numFiles"],
                    "size_bytes": detail["sizeInBytes"],
                    "num_columns": len([c for c in columns if not c["col_name"].startswith("#")]),
                    "partition_columns": str(detail["partitionColumns"]),
                    "last_modified": str(detail["lastModified"]),
                    "synapse_accessible": detail["location"] is not None
                        and "abfss://" in str(detail["location"]),
                    "inventory_timestamp": datetime.utcnow().isoformat(),
                })
            except Exception as e:
                print(f"  WARNING: Could not describe {full_name}: {e}")

    if not inventory_rows:
        print("No tables found in specified schemas.")
        return spark.createDataFrame([], schema="catalog STRING, schema STRING")

    return spark.createDataFrame(inventory_rows)


# Build inventory
inventory_df = build_cross_platform_inventory(
    catalog=UC_CATALOG,
    schemas=[UC_SCHEMA_GOLD, UC_SCHEMA_SHARED],
)

# Save inventory as a Delta table for cross-platform reference
inventory_table = f"{UC_CATALOG}.{UC_SCHEMA_SHARED}._table_inventory"
inventory_df.write.format("delta").mode("overwrite").saveAsTable(inventory_table)
print(f"Inventory saved to {inventory_table}")

display(inventory_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pattern 5: Generate Synapse View DDL from Unity Catalog Metadata
# MAGIC
# MAGIC Automatically produce Synapse serverless SQL DDL for all shared tables.

# COMMAND ----------

def generate_synapse_ddl(inventory_df: "pyspark.sql.DataFrame", data_source: str = "SharedDeltaLake") -> str:
    """
    Generate Synapse serverless SQL CREATE VIEW statements from the inventory.

    Args:
        inventory_df: DataFrame from build_cross_platform_inventory().
        data_source: Name of the Synapse external data source.

    Returns:
        SQL script as a string.
    """
    synapse_accessible = inventory_df.filter("synapse_accessible = true").collect()
    ddl_lines = [
        "-- ==========================================================",
        "-- Auto-generated Synapse serverless views",
        f"-- Generated: {datetime.utcnow().isoformat()}",
        "-- Source: Unity Catalog inventory",
        "-- Datanest Digital | https://datanest.dev",
        "-- ==========================================================",
        "",
    ]

    for row in synapse_accessible:
        # Extract relative path from the full ADLS location
        location = row["location"]
        # Parse path after container
        container_suffix = f"@{STORAGE_ACCOUNT}.dfs.core.windows.net/"
        if container_suffix in location:
            relative_path = location.split(container_suffix, 1)[1].rstrip("/")
        else:
            relative_path = row["table_name"]

        view_name = f"[{row['schema']}].[{row['table_name']}]"
        ddl_lines.extend([
            f"CREATE OR ALTER VIEW {view_name}",
            f"AS",
            f"SELECT *",
            f"FROM OPENROWSET(",
            f"    BULK '{relative_path}/',",
            f"    DATA_SOURCE = '{data_source}',",
            f"    FORMAT = 'DELTA'",
            f") AS [{row['table_name']}];",
            f"GO",
            "",
        ])

    return "\n".join(ddl_lines)


ddl_script = generate_synapse_ddl(inventory_df)
print(ddl_script)

# Optionally save the DDL to ADLS for the Synapse team to pick up
# dbutils.fs.put(
#     f"abfss://{SHARED_CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/_scripts/synapse_views.sql",
#     ddl_script,
#     overwrite=True,
# )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary
# MAGIC
# MAGIC | Pattern | Direction | Mechanism |
# MAGIC |---------|-----------|-----------|
# MAGIC | 1. Publish for Synapse | Databricks -> Synapse | External Delta table at known ADLS path |
# MAGIC | 2. Read Synapse DWH | Synapse -> Databricks | JDBC with AAD service principal |
# MAGIC | 3. Delta Sharing | Databricks -> External | Open Delta Sharing protocol |
# MAGIC | 4. Metadata Sync | Bidirectional | Inventory table in Unity Catalog |
# MAGIC | 5. DDL Generation | Databricks -> Synapse | Auto-generated Synapse view scripts |
# MAGIC
# MAGIC **Key principle:** ADLS Gen2 is the shared storage layer. Unity Catalog governs
# MAGIC access on the Databricks side. Synapse serverless reads Delta files directly.
# MAGIC No data duplication is needed for most patterns.
