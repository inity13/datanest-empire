-- =============================================================================
-- Synapse Dedicated SQL Pool Integration Queries
-- Azure Synapse-Databricks Integration Kit
-- Datanest Digital | https://datanest.dev
-- =============================================================================
--
-- These queries enable Synapse dedicated SQL pools to interoperate with
-- Delta Lake / ADLS Gen2 data managed by Databricks.
--
-- Two primary patterns:
--   1. External tables pointing to ADLS Gen2 (Parquet/Delta)
--   2. COPY INTO for high-throughput data loading from the lake
--
-- =============================================================================

-- =============================================================================
-- SETUP: External resources for dedicated pool
-- =============================================================================

-- Master key (required for credentials)
IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##')
BEGIN
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = '<replace-with-strong-password>';
END
GO

-- Credential using Managed Identity
CREATE DATABASE SCOPED CREDENTIAL LakeCredential
WITH IDENTITY = 'Managed Identity';
GO

-- External data source for the gold layer
CREATE EXTERNAL DATA SOURCE GoldLake
WITH (
    TYPE = HADOOP,
    LOCATION = 'abfss://gold@<storage_account>.dfs.core.windows.net/',
    CREDENTIAL = LakeCredential
);
GO

-- External file format for Parquet files (Delta's underlying format)
CREATE EXTERNAL FILE FORMAT ParquetFileFormat
WITH (
    FORMAT_TYPE = PARQUET,
    DATA_COMPRESSION = 'org.apache.hadoop.io.compress.SnappyCodec'
);
GO


-- =============================================================================
-- PATTERN 1: External table over Parquet files from Databricks pipeline
-- Use when: Databricks writes Parquet (not Delta) to a known path.
-- =============================================================================

CREATE EXTERNAL TABLE staging.ext_daily_metrics (
    metric_date         DATE            NOT NULL,
    metric_name         NVARCHAR(100)   NOT NULL,
    metric_value        DECIMAL(18, 4)  NOT NULL,
    dimension_1         NVARCHAR(50)    NULL,
    dimension_2         NVARCHAR(50)    NULL,
    dimension_3         NVARCHAR(50)    NULL,
    updated_at          DATETIME2       NOT NULL
)
WITH (
    LOCATION = '/metrics/daily/',
    DATA_SOURCE = GoldLake,
    FILE_FORMAT = ParquetFileFormat
);
GO


-- =============================================================================
-- PATTERN 2: COPY INTO for high-throughput loading from Delta/Parquet output
-- Use when: Loading large volumes from ADLS into dedicated pool tables.
-- =============================================================================

-- Target table in dedicated pool
CREATE TABLE dbo.fact_orders (
    order_id            BIGINT          NOT NULL,
    customer_id         BIGINT          NOT NULL,
    product_id          INT             NOT NULL,
    order_date          DATE            NOT NULL,
    region              NVARCHAR(50)    NOT NULL,
    quantity            INT             NOT NULL,
    unit_price          DECIMAL(10, 2)  NOT NULL,
    total_amount        DECIMAL(18, 2)  NOT NULL,
    order_status        NVARCHAR(20)    NOT NULL
)
WITH (
    DISTRIBUTION = HASH(customer_id),
    CLUSTERED COLUMNSTORE INDEX,
    PARTITION (order_date RANGE RIGHT FOR VALUES (
        '2024-01-01', '2024-04-01', '2024-07-01', '2024-10-01',
        '2025-01-01', '2025-04-01', '2025-07-01', '2025-10-01'
    ))
);
GO

-- COPY INTO with Parquet source (Databricks writes export Parquet to this path)
COPY INTO dbo.fact_orders
(
    order_id,
    customer_id,
    product_id,
    order_date,
    region,
    quantity,
    unit_price,
    total_amount,
    order_status
)
FROM 'abfss://gold@<storage_account>.dfs.core.windows.net/exports/orders/'
WITH (
    FILE_TYPE = 'PARQUET',
    CREDENTIAL = (IDENTITY = 'Managed Identity'),
    MAXERRORS = 0,
    AUTO_CREATE_TABLE = 'OFF'
);
GO


-- =============================================================================
-- PATTERN 3: Incremental load using watermark
-- Use when: Loading only new/changed data from Databricks output.
-- =============================================================================

-- Watermark tracking table
CREATE TABLE etl.load_watermarks (
    table_name          NVARCHAR(100)   NOT NULL,
    last_loaded_value   DATETIME2       NOT NULL,
    last_run_timestamp  DATETIME2       NOT NULL,
    rows_loaded         BIGINT          NOT NULL
);
GO

-- Stored procedure for incremental COPY INTO
CREATE PROCEDURE etl.usp_incremental_load_orders
AS
BEGIN
    DECLARE @last_watermark DATETIME2;
    DECLARE @current_watermark DATETIME2 = GETUTCDATE();
    DECLARE @rows_before BIGINT;
    DECLARE @rows_after BIGINT;

    -- Get last watermark
    SELECT @last_watermark = ISNULL(MAX(last_loaded_value), '1900-01-01')
    FROM etl.load_watermarks
    WHERE table_name = 'fact_orders';

    SELECT @rows_before = COUNT_BIG(*) FROM dbo.fact_orders;

    -- Load new data (Databricks writes incremental exports partitioned by date)
    COPY INTO dbo.fact_orders
    FROM 'abfss://gold@<storage_account>.dfs.core.windows.net/exports/orders/incremental/'
    WITH (
        FILE_TYPE = 'PARQUET',
        CREDENTIAL = (IDENTITY = 'Managed Identity')
    );

    SELECT @rows_after = COUNT_BIG(*) FROM dbo.fact_orders;

    -- Update watermark
    IF EXISTS (SELECT 1 FROM etl.load_watermarks WHERE table_name = 'fact_orders')
    BEGIN
        UPDATE etl.load_watermarks
        SET last_loaded_value = @current_watermark,
            last_run_timestamp = GETUTCDATE(),
            rows_loaded = @rows_after - @rows_before
        WHERE table_name = 'fact_orders';
    END
    ELSE
    BEGIN
        INSERT INTO etl.load_watermarks (table_name, last_loaded_value, last_run_timestamp, rows_loaded)
        VALUES ('fact_orders', @current_watermark, GETUTCDATE(), @rows_after - @rows_before);
    END
END
GO


-- =============================================================================
-- PATTERN 4: Dimension table with MERGE (upsert from lake)
-- Use when: Keeping dedicated pool dimensions in sync with Databricks-managed data.
-- =============================================================================

-- Dimension table
CREATE TABLE dbo.dim_customers (
    customer_id         BIGINT          NOT NULL,
    customer_name       NVARCHAR(200)   NOT NULL,
    email               NVARCHAR(200)   NULL,
    segment             NVARCHAR(50)    NULL,
    region              NVARCHAR(50)    NULL,
    created_date        DATE            NULL,
    is_active           BIT             NOT NULL,
    last_synced_at      DATETIME2       NOT NULL
)
WITH (
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
);
GO

-- Staging table for lake data
CREATE TABLE staging.stg_customers (
    customer_id         BIGINT          NOT NULL,
    customer_name       NVARCHAR(200)   NOT NULL,
    email               NVARCHAR(200)   NULL,
    segment             NVARCHAR(50)    NULL,
    region              NVARCHAR(50)    NULL,
    created_date        DATE            NULL,
    is_active           BIT             NOT NULL
)
WITH (
    DISTRIBUTION = ROUND_ROBIN,
    HEAP
);
GO

-- Sync procedure: load from lake then merge
CREATE PROCEDURE etl.usp_sync_dim_customers
AS
BEGIN
    -- Step 1: Truncate staging
    TRUNCATE TABLE staging.stg_customers;

    -- Step 2: Load from lake into staging
    COPY INTO staging.stg_customers
    FROM 'abfss://gold@<storage_account>.dfs.core.windows.net/dimensions/customers/'
    WITH (
        FILE_TYPE = 'PARQUET',
        CREDENTIAL = (IDENTITY = 'Managed Identity')
    );

    -- Step 3: Synapse dedicated pool does not support MERGE.
    -- Use DELETE + INSERT pattern instead.

    -- Delete rows that exist in staging (will be re-inserted with updates)
    DELETE FROM dbo.dim_customers
    WHERE customer_id IN (SELECT customer_id FROM staging.stg_customers);

    -- Insert all rows from staging
    INSERT INTO dbo.dim_customers (
        customer_id, customer_name, email, segment, region,
        created_date, is_active, last_synced_at
    )
    SELECT
        customer_id, customer_name, email, segment, region,
        created_date, is_active, GETUTCDATE()
    FROM staging.stg_customers;

    -- Step 4: Clean up staging
    TRUNCATE TABLE staging.stg_customers;
END
GO


-- =============================================================================
-- PATTERN 5: Statistics and performance optimization
-- Use when: External tables or newly loaded data need statistics for query optimizer.
-- =============================================================================

-- Create statistics on key columns after loading
CREATE STATISTICS stat_orders_date ON dbo.fact_orders (order_date);
CREATE STATISTICS stat_orders_customer ON dbo.fact_orders (customer_id);
CREATE STATISTICS stat_orders_region ON dbo.fact_orders (region);
CREATE STATISTICS stat_orders_amount ON dbo.fact_orders (total_amount);
GO

-- Rebuild columnstore indexes after large loads
ALTER INDEX ALL ON dbo.fact_orders REBUILD;
GO

-- Check data distribution skew
SELECT
    distribution_id,
    COUNT(*) AS row_count
FROM sys.pdw_distributions d
CROSS APPLY (
    SELECT 1 FROM dbo.fact_orders
) x
GROUP BY distribution_id
ORDER BY distribution_id;
GO


-- =============================================================================
-- MONITORING: Integration health checks
-- =============================================================================

-- View: External data source connectivity status
CREATE OR ALTER VIEW admin.integration_health
AS
SELECT
    'External Data Sources' AS check_category,
    eds.name                AS resource_name,
    eds.location            AS resource_location,
    'Configured'            AS status
FROM sys.external_data_sources eds

UNION ALL

SELECT
    'External Tables' AS check_category,
    t.name           AS resource_name,
    eds.location     AS resource_location,
    'Active'         AS status
FROM sys.external_tables t
INNER JOIN sys.external_data_sources eds ON t.data_source_id = eds.data_source_id

UNION ALL

SELECT
    'Load Watermarks' AS check_category,
    w.table_name      AS resource_name,
    CAST(w.last_loaded_value AS NVARCHAR(50)) AS resource_location,
    CASE
        WHEN DATEDIFF(HOUR, w.last_run_timestamp, GETUTCDATE()) > 24
        THEN 'STALE (>' + CAST(DATEDIFF(HOUR, w.last_run_timestamp, GETUTCDATE()) AS NVARCHAR) + 'h)'
        ELSE 'Current'
    END AS status
FROM etl.load_watermarks w;
GO
