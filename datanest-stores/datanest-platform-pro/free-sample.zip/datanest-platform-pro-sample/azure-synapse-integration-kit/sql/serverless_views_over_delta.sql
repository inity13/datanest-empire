-- =============================================================================
-- Synapse Serverless SQL Views over Delta Lake Tables
-- Azure Synapse-Databricks Integration Kit
-- Datanest Digital | https://datanest.dev
-- =============================================================================
--
-- These view patterns enable Synapse serverless SQL to query Delta Lake tables
-- managed by Databricks. All views use OPENROWSET with Delta format.
--
-- Prerequisites:
--   1. Database master key created
--   2. Database-scoped credential using Managed Identity
--   3. External data source pointing to ADLS Gen2
--
-- =============================================================================

-- =============================================================================
-- FOUNDATION: Database setup (run once per database)
-- =============================================================================

-- Create a dedicated database for Delta Lake views
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'delta_lakehouse')
BEGIN
    CREATE DATABASE delta_lakehouse;
END
GO

USE delta_lakehouse;
GO

-- Create master key for credential encryption
IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##')
BEGIN
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = '<replace-with-strong-password>';
END
GO

-- Managed Identity credential (no secrets stored)
IF NOT EXISTS (SELECT * FROM sys.database_scoped_credentials WHERE name = 'ManagedIdentityCredential')
BEGIN
    CREATE DATABASE SCOPED CREDENTIAL ManagedIdentityCredential
    WITH IDENTITY = 'Managed Identity';
END
GO

-- External data sources for each medallion layer
CREATE EXTERNAL DATA SOURCE BronzeLayer
WITH (
    LOCATION = 'abfss://bronze@<storage_account>.dfs.core.windows.net/',
    CREDENTIAL = ManagedIdentityCredential
);
GO

CREATE EXTERNAL DATA SOURCE SilverLayer
WITH (
    LOCATION = 'abfss://silver@<storage_account>.dfs.core.windows.net/',
    CREDENTIAL = ManagedIdentityCredential
);
GO

CREATE EXTERNAL DATA SOURCE GoldLayer
WITH (
    LOCATION = 'abfss://gold@<storage_account>.dfs.core.windows.net/',
    CREDENTIAL = ManagedIdentityCredential
);
GO


-- =============================================================================
-- PATTERN 1: Basic Delta table view (typed columns)
-- Use when: You want a clean, typed interface over a Delta table.
-- =============================================================================

CREATE OR ALTER VIEW gold.dim_customers
AS
SELECT *
FROM OPENROWSET(
    BULK 'dimensions/customers/',
    DATA_SOURCE = 'GoldLayer',
    FORMAT = 'DELTA'
) WITH (
    customer_id         BIGINT,
    customer_name       NVARCHAR(200),
    email               NVARCHAR(200),
    segment             NVARCHAR(50),
    region              NVARCHAR(50),
    created_date        DATE,
    is_active           BIT,
    lifetime_value      DECIMAL(18, 2)
) AS customers;
GO


-- =============================================================================
-- PATTERN 2: Schema-on-read (auto-detect columns)
-- Use when: Schema is evolving and you want Synapse to infer types.
-- =============================================================================

CREATE OR ALTER VIEW gold.fact_transactions
AS
SELECT *
FROM OPENROWSET(
    BULK 'facts/transactions/',
    DATA_SOURCE = 'GoldLayer',
    FORMAT = 'DELTA'
) AS transactions;
GO


-- =============================================================================
-- PATTERN 3: Column projection with renaming
-- Use when: Delta table column names don't match your SQL naming conventions.
-- =============================================================================

CREATE OR ALTER VIEW gold.dim_products
AS
SELECT
    product_id          AS ProductID,
    product_name        AS ProductName,
    category_name       AS Category,
    subcategory_name    AS Subcategory,
    unit_price          AS UnitPrice,
    is_discontinued     AS IsDiscontinued,
    effective_from      AS EffectiveFrom,
    effective_to        AS EffectiveTo
FROM OPENROWSET(
    BULK 'dimensions/products/',
    DATA_SOURCE = 'GoldLayer',
    FORMAT = 'DELTA'
) WITH (
    product_id          INT,
    product_name        NVARCHAR(200),
    category_name       NVARCHAR(100),
    subcategory_name    NVARCHAR(100),
    unit_price          DECIMAL(10, 2),
    is_discontinued     BIT,
    effective_from      DATE,
    effective_to        DATE
) AS products;
GO


-- =============================================================================
-- PATTERN 4: Partitioned Delta table with partition elimination
-- Use when: Delta table is partitioned and you want Synapse to prune partitions.
-- Synapse serverless supports partition elimination on Delta tables natively.
-- =============================================================================

CREATE OR ALTER VIEW gold.fact_orders
AS
SELECT *
FROM OPENROWSET(
    BULK 'facts/orders/',
    DATA_SOURCE = 'GoldLayer',
    FORMAT = 'DELTA'
) WITH (
    order_id            BIGINT,
    customer_id         BIGINT,
    product_id          INT,
    quantity            INT,
    unit_price          DECIMAL(10, 2),
    discount_pct        DECIMAL(5, 2),
    total_amount        DECIMAL(18, 2),
    order_status        NVARCHAR(20),
    order_date          DATE,         -- partition column
    region              NVARCHAR(50)  -- partition column
) AS orders;
GO

-- Usage: Synapse eliminates partitions when filtering on partition columns
-- SELECT * FROM gold.fact_orders WHERE order_date >= '2025-01-01' AND region = 'EMEA';


-- =============================================================================
-- PATTERN 5: Aggregation view (pre-filtered/aggregated for BI)
-- Use when: Power BI or reporting tools need a summarized dataset.
-- =============================================================================

CREATE OR ALTER VIEW gold.daily_revenue_summary
AS
SELECT
    order_date,
    region,
    COUNT(DISTINCT order_id)        AS order_count,
    COUNT(DISTINCT customer_id)     AS unique_customers,
    SUM(total_amount)               AS gross_revenue,
    SUM(total_amount * discount_pct / 100.0) AS total_discounts,
    SUM(total_amount * (1 - discount_pct / 100.0)) AS net_revenue,
    AVG(total_amount)               AS avg_order_value
FROM OPENROWSET(
    BULK 'facts/orders/',
    DATA_SOURCE = 'GoldLayer',
    FORMAT = 'DELTA'
) WITH (
    order_id            BIGINT,
    customer_id         BIGINT,
    order_date          DATE,
    region              NVARCHAR(50),
    total_amount        DECIMAL(18, 2),
    discount_pct        DECIMAL(5, 2)
) AS orders
GROUP BY order_date, region;
GO


-- =============================================================================
-- PATTERN 6: SCD Type 2 dimension view (current records only)
-- Use when: Delta table contains historical SCD2 records and you only need current.
-- =============================================================================

CREATE OR ALTER VIEW gold.dim_employees_current
AS
SELECT
    employee_id,
    employee_name,
    department,
    title,
    manager_id,
    hire_date,
    effective_from
FROM OPENROWSET(
    BULK 'dimensions/employees/',
    DATA_SOURCE = 'GoldLayer',
    FORMAT = 'DELTA'
) WITH (
    employee_id         INT,
    employee_name       NVARCHAR(200),
    department          NVARCHAR(100),
    title               NVARCHAR(100),
    manager_id          INT,
    hire_date           DATE,
    effective_from      DATE,
    effective_to        DATE,
    is_current          BIT
) AS emp
WHERE is_current = 1;
GO


-- =============================================================================
-- PATTERN 7: Multi-table join view (denormalized for reporting)
-- Use when: You want to provide a single flat view combining fact + dimensions.
-- =============================================================================

CREATE OR ALTER VIEW gold.orders_denormalized
AS
SELECT
    o.order_id,
    o.order_date,
    o.region,
    o.quantity,
    o.total_amount,
    c.customer_name,
    c.segment                       AS customer_segment,
    p.ProductName                   AS product_name,
    p.Category                      AS product_category
FROM gold.fact_orders               AS o
INNER JOIN gold.dim_customers       AS c ON o.customer_id = c.customer_id
INNER JOIN gold.dim_products        AS p ON o.product_id = p.ProductID;
GO


-- =============================================================================
-- PATTERN 8: Silver layer view with data quality filters
-- Use when: Exposing silver layer data with basic quality checks applied.
-- =============================================================================

CREATE OR ALTER VIEW silver.validated_events
AS
SELECT
    event_id,
    event_type,
    user_id,
    session_id,
    event_timestamp,
    event_payload,
    source_system,
    ingestion_timestamp
FROM OPENROWSET(
    BULK 'events/clickstream/',
    DATA_SOURCE = 'SilverLayer',
    FORMAT = 'DELTA'
) WITH (
    event_id            NVARCHAR(50),
    event_type          NVARCHAR(50),
    user_id             NVARCHAR(50),
    session_id          NVARCHAR(100),
    event_timestamp     DATETIME2,
    event_payload       NVARCHAR(MAX),
    source_system       NVARCHAR(50),
    ingestion_timestamp DATETIME2,
    _dq_is_valid        BIT,
    _dq_error_reason    NVARCHAR(200)
) AS events
WHERE _dq_is_valid = 1;
GO


-- =============================================================================
-- PATTERN 9: Bronze layer view with JSON parsing
-- Use when: Raw data is stored as JSON strings in Delta and you need to parse.
-- =============================================================================

CREATE OR ALTER VIEW bronze.raw_api_responses
AS
SELECT
    request_id,
    api_endpoint,
    http_status_code,
    response_timestamp,
    JSON_VALUE(response_body, '$.status')           AS response_status,
    JSON_VALUE(response_body, '$.data.id')          AS entity_id,
    JSON_VALUE(response_body, '$.data.name')        AS entity_name,
    JSON_QUERY(response_body, '$.data.attributes')  AS entity_attributes,
    CAST(JSON_VALUE(response_body, '$.data.amount') AS DECIMAL(18, 2)) AS amount,
    response_body
FROM OPENROWSET(
    BULK 'api_ingestion/responses/',
    DATA_SOURCE = 'BronzeLayer',
    FORMAT = 'DELTA'
) WITH (
    request_id          NVARCHAR(50),
    api_endpoint        NVARCHAR(200),
    http_status_code    INT,
    response_timestamp  DATETIME2,
    response_body       NVARCHAR(MAX)
) AS responses;
GO


-- =============================================================================
-- PATTERN 10: Time-windowed view with rolling calculations
-- Use when: You want to expose rolling metrics without materializing them.
-- =============================================================================

CREATE OR ALTER VIEW gold.customer_rolling_metrics
AS
WITH daily_totals AS (
    SELECT
        customer_id,
        order_date,
        SUM(total_amount)       AS daily_total,
        COUNT(*)                AS daily_orders
    FROM OPENROWSET(
        BULK 'facts/orders/',
        DATA_SOURCE = 'GoldLayer',
        FORMAT = 'DELTA'
    ) WITH (
        customer_id     BIGINT,
        order_date      DATE,
        total_amount    DECIMAL(18, 2)
    ) AS o
    GROUP BY customer_id, order_date
)
SELECT
    customer_id,
    order_date,
    daily_total,
    daily_orders,
    SUM(daily_total) OVER (
        PARTITION BY customer_id
        ORDER BY order_date
        ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
    ) AS rolling_30d_revenue,
    SUM(daily_orders) OVER (
        PARTITION BY customer_id
        ORDER BY order_date
        ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
    ) AS rolling_30d_orders,
    AVG(daily_total) OVER (
        PARTITION BY customer_id
        ORDER BY order_date
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) AS avg_7d_daily_revenue
FROM daily_totals;
GO


-- =============================================================================
-- PATTERN 11: Row-level security view
-- Use when: Different users/groups should see different subsets of data.
-- =============================================================================

-- Create a mapping table for user-region access
CREATE TABLE dbo.user_region_access (
    user_email      NVARCHAR(200),
    allowed_region  NVARCHAR(50)
);
GO

-- Populate access rules
INSERT INTO dbo.user_region_access (user_email, allowed_region)
VALUES
    ('analyst_emea@company.com', 'EMEA'),
    ('analyst_apac@company.com', 'APAC'),
    ('analyst_na@company.com', 'NAM'),
    ('global_admin@company.com', '*');
GO

CREATE OR ALTER VIEW gold.fact_orders_rls
AS
SELECT o.*
FROM gold.fact_orders AS o
INNER JOIN dbo.user_region_access AS a
    ON (a.allowed_region = o.region OR a.allowed_region = '*')
WHERE a.user_email = SUSER_SNAME();
GO


-- =============================================================================
-- PATTERN 12: CETAS - Materialized snapshot from Delta to Parquet
-- Use when: You need to snapshot Delta data for external consumers or archival.
-- =============================================================================

-- External file format for Parquet output
IF NOT EXISTS (SELECT * FROM sys.external_file_formats WHERE name = 'ParquetFormat')
BEGIN
    CREATE EXTERNAL FILE FORMAT ParquetFormat
    WITH (FORMAT_TYPE = PARQUET);
END
GO

-- External data source for output
CREATE EXTERNAL DATA SOURCE SnapshotOutput
WITH (
    LOCATION = 'abfss://snapshots@<storage_account>.dfs.core.windows.net/',
    CREDENTIAL = ManagedIdentityCredential
);
GO

-- Create materialized snapshot (run periodically via pipeline)
-- Note: CETAS creates a NEW external table; drop first if re-running.
CREATE EXTERNAL TABLE gold.orders_snapshot_20250101
WITH (
    LOCATION = 'orders/snapshot_20250101/',
    DATA_SOURCE = SnapshotOutput,
    FILE_FORMAT = ParquetFormat
)
AS
SELECT
    order_id,
    customer_id,
    product_id,
    order_date,
    region,
    total_amount,
    order_status,
    GETUTCDATE() AS snapshot_timestamp
FROM gold.fact_orders
WHERE order_date >= '2025-01-01'
  AND order_date < '2025-02-01';
GO


-- =============================================================================
-- UTILITY: Metadata view for listing all Delta tables accessible via data source
-- =============================================================================

CREATE OR ALTER VIEW admin.delta_table_inventory
AS
SELECT
    eds.name                AS data_source_name,
    eds.location            AS data_source_location,
    v.name                  AS view_name,
    s.name                  AS schema_name,
    v.create_date           AS view_created,
    v.modify_date           AS view_modified
FROM sys.views v
INNER JOIN sys.schemas s ON v.schema_id = s.schema_id
CROSS JOIN sys.external_data_sources eds
WHERE v.name NOT LIKE 'sys%'
  AND s.name IN ('gold', 'silver', 'bronze');
GO
