# Pricing & Rate Calculator

Spreadsheet calculator for hourly, project, and retainer pricing. Factors in expenses, taxes, and desired profit margin.

## Contents

- `config.example.yaml`

## Quick Start

1. Extract the ZIP archive
2. Review the README and documentation
3. Customize configuration files for your environment
4. Follow the setup guide for your specific use case

## Requirements

- Python 3.10+ (for Python scripts)
- Relevant CLI tools for your platform
- Access to your target environment

## License

MIT License — see LICENSE file.

## Support

Questions or issues? Email megafolder122122@hotmail.com

---
Part of [Freelancer Toolkit](https://inity13.github.io/freelancer-toolkit-pro/)
