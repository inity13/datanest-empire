# Interview Prep Pro — Free Sample Pack

Thank you for downloading the free sample pack!

## What's Included

- **Behavioral Interview Question Bank** — 200+ behavioral questions organized by competency with STAR framework templates and example answers for tech roles....
- **90-Day Interview Prep Tracker** — Notion-based study plan with daily schedules, topic tracking, mock interview log, and progress visualization....

## Get the Full Collection

This sample includes a preview of what's available in Interview Prep Pro.
The full store has 11 products covering Technical interview preparation materials, system design guides, and career toolkits.

Visit: https://inity13.github.io/interview-prep-pro/

Use code **COMMUNITY** for 15% off your first purchase.
Students/bootcamp grads: use code **STUDENT** for 50% off.

## Contact

Questions? Reach out at megafolder122122@hotmail.com
