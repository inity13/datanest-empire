# Hyperparameter Tuning Kit

Production-ready hyperparameter optimization configs using Optuna and Ray Tune. Includes search space definitions, pruning strategies, distributed tuning setups, and integration with experiment tracking.

## What's Included

- Optuna study configurations with various samplers
- Ray Tune distributed hyperparameter search setups
- Search space definition templates for common model types
- Pruning strategy configs (MedianPruner, HyperbandPruner)
- Distributed tuning on multi-node clusters
- Integration with MLflow and Weights & Biases
- Results analysis and visualization templates

## Quick Start

```bash
# 1. Copy the example config
cp config.example.yaml config.yaml

# 2. Install dependencies
pip install optuna ray[tune]

# 3. Run the example tuning study
python -m tuning.run --config config.yaml
```

## Prerequisites

- Python 3.9+
- Optuna 3.x or Ray Tune 2.x
- (Optional) Distributed compute cluster for parallel trials

## Contents

```
hyperparameter-tuning-kit/
  config.example.yaml
  docs/
    overview.md
    patterns/
      pattern-01-*.md
    checklists/
      pre-deployment.md
  templates/
    config.yaml
```

## Support

For questions or issues, contact: megafolder122122@hotmail.com

## License

MIT License - Copyright 2026 Jesse Mikkola. See LICENSE for details.
