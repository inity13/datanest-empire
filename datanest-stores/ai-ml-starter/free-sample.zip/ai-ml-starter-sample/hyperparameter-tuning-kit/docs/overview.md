# Hyperparameter Tuning Kit - Overview Guide

## Introduction

Hyperparameter tuning is the process of finding the optimal configuration
for your ML model. This guide covers systematic approaches using Optuna
and Ray Tune, from simple grid search to advanced Bayesian optimization
with early stopping.

## Architecture

```
+------------------+     +-------------------+     +------------------+
|  Search Space    |     |  Tuning Engine    |     |  Results Store   |
|  Definition      |     |                   |     |                  |
|  - Ranges        |---->|  Optuna / Ray     |---->|  - Best params   |
|  - Types         |     |  Tune             |     |  - Trial history |
|  - Constraints   |     |                   |     |  - Visualizations|
+------------------+     |  +-----------+    |     +------------------+
                         |  | Sampler   |    |
                         |  +-----------+    |
                         |  | Pruner    |    |
                         |  +-----------+    |
                         |  | Scheduler |    |
                         |  +-----------+    |
                         +-------------------+
```

## Search Strategies

### 1. Grid Search

Exhaustively tests all combinations. Only viable for small search spaces.

```python
# 2 x 3 x 3 = 18 trials
search_space = {
    "learning_rate": [0.01, 0.001],
    "batch_size": [32, 64, 128],
    "optimizer": ["adam", "sgd", "adamw"],
}
```

### 2. Random Search

Randomly samples from distributions. Surprisingly effective and simple.

```python
import optuna

def objective(trial):
    lr = trial.suggest_float("learning_rate", 1e-5, 1e-1, log=True)
    batch_size = trial.suggest_categorical("batch_size", [16, 32, 64, 128])
    dropout = trial.suggest_float("dropout", 0.1, 0.5)
    return train_and_evaluate(lr, batch_size, dropout)

study = optuna.create_study(
    direction="maximize",
    sampler=optuna.samplers.RandomSampler(seed=42),
)
study.optimize(objective, n_trials=100)
```

### 3. Bayesian Optimization (TPE)

Uses past trial results to guide the search toward promising regions.

```python
study = optuna.create_study(
    direction="maximize",
    sampler=optuna.samplers.TPESampler(
        n_startup_trials=10,  # Random trials before TPE kicks in
        seed=42,
    ),
)
study.optimize(objective, n_trials=100)
```

### 4. CMA-ES

Evolutionary strategy, good for continuous search spaces:

```python
study = optuna.create_study(
    sampler=optuna.samplers.CmaEsSampler(seed=42),
)
```

## Pruning Strategies

Pruning stops unpromising trials early, saving compute:

### Median Pruner
Stops trial if metric is below median of previous trials at same step:

```python
study = optuna.create_study(
    pruner=optuna.pruners.MedianPruner(
        n_startup_trials=5,
        n_warmup_steps=10,
        interval_steps=1,
    ),
)
```

### Hyperband Pruner
Aggressive early stopping based on successive halving:

```python
study = optuna.create_study(
    pruner=optuna.pruners.HyperbandPruner(
        min_resource=1,
        max_resource=100,
        reduction_factor=3,
    ),
)
```

### Reporting Intermediate Values

```python
def objective(trial):
    model = create_model(trial)
    for epoch in range(100):
        train(model)
        val_acc = evaluate(model)
        trial.report(val_acc, epoch)
        if trial.should_prune():
            raise optuna.TrialPruned()
    return val_acc
```

## Ray Tune for Distributed Tuning

```python
from ray import tune
from ray.tune.schedulers import ASHAScheduler

search_space = {
    "learning_rate": tune.loguniform(1e-5, 1e-1),
    "batch_size": tune.choice([16, 32, 64, 128]),
    "dropout": tune.uniform(0.1, 0.5),
}

scheduler = ASHAScheduler(
    max_t=100,
    grace_period=10,
    reduction_factor=2,
)

analysis = tune.run(
    train_function,
    config=search_space,
    num_samples=100,
    scheduler=scheduler,
    resources_per_trial={"cpu": 2, "gpu": 0.5},
)

best_config = analysis.get_best_config(metric="val_accuracy", mode="max")
```

## Search Space Design

### Common Patterns

| Hyperparameter | Recommended Distribution |
|---------------|------------------------|
| Learning rate | Log-uniform (1e-5 to 1e-1) |
| Batch size | Categorical powers of 2 |
| Dropout rate | Uniform (0.0 to 0.5) |
| Hidden layers | Integer (1 to 5) |
| Hidden units | Categorical (64, 128, 256, 512) |
| Weight decay | Log-uniform (1e-6 to 1e-2) |
| Momentum | Uniform (0.8 to 0.99) |

### Conditional Search Spaces

```python
def objective(trial):
    optimizer = trial.suggest_categorical("optimizer", ["adam", "sgd"])
    lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)

    if optimizer == "sgd":
        momentum = trial.suggest_float("momentum", 0.8, 0.99)
    else:
        momentum = None
```

## Experiment Tracking Integration

### Optuna + MLflow

```python
import mlflow

mlflow_callback = optuna.integration.MLflowCallback(
    tracking_uri="http://localhost:5000",
    metric_name="val_accuracy",
)

study.optimize(objective, n_trials=100, callbacks=[mlflow_callback])
```

### Optuna + W&B

```python
import wandb

wandb_callback = optuna.integration.WeightsAndBiasesCallback(
    wandb_kwargs={"project": "hpo-study"},
)

study.optimize(objective, n_trials=100, callbacks=[wandb_callback])
```

## Best Practices

1. **Start with random search** - Establish a baseline before Bayesian methods
2. **Use pruning** - Saves 2-5x compute with minimal loss in result quality
3. **Log-scale for rates** - Learning rate, weight decay benefit from log sampling
4. **Fix seeds** - Ensure reproducibility of best configurations
5. **Budget wisely** - 50-200 trials is typical; diminishing returns after that
6. **Analyze importance** - Use `optuna.importance` to find which params matter

## Troubleshooting

| Issue | Solution |
|-------|----------|
| All trials pruned | Lower pruning aggressiveness or increase warmup |
| Results not improving | Widen search space or try different sampler |
| OOM on GPU | Reduce max batch size or model size in search space |
| Slow trials | Enable pruning, reduce epochs, use smaller data subset |

## Next Steps

- Review the multi-stage tuning pattern in `patterns/`
- Complete the pre-deployment checklist in `checklists/`
- Customize the production config in `templates/config.yaml`
