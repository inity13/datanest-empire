# Pattern 01: Multi-Stage Hyperparameter Tuning

## Overview

This pattern implements a multi-stage tuning approach where coarse-grained
search narrows the space before fine-grained optimization, significantly
reducing compute cost while finding near-optimal configurations.

## Architecture

```
  +-------------------+
  |  Stage 1: Coarse  |
  |  Random Search    |
  |  (20 trials)      |
  |  Wide ranges      |
  +---------+---------+
            |
            v  Top 20% configs
  +-------------------+
  |  Stage 2: Narrow  |
  |  TPE Search       |
  |  (50 trials)      |
  |  Focused ranges   |
  +---------+---------+
            |
            v  Top 5 configs
  +-------------------+
  |  Stage 3: Fine    |
  |  Full training    |
  |  (5 trials)       |
  |  Multiple seeds   |
  +---------+---------+
            |
            v
  +-------------------+
  |  Best Config      |
  |  (with confidence |
  |   interval)       |
  +-------------------+
```

## Flow

1. **Stage 1 (Exploration)** - Wide random search to identify promising regions
2. **Narrow** - Analyze top performers, shrink search space around best values
3. **Stage 2 (Exploitation)** - Focused Bayesian search in narrowed space
4. **Select** - Pick top 5 candidates from stage 2
5. **Stage 3 (Validation)** - Full training with multiple seeds for confidence
6. **Final** - Select best config based on mean performance across seeds

## Implementation

```python
import optuna

def multi_stage_tuning(train_fn, n_stage1=20, n_stage2=50, n_stage3_seeds=3):
    """Run multi-stage hyperparameter tuning."""

    # Stage 1: Coarse exploration
    study_s1 = optuna.create_study(
        direction="maximize",
        sampler=optuna.samplers.RandomSampler(seed=42),
        pruner=optuna.pruners.MedianPruner(n_warmup_steps=3),
    )
    study_s1.optimize(
        lambda trial: train_fn(trial, epochs=10),  # Short training
        n_trials=n_stage1,
    )

    # Analyze top 20% to define narrowed ranges
    top_trials = sorted(study_s1.trials, key=lambda t: t.value or 0, reverse=True)
    top_k = top_trials[:max(1, len(top_trials) // 5)]
    narrowed_ranges = derive_ranges(top_k)

    # Stage 2: Focused search
    study_s2 = optuna.create_study(
        direction="maximize",
        sampler=optuna.samplers.TPESampler(seed=42),
        pruner=optuna.pruners.HyperbandPruner(),
    )
    study_s2.optimize(
        lambda trial: train_fn(trial, epochs=30, ranges=narrowed_ranges),
        n_trials=n_stage2,
    )

    # Stage 3: Validate top candidates with full training
    top_configs = get_top_configs(study_s2, n=5)
    results = []
    for config in top_configs:
        seed_scores = []
        for seed in [42, 123, 456]:
            score = train_fn_with_config(config, epochs=100, seed=seed)
            seed_scores.append(score)
        results.append({
            "config": config,
            "mean": np.mean(seed_scores),
            "std": np.std(seed_scores),
        })

    best = max(results, key=lambda r: r["mean"])
    return best
```

## Trade-offs

| Approach | Pros | Cons |
|----------|------|------|
| Single-stage (all random) | Simple, no bias in search | Wasteful, misses optima |
| Single-stage (all Bayesian) | Efficient per trial | Can get stuck in local optima |
| Multi-stage (this pattern) | Best of both worlds, cost-efficient | More complex setup, requires range analysis |

### When to Use This Pattern

- Large search spaces with many hyperparameters
- Training is expensive (minutes to hours per trial)
- Need confidence in the final selected configuration

### When to Avoid

- Small search spaces (< 3 hyperparameters)
- Cheap training (< 1 minute per trial)
- Time-constrained situations (just run more random trials)

## Compute Budget Guidelines

| Total Budget | Stage 1 | Stage 2 | Stage 3 |
|-------------|---------|---------|---------|
| 50 trials | 15 random | 30 TPE | 5 x 1 seed |
| 100 trials | 20 random | 65 TPE | 5 x 3 seeds |
| 200 trials | 40 random | 130 TPE | 10 x 3 seeds |

## Related Patterns

- Population-based training for dynamic hyperparameter schedules
- Neural architecture search for model structure optimization
- Learning rate finder for single-parameter optimization
