# Experiment Tracking Pack

Comprehensive experiment tracking setup with Weights & Biases and MLflow integration. Includes custom dashboards, metrics comparison tools, and reproducibility patterns for ML experiments.

## What's Included

- Weights & Biases project setup and configuration
- MLflow tracking integration as secondary backend
- Custom experiment comparison dashboards
- Metrics visualization and reporting templates
- Hyperparameter sweep tracking patterns
- Experiment reproducibility configurations
- Team collaboration and sharing setups

## Quick Start

```bash
# 1. Copy the example config
cp config.example.yaml config.yaml

# 2. Set your W&B API key
export WANDB_API_KEY=your_key_here

# 3. Initialize a new project
wandb init

# 4. Run the example tracked experiment
python examples/tracked_experiment.py
```

## Prerequisites

- Python 3.9+
- Weights & Biases account (free tier available)
- MLflow 2.x (optional, for dual tracking)

## Contents

```
experiment-tracking-pack/
  config.example.yaml
  docs/
    overview.md
    patterns/
      pattern-01-*.md
    checklists/
      pre-deployment.md
  templates/
    config.yaml
```

## Support

For questions or issues, contact: megafolder122122@hotmail.com

## License

MIT License - Copyright 2026 Jesse Mikkola. See LICENSE for details.
