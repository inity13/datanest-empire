# Pre-Deployment Checklist - Experiment Tracking Pack

Complete all items before rolling out experiment tracking to the team.

## Platform Setup

- [ ] W&B team/organization account created
- [ ] Project created with appropriate visibility settings
- [ ] Team members invited with correct roles
- [ ] API keys distributed securely (not in code repos)
- [ ] MLflow tracking server deployed (if dual tracking)
- [ ] SSO/SAML configured (if enterprise)

## Instrumentation Standards

- [ ] Experiment naming convention defined and documented
- [ ] Required tags list defined (team, project, experiment type)
- [ ] Minimum required logged parameters defined
- [ ] Minimum required logged metrics defined
- [ ] Artifact logging standards documented
- [ ] Code logging enabled and tested

## Dashboard Setup

- [ ] Team-level overview dashboard created
- [ ] Project-level comparison dashboard created
- [ ] Key metrics identified for each project
- [ ] Alert thresholds configured for metric regressions
- [ ] Report templates created for experiment reviews

## Integration

- [ ] Training scripts instrumented with tracking calls
- [ ] CI/CD pipeline logs experiment results automatically
- [ ] Notebook templates include tracking setup
- [ ] Model registry integration configured (if applicable)
- [ ] Slack/Teams notifications configured for key events

## Reproducibility

- [ ] Random seed logging implemented in all experiments
- [ ] Environment capture (Python version, packages) automated
- [ ] Dataset versioning integrated with experiment tracking
- [ ] Git commit hash logged with every run
- [ ] Requirements.txt / environment.yaml logged as artifact

## Data Management

- [ ] Artifact storage location configured (cloud bucket)
- [ ] Artifact retention policy defined
- [ ] Old experiment cleanup schedule established
- [ ] Storage cost monitoring enabled
- [ ] Large artifact handling documented (references vs uploads)

## Team Onboarding

- [ ] Getting started guide written for new team members
- [ ] Example experiment script provided
- [ ] Comparison workflow documented
- [ ] W&B/MLflow best practices shared
- [ ] FAQ document created for common issues

## Security

- [ ] API keys stored in secrets manager (not committed to repos)
- [ ] Project access controls reviewed
- [ ] Sensitive data excluded from logging
- [ ] Audit logging enabled for compliance
- [ ] Data retention policies comply with regulations
