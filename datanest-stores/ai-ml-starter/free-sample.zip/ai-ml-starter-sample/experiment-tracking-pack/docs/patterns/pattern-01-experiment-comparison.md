# Pattern 01: Systematic Experiment Comparison

## Overview

This pattern defines a structured approach for comparing ML experiments
to make data-driven decisions about which models to promote. It prevents
the common pitfall of cherry-picking results or comparing incompatible runs.

## Architecture

```
  +------------------+     +-------------------+
  |  Experiment Runs |     |  Comparison       |
  |                  |     |  Engine           |
  |  Run A (seed=1)  |     |                   |
  |  Run A (seed=2)  |---->|  1. Aggregate     |
  |  Run A (seed=3)  |     |  2. Statistical   |
  |                  |     |     test          |
  |  Run B (seed=1)  |     |  3. Visualize     |
  |  Run B (seed=2)  |---->|  4. Rank          |
  |  Run B (seed=3)  |     |  5. Report        |
  +------------------+     +--------+----------+
                                    |
                           +--------v----------+
                           |  Decision Matrix  |
                           |                   |
                           |  - Performance    |
                           |  - Latency        |
                           |  - Cost           |
                           |  - Complexity     |
                           +-------------------+
```

## Flow

1. **Run experiments** - Each variant with 3+ random seeds
2. **Aggregate metrics** - Compute mean and standard deviation per variant
3. **Statistical test** - Run significance test between variants
4. **Visualize** - Create comparison plots (box plots, violin plots)
5. **Rank** - Score variants on multiple criteria (accuracy, latency, cost)
6. **Decide** - Use the decision matrix to select the winner

## Implementation

### Multi-Seed Runner

```python
import wandb

def run_experiment(config: dict, seeds: list[int] = [42, 123, 456]):
    """Run an experiment variant with multiple seeds."""
    group_name = f"{config['experiment_name']}-{config['variant']}"

    for seed in seeds:
        run_config = {**config, "seed": seed}
        with wandb.init(
            project=config["project"],
            group=group_name,
            config=run_config,
            tags=[config["variant"]],
        ):
            results = train_and_evaluate(run_config)
            wandb.log(results)
```

### Statistical Comparison

```python
from scipy import stats

def compare_variants(variant_a_scores, variant_b_scores):
    """Compare two variants with a statistical test."""
    t_stat, p_value = stats.ttest_ind(variant_a_scores, variant_b_scores)
    effect_size = (
        (np.mean(variant_a_scores) - np.mean(variant_b_scores))
        / np.sqrt(
            (np.std(variant_a_scores)**2 + np.std(variant_b_scores)**2) / 2
        )
    )
    return {
        "t_statistic": t_stat,
        "p_value": p_value,
        "effect_size": effect_size,  # Cohen's d
        "significant": p_value < 0.05,
    }
```

## Trade-offs

| Approach | Pros | Cons |
|----------|------|------|
| Single seed comparison | Fast, simple | Unreliable, results may be due to luck |
| Multi-seed with t-test | Statistically sound | Slower (3-5x more runs), higher compute cost |
| Bayesian comparison | Richer analysis, uncertainty quantification | More complex, harder to automate |

### When to Use This Pattern

- Comparing model architectures or major hyperparameter changes
- Results will influence production deployment decisions
- Differences between variants are expected to be small

### When to Avoid

- Quick prototyping / early exploration phase
- Differences are obvious (10%+ performance gap)
- Compute budget doesn't allow multiple seeds

## Decision Matrix

Score each variant on multiple axes:

| Criterion | Weight | Variant A | Variant B |
|-----------|--------|-----------|-----------|
| Accuracy | 0.4 | 0.92 | 0.94 |
| Latency (ms) | 0.3 | 15 | 45 |
| Model size (MB) | 0.2 | 50 | 200 |
| Complexity | 0.1 | Low | High |

Weighted score determines the winner, not just accuracy.

## Related Patterns

- Hyperparameter sweep for automated search
- Ablation study for understanding component contributions
- Progressive experimentation for staged exploration
