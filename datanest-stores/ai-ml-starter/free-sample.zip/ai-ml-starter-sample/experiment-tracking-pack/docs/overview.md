# Experiment Tracking Pack - Overview Guide

## Introduction

This guide covers setting up comprehensive experiment tracking for ML projects.
Proper experiment tracking is the foundation of reproducible ML -- it lets you
answer "what changed?" and "why did performance degrade?" months after the fact.

## Architecture

```
+------------------+     +-------------------+     +------------------+
|  ML Engineers    |     |  Tracking Layer    |     |  Storage         |
|                  |     |                   |     |                  |
|  Training Code   |---->|  W&B Client       |---->|  W&B Cloud       |
|  with tracking   |     |  +                |     |  +               |
|  instrumentation |     |  MLflow Client    |---->|  MLflow Server   |
+------------------+     +-------------------+     +------------------+
                                                          |
                                                          v
                                                   +------------------+
                                                   |  Dashboards      |
                                                   |  - Comparison    |
                                                   |  - Sweeps        |
                                                   |  - Reports       |
                                                   +------------------+
```

## What to Track

### Always Track
- **Hyperparameters** - Learning rate, batch size, model architecture
- **Metrics** - Loss, accuracy, F1, custom business metrics
- **Environment** - Python version, package versions, GPU type
- **Data** - Dataset version, split sizes, preprocessing params
- **Code** - Git commit hash, diff from main branch
- **Artifacts** - Model checkpoints, evaluation plots, predictions

### Track When Relevant
- System metrics (GPU utilization, memory usage)
- Training curves (loss per step, not just per epoch)
- Confusion matrices and classification reports
- Feature importance scores
- Prediction distributions

## Weights & Biases Setup

### Project Initialization

```python
import wandb

wandb.init(
    project="my-project",
    entity="my-team",
    config={
        "learning_rate": 0.001,
        "batch_size": 32,
        "epochs": 100,
        "model": "resnet50",
    },
    tags=["baseline", "v1"],
)
```

### Logging Metrics

```python
for epoch in range(config.epochs):
    train_loss = train_one_epoch(model, train_loader)
    val_loss, val_acc = evaluate(model, val_loader)

    wandb.log({
        "train/loss": train_loss,
        "val/loss": val_loss,
        "val/accuracy": val_acc,
        "epoch": epoch,
    })
```

### Logging Artifacts

```python
# Log model checkpoint
artifact = wandb.Artifact("model", type="model")
artifact.add_file("model.pt")
wandb.log_artifact(artifact)

# Log evaluation table
table = wandb.Table(columns=["input", "prediction", "ground_truth"])
for sample in eval_samples:
    table.add_data(sample.input, sample.pred, sample.label)
wandb.log({"eval_samples": table})
```

## MLflow Integration

For teams that need both W&B and MLflow (e.g., W&B for visualization,
MLflow for model registry):

```python
import mlflow
import wandb

# Initialize both
wandb.init(project="my-project")
mlflow.set_experiment("my-project/baseline")

with mlflow.start_run():
    for epoch in range(epochs):
        metrics = {"loss": loss, "accuracy": acc}
        wandb.log(metrics)
        mlflow.log_metrics(metrics, step=epoch)

    mlflow.sklearn.log_model(model, "model")
```

## Experiment Comparison

### Comparing Runs in W&B

Use the W&B web UI to:
1. Select runs to compare in the runs table
2. Create parallel coordinates plots for hyperparameter analysis
3. Overlay training curves to spot divergence
4. Use grouping to compare experiment batches

### Programmatic Comparison

```python
api = wandb.Api()
runs = api.runs("team/project", filters={"tags": "baseline"})

comparison = []
for run in runs:
    comparison.append({
        "name": run.name,
        "accuracy": run.summary.get("val/accuracy"),
        "loss": run.summary.get("val/loss"),
        "lr": run.config.get("learning_rate"),
    })

df = pd.DataFrame(comparison).sort_values("accuracy", ascending=False)
```

## Custom Dashboards

### W&B Report Template

Create shareable reports with:
- Run comparison tables with key metrics
- Training curve overlays
- Hyperparameter importance analysis
- Best run summaries with configuration details

### Metrics to Include in Dashboards
- Best metric value and which run achieved it
- Metric trend over time (are experiments improving?)
- Resource usage per run (cost tracking)
- Experiment throughput (runs per day/week)

## Reproducibility

### Environment Capture

```python
import subprocess
import platform

env_info = {
    "python_version": platform.python_version(),
    "cuda_version": torch.version.cuda,
    "gpu": torch.cuda.get_device_name(0),
    "packages": subprocess.check_output(
        ["pip", "freeze"]
    ).decode().split("\n"),
}
wandb.config.update({"environment": env_info})
```

### Seed Management

```python
def set_all_seeds(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    wandb.config.update({"seed": seed})
```

## Best Practices

1. **Name experiments, not runs** - Use meaningful experiment names; auto-name runs
2. **Tag everything** - Use tags for filtering: `baseline`, `ablation`, `production`
3. **Log early and often** - Log per-step, not just per-epoch
4. **Track negative results** - Failed experiments are valuable information
5. **Use groups** - Group related runs (same experiment, different seeds)
6. **Automate comparison** - Script your comparison workflow, don't do it manually
7. **Clean up** - Archive old experiments, delete failed/test runs

## Team Collaboration

- Share W&B reports for experiment reviews
- Use @mentions in run notes for questions
- Create team dashboards for project-level visibility
- Set up Slack notifications for completed sweeps

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Slow logging | Reduce log frequency or use `wandb.log(commit=False)` |
| Missing metrics | Check metric names for typos, verify log calls execute |
| Large artifact uploads | Use references instead of uploading raw data |
| Duplicate runs | Check for `wandb.init()` in loops |

## Next Steps

- Review the experiment comparison pattern in `patterns/`
- Complete the pre-deployment checklist in `checklists/`
- Customize the production config in `templates/config.yaml`
