# ML Starter Kit — Free Sample Pack

Thank you for downloading the free sample pack!

## What's Included

- **Experiment Tracking Pack** — Experiment tracking with W&B and MLflow, custom dashboards, metrics comparison, and reproducibility tooling....
- **Hyperparameter Tuning Kit** — Optuna/Ray Tune configs, search space definitions, pruning strategies, and distributed tuning setups....

## Get the Full Collection

This sample includes a preview of what's available in ML Starter Kit.
The full store has 10 products covering From Notebook to Production ML in Minutes.

Visit: https://inity13.github.io/ml-starter-kit/

Use code **COMMUNITY** for 15% off your first purchase.
Students/bootcamp grads: use code **STUDENT** for 50% off.

## Contact

Questions? Reach out at megafolder122122@hotmail.com
