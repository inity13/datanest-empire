# Security Policy — No-Code Security Checklist

## Scope
This policy applies to all systems and services managed by this toolkit.

## Access Control
1. All access must be authenticated and authorized
2. Use role-based access control (RBAC)
3. Apply principle of least privilege
4. Review access quarterly
5. Disable unused accounts within 24 hours

## Data Protection
1. Encrypt data at rest using AES-256
2. Encrypt data in transit using TLS 1.2+
3. Classify data by sensitivity level
4. Apply retention policies per classification
5. Securely destroy data when no longer needed

## Incident Response
1. Report incidents within 1 hour of detection
2. Follow the incident response playbook
3. Preserve evidence for forensic analysis
4. Conduct post-mortem within 48 hours
5. Track remediation actions to completion

## Compliance
- [ ] SOC 2 Type II controls mapped
- [ ] GDPR data processing requirements met
- [ ] Regular vulnerability scanning (weekly)
- [ ] Annual penetration testing
- [ ] Security awareness training (quarterly)
