"""Basic security configuration scanner."""
import os
import json
from typing import Dict, List


def check_file_permissions(paths: List[str]) -> List[Dict]:
    """Check for overly permissive file permissions."""
    findings = []
    for path in paths:
        if os.path.exists(path):
            mode = oct(os.stat(path).st_mode)[-3:]
            if int(mode[2]) > 0:  # World-readable/writable
                findings.append({
                    "severity": "HIGH",
                    "path": path,
                    "current_mode": mode,
                    "recommendation": "Remove world permissions: chmod o-rwx"
                })
    return findings


def check_env_secrets(env_file: str = ".env") -> List[Dict]:
    """Check for potential secrets in environment files."""
    sensitive_patterns = ["PASSWORD", "SECRET", "TOKEN", "KEY", "CREDENTIAL"]
    findings = []
    if os.path.exists(env_file):
        with open(env_file) as f:
            for i, line in enumerate(f, 1):
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    key = line.split("=")[0].upper()
                    if any(p in key for p in sensitive_patterns):
                        findings.append({
                            "severity": "MEDIUM",
                            "file": env_file,
                            "line": i,
                            "key": key,
                            "recommendation": "Use a secrets manager instead of .env files"
                        })
    return findings


if __name__ == "__main__":
    print("Running security scan...")
    results = {
        "file_permissions": check_file_permissions([".env", "config.yaml", "secrets/"]),
        "env_secrets": check_env_secrets(),
    }
    print(json.dumps(results, indent=2))
