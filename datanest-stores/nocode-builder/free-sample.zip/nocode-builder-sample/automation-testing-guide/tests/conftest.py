"""Shared test fixtures and configuration."""
import pytest
import json
import tempfile
from pathlib import Path


@pytest.fixture
def tmp_dir():
    """Provide a temporary directory for test files."""
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


@pytest.fixture
def sample_config(tmp_dir):
    """Create a sample configuration file."""
    config = {
        "name": "test",
        "version": "1.0.0",
        "debug": True,
        "settings": {"key": "value"}
    }
    path = tmp_dir / "config.json"
    path.write_text(json.dumps(config))
    return path


@pytest.fixture
def sample_data():
    """Provide sample test data."""
    return [
        {"id": 1, "name": "Alice", "role": "engineer"},
        {"id": 2, "name": "Bob", "role": "manager"},
        {"id": 3, "name": "Carol", "role": "designer"},
    ]
