"""Batch file processing utility."""
import os
import sys
import argparse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed


def process_file(filepath: Path) -> dict:
    """Process a single file. Customize this function."""
    stat = filepath.stat()
    return {
        "path": str(filepath),
        "size_bytes": stat.st_size,
        "modified": stat.st_mtime,
        "extension": filepath.suffix,
    }


def batch_process(directory: str, pattern: str = "*", workers: int = 4):
    """Process all matching files in directory."""
    path = Path(directory)
    files = list(path.rglob(pattern))
    print(f"Found {len(files)} files matching '{pattern}'")

    results = []
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(process_file, f): f for f in files}
        for future in as_completed(futures):
            try:
                results.append(future.result())
            except Exception as e:
                print(f"Error processing {futures[future]}: {e}")

    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Batch file processor")
    parser.add_argument("directory", help="Directory to process")
    parser.add_argument("--pattern", default="*", help="File glob pattern")
    parser.add_argument("--workers", type=int, default=4, help="Number of workers")
    args = parser.parse_args()

    results = batch_process(args.directory, args.pattern, args.workers)
    print(f"Processed {len(results)} files")
