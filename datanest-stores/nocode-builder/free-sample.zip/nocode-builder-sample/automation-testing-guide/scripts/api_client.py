"""Generic API client with retry logic."""
import urllib.request
import urllib.error
import json
import time
from typing import Any, Dict, Optional


class APIClient:
    """HTTP API client with retry and error handling."""

    def __init__(self, base_url: str, token: Optional[str] = None, max_retries: int = 3):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.max_retries = max_retries

    def _headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def request(self, method: str, path: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        body = json.dumps(data).encode() if data else None

        for attempt in range(self.max_retries):
            try:
                req = urllib.request.Request(url, data=body, headers=self._headers(), method=method)
                with urllib.request.urlopen(req, timeout=30) as resp:
                    return json.loads(resp.read())
            except urllib.error.HTTPError as e:
                if e.code >= 500 and attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                raise
            except urllib.error.URLError:
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                raise

    def get(self, path: str) -> Dict[str, Any]:
        return self.request("GET", path)

    def post(self, path: str, data: Dict) -> Dict[str, Any]:
        return self.request("POST", path, data)

    def put(self, path: str, data: Dict) -> Dict[str, Any]:
        return self.request("PUT", path, data)

    def delete(self, path: str) -> Dict[str, Any]:
        return self.request("DELETE", path)
