"""
Data Pipeline Testing Kit — Test Fixtures (conftest.py)
By Datanest Digital (https://datanest.dev) | Version 1.0.0

Shared pytest fixtures providing a SparkSession, sample DataFrames,
mock dbutils, and temporary directories for pipeline tests.
"""

from __future__ import annotations

import json
import tempfile
import shutil
from pathlib import Path
from typing import Generator

import pytest
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    DoubleType,
    TimestampType,
    BooleanType,
)

# Adjust the import path as needed for your project layout
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from mock_utils import MockDbutils  # noqa: E402


# =============================================================================
# SparkSession Fixture (session-scoped — shared across all tests)
# =============================================================================

@pytest.fixture(scope="session")
def spark() -> Generator[SparkSession, None, None]:
    """Create a local SparkSession for the entire test session."""
    session = (
        SparkSession.builder
        .master("local[2]")
        .appName("DataPipelineTestSuite")
        .config("spark.sql.shuffle.partitions", "4")
        .config("spark.default.parallelism", "4")
        .config("spark.ui.enabled", "false")
        .config("spark.driver.bindAddress", "127.0.0.1")
        .config("spark.sql.session.timeZone", "UTC")
        .getOrCreate()
    )
    session.sparkContext.setLogLevel("WARN")
    yield session
    session.stop()


# =============================================================================
# Temporary Directory Fixtures
# =============================================================================

@pytest.fixture
def tmp_dir() -> Generator[Path, None, None]:
    """Provide a temporary directory, cleaned up after each test."""
    d = Path(tempfile.mkdtemp(prefix="pipeline_test_"))
    yield d
    shutil.rmtree(d, ignore_errors=True)


@pytest.fixture
def tmp_delta_path(tmp_dir: Path) -> str:
    """Provide a path suitable for writing Delta tables."""
    return str(tmp_dir / "delta_output")


# =============================================================================
# Mock Fixtures
# =============================================================================

@pytest.fixture
def mock_dbutils() -> MockDbutils:
    """Provide a fresh MockDbutils instance with pre-configured scopes."""
    dbutils = MockDbutils()
    dbutils.secrets.create_scope("test-scope")
    dbutils.secrets.put("test-scope", "api-key", "test-api-key-12345")
    dbutils.secrets.put("test-scope", "db-password", "test-password")
    dbutils.widgets.text("environment", "test", "Environment")
    dbutils.widgets.text("run_date", "2025-01-15", "Run Date")
    return dbutils


# =============================================================================
# Sample Data Fixtures
# =============================================================================

FIXTURES_DIR = Path(__file__).resolve().parent.parent / "fixtures"


@pytest.fixture
def sample_customers_df(spark: SparkSession) -> DataFrame:
    """Load sample customers from the fixtures JSON file."""
    customers_path = FIXTURES_DIR / "sample_customers.json"
    if customers_path.exists():
        return spark.read.json(str(customers_path))

    # Fallback: create inline test data
    data = [
        ("cust_001", "Alice", "Smith", "alice@example.com", "enterprise", "active", 5200.50),
        ("cust_002", "Bob", "Johnson", "bob@example.com", "mid-market", "active", 1800.00),
        ("cust_003", "Carol", "Williams", "carol@example.com", "startup", "churned", 350.25),
        ("cust_004", "David", "Brown", "david@example.com", "small-business", "active", 720.00),
        ("cust_005", "Eve", "Davis", "eve@example.com", "enterprise", "inactive", 4100.00),
    ]
    schema = StructType([
        StructField("customer_id", StringType(), False),
        StructField("first_name", StringType(), False),
        StructField("last_name", StringType(), False),
        StructField("email", StringType(), False),
        StructField("segment", StringType(), False),
        StructField("status", StringType(), False),
        StructField("lifetime_value", DoubleType(), False),
    ])
    return spark.createDataFrame(data, schema=schema)


@pytest.fixture
def sample_orders_df(spark: SparkSession) -> DataFrame:
    """Load sample orders from the fixtures JSON file."""
    orders_path = FIXTURES_DIR / "sample_orders.json"
    if orders_path.exists():
        return spark.read.json(str(orders_path))

    # Fallback: create inline test data
    data = [
        ("ord_001", "cust_001", "Widget Pro", 2, 49.99, 99.98, "completed"),
        ("ord_002", "cust_001", "Data Sync License", 1, 199.00, 199.00, "completed"),
        ("ord_003", "cust_002", "Analytics Dashboard", 1, 299.00, 299.00, "pending"),
        ("ord_004", "cust_003", "API Gateway", 3, 29.99, 89.97, "cancelled"),
        ("ord_005", "cust_004", "ML Pipeline Kit", 1, 149.00, 149.00, "completed"),
    ]
    schema = StructType([
        StructField("order_id", StringType(), False),
        StructField("customer_id", StringType(), False),
        StructField("product_name", StringType(), False),
        StructField("quantity", IntegerType(), False),
        StructField("unit_price", DoubleType(), False),
        StructField("total_amount", DoubleType(), False),
        StructField("order_status", StringType(), False),
    ])
    return spark.createDataFrame(data, schema=schema)


@pytest.fixture
def empty_df(spark: SparkSession) -> DataFrame:
    """Provide an empty DataFrame with a basic schema."""
    schema = StructType([
        StructField("id", StringType(), False),
        StructField("value", IntegerType(), True),
    ])
    return spark.createDataFrame([], schema=schema)
