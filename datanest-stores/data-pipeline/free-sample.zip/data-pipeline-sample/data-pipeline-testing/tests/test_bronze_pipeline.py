"""
Data Pipeline Testing Kit — Bronze Layer Tests
By Datanest Digital (https://datanest.dev) | Version 1.0.0

Tests for the bronze (raw ingestion) layer of a medallion architecture pipeline.
Validates raw data loading, schema enforcement, metadata enrichment, and
deduplication at the landing zone.

These tests demonstrate how to use the toolkit's assertions, mock utilities,
and data generators to verify bronze-layer behaviour.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import List

import pytest
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    DoubleType,
    TimestampType,
    BooleanType,
)

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from assertions import DataFrameAssertions  # noqa: E402
from data_generators import CustomerGenerator, OrderGenerator  # noqa: E402
from mock_utils import MockDbutils  # noqa: E402


# =============================================================================
# Bronze Ingestion Helpers (example pipeline code under test)
# =============================================================================

def bronze_ingest_json(spark: SparkSession, path: str) -> DataFrame:
    """Simulate bronze-layer JSON ingestion with metadata columns."""
    df = spark.read.option("multiLine", True).json(path)
    return (
        df
        .withColumn("_ingested_at", F.current_timestamp())
        .withColumn("_source_file", F.input_file_name())
        .withColumn("_batch_id", F.lit("batch_001"))
    )


def bronze_enforce_schema(df: DataFrame, expected_schema: StructType) -> DataFrame:
    """Cast columns to match expected schema, drop unexpected columns."""
    result = df
    expected_names = {f.name for f in expected_schema.fields}
    # Keep only expected columns (plus metadata cols starting with _)
    keep_cols = [c for c in df.columns if c in expected_names or c.startswith("_")]
    result = result.select(*keep_cols)
    # Cast to expected types
    for field in expected_schema.fields:
        if field.name in result.columns:
            result = result.withColumn(field.name, F.col(field.name).cast(field.dataType))
    return result


def bronze_deduplicate(df: DataFrame, key_columns: List[str]) -> DataFrame:
    """Remove exact duplicates based on key columns, keeping the first."""
    from pyspark.sql.window import Window

    w = Window.partitionBy(*key_columns).orderBy(F.col("_ingested_at").asc())
    return (
        df
        .withColumn("_row_num", F.row_number().over(w))
        .filter(F.col("_row_num") == 1)
        .drop("_row_num")
    )


# =============================================================================
# Test Fixtures
# =============================================================================

CUSTOMER_SCHEMA = StructType([
    StructField("customer_id", StringType(), False),
    StructField("first_name", StringType(), True),
    StructField("last_name", StringType(), True),
    StructField("email", StringType(), True),
    StructField("segment", StringType(), True),
    StructField("region", StringType(), True),
    StructField("status", StringType(), True),
    StructField("lifetime_value", DoubleType(), True),
    StructField("is_premium", BooleanType(), True),
])

FIXTURES_DIR = Path(__file__).resolve().parent.parent / "fixtures"


@pytest.fixture
def assertions(spark: SparkSession) -> DataFrameAssertions:
    """Provide a DataFrameAssertions instance."""
    return DataFrameAssertions(spark)


@pytest.fixture
def raw_customers_df(spark: SparkSession) -> DataFrame:
    """Load raw customer data as Spark would ingest it."""
    path = str(FIXTURES_DIR / "sample_customers.json")
    return spark.read.option("multiLine", True).json(path)


# =============================================================================
# Tests: Raw Ingestion
# =============================================================================

class TestBronzeIngestion:
    """Tests for the raw ingestion step of the bronze layer."""

    def test_json_ingestion_loads_all_records(
        self, spark: SparkSession, assertions: DataFrameAssertions
    ) -> None:
        """Ingested DataFrame should contain all 50 customer records."""
        path = str(FIXTURES_DIR / "sample_customers.json")
        df = bronze_ingest_json(spark, path)
        assertions.assert_row_count(df, 50)

    def test_ingestion_adds_metadata_columns(
        self, spark: SparkSession
    ) -> None:
        """Bronze ingestion should add _ingested_at, _source_file, _batch_id."""
        path = str(FIXTURES_DIR / "sample_customers.json")
        df = bronze_ingest_json(spark, path)
        metadata_cols = {"_ingested_at", "_source_file", "_batch_id"}
        assert metadata_cols.issubset(set(df.columns)), (
            f"Missing metadata columns: {metadata_cols - set(df.columns)}"
        )

    def test_ingested_at_is_populated(self, spark: SparkSession) -> None:
        """Every row should have a non-null _ingested_at timestamp."""
        path = str(FIXTURES_DIR / "sample_customers.json")
        df = bronze_ingest_json(spark, path)
        null_count = df.filter(F.col("_ingested_at").isNull()).count()
        assert null_count == 0, f"Found {null_count} rows with null _ingested_at"

    def test_batch_id_is_consistent(self, spark: SparkSession) -> None:
        """All rows in a single ingestion batch should share the same batch_id."""
        path = str(FIXTURES_DIR / "sample_customers.json")
        df = bronze_ingest_json(spark, path)
        distinct_batches = df.select("_batch_id").distinct().count()
        assert distinct_batches == 1, f"Expected 1 batch_id, got {distinct_batches}"


# =============================================================================
# Tests: Schema Enforcement
# =============================================================================

class TestBronzeSchemaEnforcement:
    """Tests for schema enforcement at the bronze layer."""

    def test_enforce_schema_keeps_expected_columns(
        self, raw_customers_df: DataFrame
    ) -> None:
        """After schema enforcement, all expected columns should be present."""
        df = bronze_enforce_schema(raw_customers_df, CUSTOMER_SCHEMA)
        expected_names = {f.name for f in CUSTOMER_SCHEMA.fields}
        actual_names = set(df.columns)
        assert expected_names.issubset(actual_names), (
            f"Missing columns: {expected_names - actual_names}"
        )

    def test_enforce_schema_preserves_metadata_columns(
        self, spark: SparkSession
    ) -> None:
        """Metadata columns (prefixed with _) should survive schema enforcement."""
        path = str(FIXTURES_DIR / "sample_customers.json")
        df = bronze_ingest_json(spark, path)
        enforced = bronze_enforce_schema(df, CUSTOMER_SCHEMA)
        meta_cols = [c for c in enforced.columns if c.startswith("_")]
        assert len(meta_cols) >= 3, f"Expected >= 3 metadata columns, got {meta_cols}"

    def test_enforce_schema_casts_types(
        self, raw_customers_df: DataFrame
    ) -> None:
        """lifetime_value should be cast to DoubleType after enforcement."""
        df = bronze_enforce_schema(raw_customers_df, CUSTOMER_SCHEMA)
        lv_field = [f for f in df.schema.fields if f.name == "lifetime_value"]
        assert len(lv_field) == 1
        assert isinstance(lv_field[0].dataType, DoubleType), (
            f"Expected DoubleType, got {lv_field[0].dataType}"
        )

    def test_enforce_schema_drops_extra_columns(
        self, spark: SparkSession
    ) -> None:
        """Columns not in the expected schema (and not metadata) should be dropped."""
        data = [("cust_001", "Alice", "extra_value")]
        df = spark.createDataFrame(data, ["customer_id", "first_name", "bonus_field"])
        minimal_schema = StructType([
            StructField("customer_id", StringType(), False),
            StructField("first_name", StringType(), True),
        ])
        enforced = bronze_enforce_schema(df, minimal_schema)
        assert "bonus_field" not in enforced.columns


# =============================================================================
# Tests: Deduplication
# =============================================================================

class TestBronzeDeduplication:
    """Tests for deduplication at the bronze layer."""

    def test_dedup_removes_exact_duplicates(
        self, spark: SparkSession
    ) -> None:
        """Duplicate rows (by key columns) should be reduced to one."""
        data = [
            ("cust_001", "Alice", "2025-01-01T10:00:00"),
            ("cust_001", "Alice", "2025-01-01T10:05:00"),  # duplicate key
            ("cust_002", "Bob", "2025-01-01T10:00:00"),
        ]
        df = spark.createDataFrame(data, ["customer_id", "name", "_ingested_at"])
        deduped = bronze_deduplicate(df, ["customer_id"])
        assert deduped.count() == 2, f"Expected 2 rows after dedup, got {deduped.count()}"

    def test_dedup_keeps_earliest_record(
        self, spark: SparkSession
    ) -> None:
        """When duplicates exist, the earliest ingested record should be kept."""
        data = [
            ("cust_001", "old_value", "2025-01-01T08:00:00"),
            ("cust_001", "new_value", "2025-01-01T12:00:00"),
        ]
        df = spark.createDataFrame(data, ["customer_id", "name", "_ingested_at"])
        deduped = bronze_deduplicate(df, ["customer_id"])
        row = deduped.collect()[0]
        assert row["name"] == "old_value", f"Expected 'old_value', got '{row['name']}'"

    def test_dedup_with_no_duplicates_is_noop(
        self, spark: SparkSession, assertions: DataFrameAssertions
    ) -> None:
        """When no duplicates exist, row count should remain unchanged."""
        data = [
            ("cust_001", "Alice", "2025-01-01T10:00:00"),
            ("cust_002", "Bob", "2025-01-01T10:00:00"),
            ("cust_003", "Carol", "2025-01-01T10:00:00"),
        ]
        df = spark.createDataFrame(data, ["customer_id", "name", "_ingested_at"])
        deduped = bronze_deduplicate(df, ["customer_id"])
        assertions.assert_row_count(deduped, 3)

    def test_dedup_composite_key(self, spark: SparkSession) -> None:
        """Deduplication should work on composite keys."""
        data = [
            ("cust_001", "prod_A", "2025-01-01T10:00:00"),
            ("cust_001", "prod_A", "2025-01-01T11:00:00"),  # dup on composite
            ("cust_001", "prod_B", "2025-01-01T10:00:00"),  # different product
        ]
        df = spark.createDataFrame(data, ["customer_id", "product", "_ingested_at"])
        deduped = bronze_deduplicate(df, ["customer_id", "product"])
        assert deduped.count() == 2


# =============================================================================
# Tests: Data Quality at Bronze
# =============================================================================

class TestBronzeDataQuality:
    """Basic data quality checks at the bronze layer."""

    def test_customer_ids_are_not_null(
        self, raw_customers_df: DataFrame, assertions: DataFrameAssertions
    ) -> None:
        """customer_id must never be null in raw data."""
        assertions.assert_no_nulls(raw_customers_df, ["customer_id"])

    def test_customer_ids_are_unique(
        self, raw_customers_df: DataFrame, assertions: DataFrameAssertions
    ) -> None:
        """customer_id must be unique across the dataset."""
        assertions.assert_unique(raw_customers_df, ["customer_id"])

    def test_emails_have_valid_format(
        self, raw_customers_df: DataFrame
    ) -> None:
        """All email addresses should contain an @ symbol."""
        invalid = raw_customers_df.filter(
            ~F.col("email").rlike(r"^[^@]+@[^@]+\.[^@]+$")
        )
        assert invalid.count() == 0, (
            f"Found {invalid.count()} invalid email addresses"
        )

    def test_status_values_are_known(
        self, raw_customers_df: DataFrame
    ) -> None:
        """Status should be one of the known valid values."""
        valid_statuses = {"active", "inactive", "churned", "trial"}
        actual_statuses = {
            row["status"]
            for row in raw_customers_df.select("status").distinct().collect()
        }
        unknown = actual_statuses - valid_statuses
        assert len(unknown) == 0, f"Unknown status values: {unknown}"
