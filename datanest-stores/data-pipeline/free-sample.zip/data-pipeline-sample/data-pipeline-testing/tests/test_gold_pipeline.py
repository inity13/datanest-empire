"""
Data Pipeline Testing Kit — Gold Layer Tests
By Datanest Digital (https://datanest.dev) | Version 1.0.0

Tests for the gold (business-ready / aggregated) layer of a medallion
architecture pipeline. Validates aggregation logic, KPI computation,
referential integrity, and snapshot comparison against expected outputs.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    DoubleType,
)

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from assertions import DataFrameAssertions  # noqa: E402
from snapshot_testing import SnapshotManager  # noqa: E402


FIXTURES_DIR = Path(__file__).resolve().parent.parent / "fixtures"


# =============================================================================
# Gold Transform Helpers (example pipeline code under test)
# =============================================================================

def gold_customer_summary(
    customers_df: DataFrame, orders_df: DataFrame
) -> DataFrame:
    """Aggregate orders per customer to produce a summary table.

    Returns one row per customer with order counts, revenue, and derived KPIs.
    """
    order_stats = (
        orders_df
        .groupBy("customer_id")
        .agg(
            F.count("order_id").alias("total_orders"),
            F.sum(
                F.when(F.col("order_status") == "completed", 1).otherwise(0)
            ).alias("completed_orders"),
            F.sum(
                F.when(F.col("order_status") == "cancelled", 1).otherwise(0)
            ).alias("cancelled_orders"),
            F.round(F.sum("total_amount"), 2).alias("total_revenue"),
        )
    )

    summary = (
        customers_df
        .select("customer_id", "first_name", "last_name", "segment", "status")
        .join(order_stats, on="customer_id", how="inner")
        .withColumn(
            "avg_order_value",
            F.round(F.col("total_revenue") / F.col("total_orders"), 2),
        )
        .withColumn(
            "completion_rate",
            F.round(F.col("completed_orders") / F.col("total_orders"), 4),
        )
    )
    return summary


def gold_segment_revenue(summary_df: DataFrame) -> DataFrame:
    """Aggregate customer summary into per-segment revenue metrics."""
    return (
        summary_df
        .groupBy("segment")
        .agg(
            F.count("customer_id").alias("customer_count"),
            F.round(F.sum("total_revenue"), 2).alias("segment_revenue"),
            F.round(F.avg("avg_order_value"), 2).alias("avg_order_value"),
            F.round(F.avg("completion_rate"), 4).alias("avg_completion_rate"),
        )
        .orderBy(F.col("segment_revenue").desc())
    )


def gold_top_customers(summary_df: DataFrame, top_n: int = 10) -> DataFrame:
    """Return the top N customers by total revenue."""
    return (
        summary_df
        .orderBy(F.col("total_revenue").desc())
        .limit(top_n)
    )


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def assertions(spark: SparkSession) -> DataFrameAssertions:
    return DataFrameAssertions(spark)


@pytest.fixture
def customers_df(spark: SparkSession) -> DataFrame:
    """Load customers from fixture file."""
    return spark.read.option("multiLine", True).json(
        str(FIXTURES_DIR / "sample_customers.json")
    )


@pytest.fixture
def orders_df(spark: SparkSession) -> DataFrame:
    """Load orders from fixture file."""
    return spark.read.option("multiLine", True).json(
        str(FIXTURES_DIR / "sample_orders.json")
    )


@pytest.fixture
def customer_summary_df(
    spark: SparkSession, customers_df: DataFrame, orders_df: DataFrame
) -> DataFrame:
    """Compute the customer summary gold table."""
    return gold_customer_summary(customers_df, orders_df)


@pytest.fixture
def snapshot_mgr(tmp_path: Path) -> SnapshotManager:
    """Provide a SnapshotManager using a temp directory for golden files."""
    return SnapshotManager(snapshot_dir=str(tmp_path / "snapshots"))


# =============================================================================
# Tests: Customer Summary Aggregation
# =============================================================================

class TestGoldCustomerSummary:
    """Tests for the customer summary gold-layer transform."""

    def test_summary_has_expected_columns(
        self, customer_summary_df: DataFrame
    ) -> None:
        expected = {
            "customer_id", "first_name", "last_name", "segment", "status",
            "total_orders", "completed_orders", "cancelled_orders",
            "total_revenue", "avg_order_value", "completion_rate",
        }
        actual = set(customer_summary_df.columns)
        assert expected.issubset(actual), f"Missing columns: {expected - actual}"

    def test_summary_no_null_customer_ids(
        self, customer_summary_df: DataFrame, assertions: DataFrameAssertions
    ) -> None:
        assertions.assert_no_nulls(customer_summary_df, ["customer_id"])

    def test_summary_unique_customer_ids(
        self, customer_summary_df: DataFrame, assertions: DataFrameAssertions
    ) -> None:
        assertions.assert_unique(customer_summary_df, ["customer_id"])

    def test_total_orders_positive(
        self, customer_summary_df: DataFrame
    ) -> None:
        """Every customer in the summary must have at least one order."""
        zero_orders = customer_summary_df.filter(
            F.col("total_orders") <= 0
        ).count()
        assert zero_orders == 0, f"{zero_orders} customers have 0 orders"

    def test_completed_plus_other_equals_total(
        self, customer_summary_df: DataFrame
    ) -> None:
        """completed + cancelled should not exceed total_orders."""
        bad_rows = customer_summary_df.filter(
            (F.col("completed_orders") + F.col("cancelled_orders"))
            > F.col("total_orders")
        ).count()
        assert bad_rows == 0, (
            f"{bad_rows} rows where completed+cancelled > total"
        )

    def test_avg_order_value_calculation(
        self, customer_summary_df: DataFrame
    ) -> None:
        """avg_order_value should equal total_revenue / total_orders."""
        df = customer_summary_df.withColumn(
            "expected_avg",
            F.round(F.col("total_revenue") / F.col("total_orders"), 2),
        )
        mismatches = df.filter(
            F.abs(F.col("avg_order_value") - F.col("expected_avg")) > 0.01
        ).count()
        assert mismatches == 0, f"{mismatches} rows with wrong avg_order_value"

    def test_completion_rate_range(
        self, customer_summary_df: DataFrame
    ) -> None:
        """completion_rate should be between 0.0 and 1.0."""
        out_of_range = customer_summary_df.filter(
            (F.col("completion_rate") < 0.0) | (F.col("completion_rate") > 1.0)
        ).count()
        assert out_of_range == 0, (
            f"{out_of_range} rows with completion_rate outside [0, 1]"
        )


# =============================================================================
# Tests: Segment Revenue
# =============================================================================

class TestGoldSegmentRevenue:
    """Tests for the per-segment revenue aggregation."""

    def test_segment_revenue_not_empty(
        self, customer_summary_df: DataFrame
    ) -> None:
        seg = gold_segment_revenue(customer_summary_df)
        assert seg.count() > 0, "Segment revenue table is empty"

    def test_segment_revenue_ordered_descending(
        self, customer_summary_df: DataFrame
    ) -> None:
        seg = gold_segment_revenue(customer_summary_df)
        revenues = [row["segment_revenue"] for row in seg.collect()]
        assert revenues == sorted(revenues, reverse=True), (
            "Segment revenue is not sorted descending"
        )

    def test_segment_customer_count_sums_to_total(
        self, customer_summary_df: DataFrame
    ) -> None:
        seg = gold_segment_revenue(customer_summary_df)
        seg_total = seg.agg(F.sum("customer_count")).collect()[0][0]
        actual_total = customer_summary_df.count()
        assert seg_total == actual_total, (
            f"Segment customer count {seg_total} != total {actual_total}"
        )


# =============================================================================
# Tests: Top Customers
# =============================================================================

class TestGoldTopCustomers:
    """Tests for the top-N customers query."""

    def test_top_10_returns_at_most_10(
        self, customer_summary_df: DataFrame
    ) -> None:
        top = gold_top_customers(customer_summary_df, top_n=10)
        assert top.count() <= 10

    def test_top_customers_sorted_by_revenue(
        self, customer_summary_df: DataFrame
    ) -> None:
        top = gold_top_customers(customer_summary_df, top_n=10)
        revenues = [row["total_revenue"] for row in top.collect()]
        assert revenues == sorted(revenues, reverse=True)

    def test_top_1_is_highest_revenue(
        self, customer_summary_df: DataFrame
    ) -> None:
        top = gold_top_customers(customer_summary_df, top_n=1)
        max_revenue = customer_summary_df.agg(
            F.max("total_revenue")
        ).collect()[0][0]
        top_revenue = top.collect()[0]["total_revenue"]
        assert abs(top_revenue - max_revenue) < 0.01


# =============================================================================
# Tests: Snapshot Comparison
# =============================================================================

class TestGoldSnapshotComparison:
    """Compare gold-layer output against the expected_outputs fixture."""

    def test_customer_summary_matches_expected_structure(
        self, customer_summary_df: DataFrame
    ) -> None:
        """Verify the generated summary has the same columns as the fixture."""
        expected_path = FIXTURES_DIR / "expected_outputs" / "customer_summary.json"
        if not expected_path.exists():
            pytest.skip("Expected output fixture not found")

        with open(expected_path) as f:
            expected = json.load(f)

        expected_keys = set(expected[0].keys()) if expected else set()
        actual_keys = set(customer_summary_df.columns)
        # The fixture may have 'unique_products' which isn't in our transform
        common_keys = expected_keys & actual_keys
        assert len(common_keys) >= 8, (
            f"Only {len(common_keys)} common columns between fixture and output"
        )

    def test_customer_summary_row_count_reasonable(
        self, customer_summary_df: DataFrame
    ) -> None:
        """Summary should have a reasonable number of rows given 50 customers."""
        count = customer_summary_df.count()
        # Not all customers may have orders
        assert 10 <= count <= 50, f"Unexpected row count: {count}"
