"""
Data Pipeline Testing Kit — Silver Layer Tests
By Datanest Digital (https://datanest.dev) | Version 1.0.0

Tests for the silver (cleansed / enriched) layer of a medallion architecture
pipeline. Validates data cleaning, type casting, deduplication, null handling,
and business-rule transformations.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    DoubleType,
    TimestampType,
    BooleanType,
)

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from assertions import DataFrameAssertions  # noqa: E402


# =============================================================================
# Silver Transform Helpers (example pipeline code under test)
# =============================================================================

def silver_clean_strings(df: DataFrame, columns: list[str]) -> DataFrame:
    """Trim whitespace and lower-case the specified string columns."""
    result = df
    for col_name in columns:
        result = result.withColumn(
            col_name,
            F.lower(F.trim(F.col(col_name))),
        )
    return result


def silver_standardise_nulls(df: DataFrame) -> DataFrame:
    """Replace common null-like string values with actual nulls."""
    null_values = ["", "null", "none", "n/a", "na", "N/A"]
    result = df
    for col_info in df.schema.fields:
        if isinstance(col_info.dataType, StringType):
            result = result.withColumn(
                col_info.name,
                F.when(
                    F.trim(F.col(col_info.name)).isin(null_values),
                    F.lit(None).cast(StringType()),
                ).otherwise(F.col(col_info.name)),
            )
    return result


def silver_add_derived_columns(df: DataFrame) -> DataFrame:
    """Add computed columns for the silver layer."""
    return (
        df
        .withColumn(
            "full_name",
            F.concat_ws(" ", F.col("first_name"), F.col("last_name")),
        )
        .withColumn(
            "value_tier",
            F.when(F.col("lifetime_value") >= 5000, "platinum")
            .when(F.col("lifetime_value") >= 2000, "gold")
            .when(F.col("lifetime_value") >= 500, "silver")
            .otherwise("bronze"),
        )
    )


def silver_filter_valid_records(df: DataFrame) -> DataFrame:
    """Drop rows that fail basic validity checks."""
    return df.filter(
        F.col("customer_id").isNotNull()
        & F.col("email").isNotNull()
        & F.col("email").rlike(r"^[^@]+@[^@]+\.[^@]+$")
    )


# =============================================================================
# Fixtures
# =============================================================================

FIXTURES_DIR = Path(__file__).resolve().parent.parent / "fixtures"


@pytest.fixture
def assertions(spark: SparkSession) -> DataFrameAssertions:
    return DataFrameAssertions(spark)


@pytest.fixture
def raw_customers_df(spark: SparkSession) -> DataFrame:
    """Load raw fixture data (simulating bronze output)."""
    path = str(FIXTURES_DIR / "sample_customers.json")
    return spark.read.option("multiLine", True).json(path)


@pytest.fixture
def dirty_customers_df(spark: SparkSession) -> DataFrame:
    """DataFrame with intentionally messy data for cleaning tests."""
    data = [
        ("cust_001", "  Alice ", " Smith", "alice@example.com", "enterprise", "active", 5200.0, True),
        ("cust_002", "Bob", "  Johnson  ", "bob@example.com", "mid-market", "active", 1800.0, False),
        ("cust_003", "Carol", "Williams", "N/A", "startup", "churned", 350.0, False),
        (None, "David", "Brown", "david@example.com", "small-business", "", 720.0, False),
        ("cust_005", "Eve", "Davis", "invalid-email", "enterprise", "null", 4100.0, True),
    ]
    schema = StructType([
        StructField("customer_id", StringType(), True),
        StructField("first_name", StringType(), True),
        StructField("last_name", StringType(), True),
        StructField("email", StringType(), True),
        StructField("segment", StringType(), True),
        StructField("status", StringType(), True),
        StructField("lifetime_value", DoubleType(), True),
        StructField("is_premium", BooleanType(), True),
    ])
    return spark.createDataFrame(data, schema=schema)


# =============================================================================
# Tests: String Cleaning
# =============================================================================

class TestSilverStringCleaning:
    """Tests for whitespace trimming and lower-casing."""

    def test_trim_removes_leading_trailing_spaces(
        self, dirty_customers_df: DataFrame
    ) -> None:
        cleaned = silver_clean_strings(dirty_customers_df, ["first_name", "last_name"])
        rows = {
            r["customer_id"]: r
            for r in cleaned.collect()
            if r["customer_id"] is not None
        }
        assert rows["cust_001"]["first_name"] == "alice"
        assert rows["cust_002"]["last_name"] == "johnson"

    def test_lower_cases_strings(self, spark: SparkSession) -> None:
        data = [("cust_001", "ALICE", "SMITH")]
        df = spark.createDataFrame(data, ["customer_id", "first_name", "last_name"])
        cleaned = silver_clean_strings(df, ["first_name", "last_name"])
        row = cleaned.collect()[0]
        assert row["first_name"] == "alice"
        assert row["last_name"] == "smith"

    def test_clean_is_idempotent(self, spark: SparkSession) -> None:
        """Cleaning an already-clean DataFrame should produce the same result."""
        data = [("cust_001", "alice", "smith")]
        df = spark.createDataFrame(data, ["customer_id", "first_name", "last_name"])
        once = silver_clean_strings(df, ["first_name", "last_name"])
        twice = silver_clean_strings(once, ["first_name", "last_name"])
        assert once.collect() == twice.collect()


# =============================================================================
# Tests: Null Standardisation
# =============================================================================

class TestSilverNullStandardisation:
    """Tests for replacing null-like strings with actual nulls."""

    def test_n_a_becomes_null(self, dirty_customers_df: DataFrame) -> None:
        cleaned = silver_standardise_nulls(dirty_customers_df)
        carol = cleaned.filter(F.col("customer_id") == "cust_003").collect()[0]
        assert carol["email"] is None, f"Expected None, got '{carol['email']}'"

    def test_empty_string_becomes_null(self, dirty_customers_df: DataFrame) -> None:
        cleaned = silver_standardise_nulls(dirty_customers_df)
        david = cleaned.filter(F.col("first_name") == "David").collect()[0]
        assert david["status"] is None, f"Expected None, got '{david['status']}'"

    def test_null_string_becomes_null(self, dirty_customers_df: DataFrame) -> None:
        cleaned = silver_standardise_nulls(dirty_customers_df)
        eve = cleaned.filter(F.col("customer_id") == "cust_005").collect()[0]
        assert eve["status"] is None

    def test_valid_strings_unchanged(self, dirty_customers_df: DataFrame) -> None:
        cleaned = silver_standardise_nulls(dirty_customers_df)
        alice = cleaned.filter(F.col("customer_id") == "cust_001").collect()[0]
        assert alice["status"] == "active"


# =============================================================================
# Tests: Derived Columns
# =============================================================================

class TestSilverDerivedColumns:
    """Tests for computed / enrichment columns."""

    def test_full_name_concatenation(self, spark: SparkSession) -> None:
        data = [("cust_001", "Alice", "Smith", "alice@example.com", 5000.0)]
        df = spark.createDataFrame(
            data, ["customer_id", "first_name", "last_name", "email", "lifetime_value"]
        )
        enriched = silver_add_derived_columns(df)
        row = enriched.collect()[0]
        assert row["full_name"] == "Alice Smith"

    def test_value_tier_platinum(self, spark: SparkSession) -> None:
        data = [("c1", "A", "B", "a@b.com", 10000.0)]
        df = spark.createDataFrame(
            data, ["customer_id", "first_name", "last_name", "email", "lifetime_value"]
        )
        row = silver_add_derived_columns(df).collect()[0]
        assert row["value_tier"] == "platinum"

    def test_value_tier_gold(self, spark: SparkSession) -> None:
        data = [("c1", "A", "B", "a@b.com", 3000.0)]
        df = spark.createDataFrame(
            data, ["customer_id", "first_name", "last_name", "email", "lifetime_value"]
        )
        row = silver_add_derived_columns(df).collect()[0]
        assert row["value_tier"] == "gold"

    def test_value_tier_silver(self, spark: SparkSession) -> None:
        data = [("c1", "A", "B", "a@b.com", 800.0)]
        df = spark.createDataFrame(
            data, ["customer_id", "first_name", "last_name", "email", "lifetime_value"]
        )
        row = silver_add_derived_columns(df).collect()[0]
        assert row["value_tier"] == "silver"

    def test_value_tier_bronze(self, spark: SparkSession) -> None:
        data = [("c1", "A", "B", "a@b.com", 100.0)]
        df = spark.createDataFrame(
            data, ["customer_id", "first_name", "last_name", "email", "lifetime_value"]
        )
        row = silver_add_derived_columns(df).collect()[0]
        assert row["value_tier"] == "bronze"


# =============================================================================
# Tests: Validity Filtering
# =============================================================================

class TestSilverValidityFilter:
    """Tests for filtering out invalid rows."""

    def test_null_customer_id_is_dropped(
        self, dirty_customers_df: DataFrame
    ) -> None:
        valid = silver_filter_valid_records(dirty_customers_df)
        null_ids = valid.filter(F.col("customer_id").isNull()).count()
        assert null_ids == 0

    def test_invalid_email_is_dropped(
        self, dirty_customers_df: DataFrame
    ) -> None:
        valid = silver_filter_valid_records(dirty_customers_df)
        # cust_005 has "invalid-email" — should be removed
        assert valid.filter(F.col("customer_id") == "cust_005").count() == 0

    def test_valid_records_are_kept(
        self, dirty_customers_df: DataFrame, assertions: DataFrameAssertions
    ) -> None:
        valid = silver_filter_valid_records(dirty_customers_df)
        # cust_001 and cust_002 should survive (valid id + email)
        assert valid.filter(F.col("customer_id") == "cust_001").count() == 1
        assert valid.filter(F.col("customer_id") == "cust_002").count() == 1


# =============================================================================
# Tests: Full Silver Pipeline (integration)
# =============================================================================

class TestSilverPipelineIntegration:
    """End-to-end integration test for the silver layer transforms."""

    def test_full_silver_transform(
        self, raw_customers_df: DataFrame, assertions: DataFrameAssertions
    ) -> None:
        """Run all silver transforms in order on fixture data."""
        df = raw_customers_df
        df = silver_clean_strings(df, ["first_name", "last_name", "email"])
        df = silver_standardise_nulls(df)
        df = silver_filter_valid_records(df)
        df = silver_add_derived_columns(df)

        # Should have full_name and value_tier columns
        assert "full_name" in df.columns
        assert "value_tier" in df.columns

        # All surviving rows must have valid customer_id and email
        assertions.assert_no_nulls(df, ["customer_id", "email"])
        assertions.assert_unique(df, ["customer_id"])
