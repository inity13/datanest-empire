"""
Data Pipeline Testing Kit — Mock Utilities
By Datanest Digital (https://datanest.dev) | Version 1.0.0

Helpers for mocking Databricks-specific objects (dbutils, widgets, secrets)
and external service dependencies in unit tests.

Usage:
    from mock_utils import MockDbutils, MockSecretScope, create_mock_spark_session

    dbutils = MockDbutils()
    dbutils.secrets.put("my-scope", "api-key", "test-value-123")
    assert dbutils.secrets.get("my-scope", "api-key") == "test-value-123"
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch


# =============================================================================
# Mock dbutils
# =============================================================================

class MockWidgets:
    """Mock for dbutils.widgets — stores and retrieves widget values.

    Example:
        widgets = MockWidgets()
        widgets.text("env", "dev", "Environment")
        assert widgets.get("env") == "dev"
    """

    def __init__(self) -> None:
        self._values: Dict[str, str] = {}

    def text(self, name: str, default: str, label: str = "") -> None:
        """Register a text widget with a default value."""
        if name not in self._values:
            self._values[name] = default

    def dropdown(
        self, name: str, default: str, choices: List[str], label: str = ""
    ) -> None:
        """Register a dropdown widget with a default value."""
        if name not in self._values:
            self._values[name] = default

    def combobox(
        self, name: str, default: str, choices: List[str], label: str = ""
    ) -> None:
        """Register a combobox widget with a default value."""
        if name not in self._values:
            self._values[name] = default

    def multiselect(
        self, name: str, default: str, choices: List[str], label: str = ""
    ) -> None:
        """Register a multiselect widget."""
        if name not in self._values:
            self._values[name] = default

    def get(self, name: str) -> str:
        """Get the current value of a widget."""
        if name not in self._values:
            raise ValueError(f"Widget '{name}' not found")
        return self._values[name]

    def remove(self, name: str) -> None:
        """Remove a widget."""
        self._values.pop(name, None)

    def removeAll(self) -> None:
        """Remove all widgets."""
        self._values.clear()

    def set_value(self, name: str, value: str) -> None:
        """Manually set a widget value (for test setup)."""
        self._values[name] = value


class MockSecretScope:
    """Mock for dbutils.secrets — in-memory secret storage.

    Example:
        secrets = MockSecretScope()
        secrets.put("my-scope", "db-password", "secret123")
        assert secrets.get("my-scope", "db-password") == "secret123"
    """

    def __init__(self) -> None:
        self._scopes: Dict[str, Dict[str, str]] = {}

    def get(self, scope: str, key: str) -> str:
        """Get a secret value."""
        if scope not in self._scopes or key not in self._scopes[scope]:
            raise ValueError(f"Secret '{scope}/{key}' not found")
        return self._scopes[scope][key]

    def getBytes(self, scope: str, key: str) -> bytes:
        """Get a secret value as bytes."""
        return self.get(scope, key).encode("utf-8")

    def list(self, scope: str) -> List[Dict[str, str]]:
        """List all secret keys in a scope."""
        if scope not in self._scopes:
            return []
        return [{"key": k} for k in self._scopes[scope]]

    def listScopes(self) -> List[Dict[str, str]]:
        """List all secret scopes."""
        return [{"name": name} for name in self._scopes]

    # --- Test helper methods (not part of real dbutils API) ---

    def put(self, scope: str, key: str, value: str) -> None:
        """Store a secret value (for test setup)."""
        if scope not in self._scopes:
            self._scopes[scope] = {}
        self._scopes[scope][key] = value

    def create_scope(self, scope: str) -> None:
        """Create a secret scope (for test setup)."""
        if scope not in self._scopes:
            self._scopes[scope] = {}


class MockFS:
    """Mock for dbutils.fs — simulates basic file system operations.

    Tracks calls for assertion in tests but does not perform real I/O.
    """

    def __init__(self) -> None:
        self._files: Dict[str, str] = {}
        self._call_log: List[Dict[str, Any]] = []

    def ls(self, path: str) -> List[Dict[str, Any]]:
        """List files at a path."""
        self._call_log.append({"method": "ls", "path": path})
        return [
            {"path": f"{path}/{name}", "name": name, "size": len(content)}
            for name, content in self._files.items()
            if name.startswith(path.rstrip("/"))
        ]

    def cp(self, src: str, dst: str, recurse: bool = False) -> bool:
        """Copy a file."""
        self._call_log.append({"method": "cp", "src": src, "dst": dst})
        return True

    def mv(self, src: str, dst: str, recurse: bool = False) -> bool:
        """Move a file."""
        self._call_log.append({"method": "mv", "src": src, "dst": dst})
        return True

    def rm(self, path: str, recurse: bool = False) -> bool:
        """Remove a file."""
        self._call_log.append({"method": "rm", "path": path})
        return True

    def mkdirs(self, path: str) -> bool:
        """Create directories."""
        self._call_log.append({"method": "mkdirs", "path": path})
        return True

    def put(self, path: str, content: str, overwrite: bool = False) -> bool:
        """Write content to a path (for test setup)."""
        self._files[path] = content
        return True

    def head(self, path: str, max_bytes: int = 65536) -> str:
        """Read the first N bytes of a file."""
        self._call_log.append({"method": "head", "path": path})
        return self._files.get(path, "")[:max_bytes]

    def get_call_log(self) -> List[Dict[str, Any]]:
        """Get the call log for assertions."""
        return self._call_log


class MockDbutils:
    """Complete mock for Databricks dbutils.

    Provides mock implementations of widgets, secrets, fs, and notebook.

    Example:
        dbutils = MockDbutils()
        dbutils.widgets.text("env", "dev", "Environment")
        dbutils.secrets.put("scope", "key", "value")
        assert dbutils.widgets.get("env") == "dev"
    """

    def __init__(self) -> None:
        self.widgets = MockWidgets()
        self.secrets = MockSecretScope()
        self.fs = MockFS()
        self.notebook = MockNotebook()


class MockNotebook:
    """Mock for dbutils.notebook — tracks run calls."""

    def __init__(self) -> None:
        self._runs: List[Dict[str, Any]] = []
        self._exit_value: Optional[str] = None

    def run(
        self,
        path: str,
        timeout_seconds: int = 300,
        arguments: Optional[Dict[str, str]] = None,
    ) -> str:
        """Simulate running a notebook."""
        self._runs.append({
            "path": path,
            "timeout": timeout_seconds,
            "arguments": arguments or {},
        })
        return "OK"

    def exit(self, value: str) -> None:
        """Simulate notebook exit."""
        self._exit_value = value

    def get_runs(self) -> List[Dict[str, Any]]:
        """Get logged run calls for assertions."""
        return self._runs


# =============================================================================
# Patch Helpers
# =============================================================================

def patch_dbutils(target_module: str) -> MockDbutils:
    """Create a MockDbutils and patch it into the target module.

    Args:
        target_module: Dot-separated module path where 'dbutils' is referenced.

    Returns:
        The MockDbutils instance that was injected.

    Example:
        mock_dbutils = patch_dbutils("my_pipeline.bronze_ingest")
        mock_dbutils.widgets.set_value("env", "test")
    """
    mock = MockDbutils()
    patcher = patch(f"{target_module}.dbutils", mock)
    patcher.start()
    return mock


def create_mock_delta_table(
    spark_mock: MagicMock,
    table_name: str,
    data: Optional[List[Dict[str, Any]]] = None,
) -> MagicMock:
    """Create a mock DeltaTable for testing merge/update operations.

    Args:
        spark_mock: A mock SparkSession.
        table_name: The table name to mock.
        data: Optional initial data for the mock table.

    Returns:
        A MagicMock configured as a DeltaTable.
    """
    delta_table = MagicMock()
    delta_table.toDF.return_value = spark_mock.createDataFrame(data or [])
    delta_table.alias.return_value = delta_table
    delta_table.merge.return_value = delta_table

    # Chain merge -> whenMatchedUpdate -> whenNotMatchedInsert -> execute
    delta_table.merge.return_value.whenMatchedUpdate.return_value = delta_table
    delta_table.merge.return_value.whenNotMatchedInsert.return_value = delta_table
    delta_table.merge.return_value.whenMatchedUpdate.return_value.whenNotMatchedInsert.return_value = delta_table

    return delta_table
