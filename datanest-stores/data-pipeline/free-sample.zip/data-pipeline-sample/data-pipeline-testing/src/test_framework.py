"""
Data Pipeline Testing Kit — Test Framework
By Datanest Digital (https://datanest.dev) | Version 1.0.0

Base test classes and utilities for PySpark data pipeline testing.
Provides SparkTestCase with built-in DataFrame assertions, temp table
management, and Delta Lake test helpers.

Usage:
    from test_framework import SparkTestCase

    class TestMyPipeline(SparkTestCase):
        def test_transform(self):
            df = self.create_dataframe(
                [("Alice", 100), ("Bob", 200)],
                schema=["name", "amount"]
            )
            result = my_transform(df)
            self.assert_row_count(result, 2)
"""

from __future__ import annotations

import logging
import tempfile
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union
from dataclasses import dataclass, field
from datetime import datetime

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
import pytest

logger = logging.getLogger(__name__)


# =============================================================================
# Configuration
# =============================================================================

@dataclass
class TestConfig:
    """Configuration for the test framework."""

    app_name: str = "DataPipelineTests"
    master: str = "local[2]"
    warehouse_dir: str = ""
    log_level: str = "WARN"
    delta_extensions: bool = True
    extra_spark_conf: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.warehouse_dir:
            self.warehouse_dir = tempfile.mkdtemp(prefix="spark_test_warehouse_")


# =============================================================================
# Spark Session Management
# =============================================================================

class SparkSessionManager:
    """Manages a shared SparkSession for the test suite.

    Creates a single SparkSession per test run configured for local testing
    with Delta Lake support. The session is reused across all test classes.
    """

    _instance: Optional[SparkSession] = None
    _config: Optional[TestConfig] = None
    _temp_dirs: List[str] = []

    @classmethod
    def get_or_create(cls, config: Optional[TestConfig] = None) -> SparkSession:
        """Get or create the shared SparkSession.

        Args:
            config: Optional test configuration. Ignored if session already exists.

        Returns:
            Configured SparkSession for testing.
        """
        if cls._instance is not None and cls._instance.sparkContext._jsc is not None:
            return cls._instance

        cfg = config or TestConfig()
        cls._config = cfg

        builder = (
            SparkSession.builder
            .master(cfg.master)
            .appName(cfg.app_name)
            .config("spark.sql.warehouse.dir", cfg.warehouse_dir)
            .config("spark.sql.shuffle.partitions", "4")
            .config("spark.default.parallelism", "4")
            .config("spark.sql.session.timeZone", "UTC")
            .config("spark.ui.enabled", "false")
            .config("spark.driver.bindAddress", "127.0.0.1")
        )

        # Delta Lake extensions
        if cfg.delta_extensions:
            builder = (
                builder
                .config(
                    "spark.sql.extensions",
                    "io.delta.sql.DeltaSparkSessionExtension",
                )
                .config(
                    "spark.sql.catalog.spark_catalog",
                    "org.apache.spark.sql.delta.catalog.DeltaCatalog",
                )
            )

        # Extra configuration
        for key, value in cfg.extra_spark_conf.items():
            builder = builder.config(key, value)

        cls._instance = builder.getOrCreate()
        cls._instance.sparkContext.setLogLevel(cfg.log_level)
        cls._temp_dirs.append(cfg.warehouse_dir)

        logger.info("SparkSession created: %s", cfg.app_name)
        return cls._instance

    @classmethod
    def stop(cls) -> None:
        """Stop the shared SparkSession and clean up temp directories."""
        if cls._instance is not None:
            cls._instance.stop()
            cls._instance = None
        for d in cls._temp_dirs:
            shutil.rmtree(d, ignore_errors=True)
        cls._temp_dirs.clear()
        logger.info("SparkSession stopped and temp dirs cleaned up")


# =============================================================================
# Base Test Case
# =============================================================================

class SparkTestCase:
    """Base test class for PySpark pipeline tests.

    Provides convenience methods for creating DataFrames, managing temp
    tables, and performing common assertions. Use as a base class for
    your pytest test classes.

    Example:
        class TestMyPipeline(SparkTestCase):
            def test_basic(self):
                df = self.create_dataframe(
                    [("Alice", 30), ("Bob", 25)],
                    schema=["name", "age"]
                )
                assert df.count() == 2
    """

    _spark: Optional[SparkSession] = None
    _temp_tables: List[str] = []
    _temp_paths: List[str] = []

    @pytest.fixture(autouse=True)
    def _setup_spark(self) -> None:
        """Pytest fixture: initialize SparkSession before each test class."""
        self._spark = SparkSessionManager.get_or_create()
        self._temp_tables = []
        self._temp_paths = []
        yield  # type: ignore[misc]
        self._cleanup()

    @property
    def spark(self) -> SparkSession:
        """Access the active SparkSession."""
        assert self._spark is not None, "SparkSession not initialized"
        return self._spark

    # --- DataFrame creation ---------------------------------------------------

    def create_dataframe(
        self,
        data: Sequence[Tuple[Any, ...]],
        schema: Union[StructType, List[str]],
    ) -> DataFrame:
        """Create a DataFrame from a list of tuples.

        Args:
            data: Rows as tuples.
            schema: Column names (list of strings) or a StructType.

        Returns:
            PySpark DataFrame.
        """
        return self.spark.createDataFrame(data, schema=schema)

    def create_dataframe_from_dicts(
        self,
        data: List[Dict[str, Any]],
        schema: Optional[StructType] = None,
    ) -> DataFrame:
        """Create a DataFrame from a list of dictionaries.

        Args:
            data: Rows as dicts.
            schema: Optional explicit schema.

        Returns:
            PySpark DataFrame.
        """
        rdd = self.spark.sparkContext.parallelize(data)
        if schema:
            return self.spark.createDataFrame(rdd, schema=schema)
        return self.spark.createDataFrame(rdd)

    def create_empty_dataframe(self, schema: StructType) -> DataFrame:
        """Create an empty DataFrame with a given schema.

        Args:
            schema: The StructType schema.

        Returns:
            Empty PySpark DataFrame.
        """
        return self.spark.createDataFrame([], schema=schema)

    def create_temp_table(self, df: DataFrame, name: str) -> str:
        """Register a DataFrame as a temporary view.

        Args:
            df: The DataFrame to register.
            name: Temp view name.

        Returns:
            The registered view name.
        """
        df.createOrReplaceTempView(name)
        self._temp_tables.append(name)
        return name

    def get_temp_path(self, prefix: str = "test_") -> str:
        """Get a temporary directory path for test output.

        Args:
            prefix: Directory name prefix.

        Returns:
            Absolute path to a temporary directory.
        """
        path = tempfile.mkdtemp(prefix=prefix)
        self._temp_paths.append(path)
        return path

    # --- Assertions -----------------------------------------------------------

    def assert_row_count(self, df: DataFrame, expected: int) -> None:
        """Assert that a DataFrame has the expected number of rows."""
        actual = df.count()
        assert actual == expected, (
            f"Row count mismatch: expected {expected}, got {actual}"
        )

    def assert_no_nulls(self, df: DataFrame, columns: List[str]) -> None:
        """Assert that specified columns contain no null values."""
        for col in columns:
            null_count = df.filter(df[col].isNull()).count()
            assert null_count == 0, (
                f"Column '{col}' contains {null_count} null value(s)"
            )

    def assert_column_exists(self, df: DataFrame, column: str) -> None:
        """Assert that a column exists in the DataFrame."""
        assert column in df.columns, (
            f"Column '{column}' not found. Available: {df.columns}"
        )

    def assert_schema_equals(
        self, df: DataFrame, expected: StructType
    ) -> None:
        """Assert that the DataFrame schema matches exactly."""
        assert df.schema == expected, (
            f"Schema mismatch:\n"
            f"  Expected: {expected.simpleString()}\n"
            f"  Actual:   {df.schema.simpleString()}"
        )

    def assert_dataframes_equal(
        self,
        actual: DataFrame,
        expected: DataFrame,
        order_by: Optional[List[str]] = None,
    ) -> None:
        """Assert that two DataFrames are equal (same schema, same rows).

        Args:
            actual: The result DataFrame.
            expected: The expected DataFrame.
            order_by: Columns to sort by before comparing (for deterministic order).
        """
        # Schema check
        assert actual.schema == expected.schema, (
            f"Schema mismatch:\n"
            f"  Expected: {expected.schema.simpleString()}\n"
            f"  Actual:   {actual.schema.simpleString()}"
        )

        # Row count check
        actual_count = actual.count()
        expected_count = expected.count()
        assert actual_count == expected_count, (
            f"Row count mismatch: expected {expected_count}, got {actual_count}"
        )

        # Content check
        if order_by:
            actual_rows = [row.asDict() for row in actual.orderBy(order_by).collect()]
            expected_rows = [row.asDict() for row in expected.orderBy(order_by).collect()]
        else:
            actual_rows = sorted(
                [row.asDict() for row in actual.collect()],
                key=lambda r: str(r),
            )
            expected_rows = sorted(
                [row.asDict() for row in expected.collect()],
                key=lambda r: str(r),
            )

        assert actual_rows == expected_rows, (
            f"DataFrame content mismatch.\n"
            f"  First difference at row where actual != expected."
        )

    # --- Cleanup --------------------------------------------------------------

    def _cleanup(self) -> None:
        """Clean up temp tables and directories after each test."""
        if self._spark:
            for table in self._temp_tables:
                try:
                    self._spark.catalog.dropTempView(table)
                except Exception:
                    pass
        for path in self._temp_paths:
            shutil.rmtree(path, ignore_errors=True)
        self._temp_tables.clear()
        self._temp_paths.clear()


# =============================================================================
# Test Result Reporter
# =============================================================================

@dataclass
class TestResult:
    """Represents a single test result."""

    test_name: str
    status: str  # "passed", "failed", "error"
    duration_ms: float
    error_message: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class TestReporter:
    """Collects and formats test results.

    Usage:
        reporter = TestReporter()
        reporter.add_result(TestResult("test_basic", "passed", 45.2))
        reporter.add_result(TestResult("test_schema", "failed", 12.1, "Schema mismatch"))
        print(reporter.summary())
    """

    def __init__(self) -> None:
        self.results: List[TestResult] = []

    def add_result(self, result: TestResult) -> None:
        """Add a test result."""
        self.results.append(result)

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.status == "passed")

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if r.status == "failed")

    @property
    def total_duration_ms(self) -> float:
        return sum(r.duration_ms for r in self.results)

    def summary(self) -> str:
        """Generate a human-readable test summary."""
        lines = [
            "=" * 60,
            "TEST RESULTS SUMMARY",
            "=" * 60,
            f"Total:    {len(self.results)}",
            f"Passed:   {self.passed}",
            f"Failed:   {self.failed}",
            f"Duration: {self.total_duration_ms:.1f}ms",
            "-" * 60,
        ]

        for r in self.results:
            icon = "PASS" if r.status == "passed" else "FAIL"
            line = f"  [{icon}] {r.test_name} ({r.duration_ms:.1f}ms)"
            if r.error_message:
                line += f"\n         {r.error_message}"
            lines.append(line)

        lines.append("=" * 60)
        return "\n".join(lines)
