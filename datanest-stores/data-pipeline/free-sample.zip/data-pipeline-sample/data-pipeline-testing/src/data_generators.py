"""
Data Pipeline Testing Kit — Data Generators
By Datanest Digital (https://datanest.dev) | Version 1.0.0

Factories for generating realistic synthetic test data. Each generator
produces PySpark DataFrames with configurable record counts and
deterministic seeding for reproducible tests.

Usage:
    from data_generators import CustomerGenerator, OrderGenerator

    gen = CustomerGenerator(spark, seed=42)
    customers_df = gen.generate(count=1000)
"""

from __future__ import annotations

import hashlib
import random
import string
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    DoubleType,
    TimestampType,
    BooleanType,
    LongType,
    DateType,
)


# =============================================================================
# Base Generator
# =============================================================================

class BaseGenerator:
    """Base class for all data generators.

    Provides seeded random number generation and common utility methods
    for creating realistic synthetic data.

    Args:
        spark: Active SparkSession.
        seed: Random seed for reproducibility.
    """

    def __init__(self, spark: SparkSession, seed: int = 42) -> None:
        self.spark = spark
        self.seed = seed
        self._rng = random.Random(seed)

    def _random_string(self, length: int = 8) -> str:
        """Generate a random alphanumeric string."""
        return "".join(self._rng.choices(string.ascii_lowercase + string.digits, k=length))

    def _random_choice(self, options: List[Any]) -> Any:
        """Pick a random item from a list."""
        return self._rng.choice(options)

    def _random_date(
        self,
        start: datetime = datetime(2023, 1, 1),
        end: datetime = datetime(2026, 1, 1),
    ) -> datetime:
        """Generate a random datetime within a range."""
        delta = end - start
        random_seconds = self._rng.randint(0, int(delta.total_seconds()))
        return start + timedelta(seconds=random_seconds)

    def _deterministic_id(self, prefix: str, index: int) -> str:
        """Generate a deterministic ID based on seed and index."""
        raw = f"{prefix}_{self.seed}_{index}"
        return hashlib.md5(raw.encode()).hexdigest()[:12]


# =============================================================================
# Customer Generator
# =============================================================================

FIRST_NAMES = [
    "Alice", "Bob", "Carol", "David", "Eve", "Frank", "Grace", "Henry",
    "Iris", "Jack", "Karen", "Leo", "Mia", "Noah", "Olivia", "Peter",
    "Quinn", "Rachel", "Sam", "Tina", "Uma", "Victor", "Wendy", "Xander",
    "Yara", "Zach", "Amelia", "Ben", "Clara", "Dylan",
]

LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller",
    "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez",
    "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
    "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark",
    "Ramirez", "Lewis", "Robinson",
]

CUSTOMER_SEGMENTS = ["enterprise", "mid-market", "small-business", "startup", "individual"]
REGIONS = ["us-east", "us-west", "eu-west", "eu-central", "apac-southeast", "apac-northeast"]
STATUSES = ["active", "inactive", "churned", "trial"]


class CustomerGenerator(BaseGenerator):
    """Generates realistic customer records.

    Each customer has: customer_id, first_name, last_name, email, segment,
    region, status, created_at, lifetime_value, is_premium.

    Example:
        gen = CustomerGenerator(spark, seed=42)
        df = gen.generate(count=500)
    """

    SCHEMA = StructType([
        StructField("customer_id", StringType(), False),
        StructField("first_name", StringType(), False),
        StructField("last_name", StringType(), False),
        StructField("email", StringType(), False),
        StructField("segment", StringType(), False),
        StructField("region", StringType(), False),
        StructField("status", StringType(), False),
        StructField("created_at", TimestampType(), False),
        StructField("lifetime_value", DoubleType(), False),
        StructField("is_premium", BooleanType(), False),
    ])

    def generate(self, count: int = 50) -> DataFrame:
        """Generate a DataFrame of customer records.

        Args:
            count: Number of customer records to generate.

        Returns:
            DataFrame with customer schema.
        """
        rows: List[Dict[str, Any]] = []

        for i in range(count):
            first = self._random_choice(FIRST_NAMES)
            last = self._random_choice(LAST_NAMES)
            cid = f"cust_{self._deterministic_id('customer', i)}"
            email = f"{first.lower()}.{last.lower()}.{i}@example.com"
            segment = self._random_choice(CUSTOMER_SEGMENTS)
            region = self._random_choice(REGIONS)
            status = self._random_choice(STATUSES)
            created = self._random_date(datetime(2021, 1, 1), datetime(2025, 12, 31))

            # Higher LTV for enterprise/premium
            base_ltv = {"enterprise": 5000, "mid-market": 2000, "small-business": 500,
                        "startup": 300, "individual": 100}
            ltv = round(self._rng.gauss(base_ltv.get(segment, 500), 200), 2)
            ltv = max(0.0, ltv)
            is_premium = ltv > 1500 or segment == "enterprise"

            rows.append({
                "customer_id": cid,
                "first_name": first,
                "last_name": last,
                "email": email,
                "segment": segment,
                "region": region,
                "status": status,
                "created_at": created,
                "lifetime_value": ltv,
                "is_premium": is_premium,
            })

        return self.spark.createDataFrame(rows, schema=self.SCHEMA)


# =============================================================================
# Order Generator
# =============================================================================

PRODUCT_NAMES = [
    "Widget Pro", "Data Sync License", "Analytics Dashboard", "Cloud Storage Plan",
    "API Gateway", "ML Pipeline Kit", "Stream Processor", "Report Builder",
    "ETL Accelerator", "Monitoring Suite", "Security Scanner", "DevOps Toolkit",
]

ORDER_STATUSES = ["completed", "pending", "cancelled", "refunded", "processing"]
PAYMENT_METHODS = ["credit_card", "bank_transfer", "paypal", "invoice"]


class OrderGenerator(BaseGenerator):
    """Generates realistic order/transaction records.

    Each order has: order_id, customer_id, product_name, quantity, unit_price,
    total_amount, order_status, payment_method, order_date, shipped_date.

    Example:
        gen = OrderGenerator(spark, seed=42)
        orders_df = gen.generate(count=1000, customer_ids=["cust_001", "cust_002"])
    """

    SCHEMA = StructType([
        StructField("order_id", StringType(), False),
        StructField("customer_id", StringType(), False),
        StructField("product_name", StringType(), False),
        StructField("quantity", IntegerType(), False),
        StructField("unit_price", DoubleType(), False),
        StructField("total_amount", DoubleType(), False),
        StructField("order_status", StringType(), False),
        StructField("payment_method", StringType(), False),
        StructField("order_date", TimestampType(), False),
        StructField("shipped_date", TimestampType(), True),
    ])

    def generate(
        self,
        count: int = 100,
        customer_ids: Optional[List[str]] = None,
    ) -> DataFrame:
        """Generate a DataFrame of order records.

        Args:
            count: Number of order records to generate.
            customer_ids: Optional list of customer IDs to assign orders to.
                If None, generates random customer IDs.

        Returns:
            DataFrame with order schema.
        """
        if customer_ids is None:
            customer_ids = [f"cust_{self._deterministic_id('customer', i)}" for i in range(20)]

        rows: List[Dict[str, Any]] = []

        for i in range(count):
            oid = f"ord_{self._deterministic_id('order', i)}"
            cid = self._random_choice(customer_ids)
            product = self._random_choice(PRODUCT_NAMES)
            qty = self._rng.randint(1, 10)
            unit_price = round(self._rng.uniform(9.99, 499.99), 2)
            total = round(qty * unit_price, 2)
            status = self._random_choice(ORDER_STATUSES)
            payment = self._random_choice(PAYMENT_METHODS)
            order_date = self._random_date(datetime(2024, 1, 1), datetime(2026, 1, 1))

            # Only completed/processing orders have shipped dates
            shipped = None
            if status in ("completed", "processing"):
                shipped = order_date + timedelta(days=self._rng.randint(1, 14))

            rows.append({
                "order_id": oid,
                "customer_id": cid,
                "product_name": product,
                "quantity": qty,
                "unit_price": unit_price,
                "total_amount": total,
                "order_status": status,
                "payment_method": payment,
                "order_date": order_date,
                "shipped_date": shipped,
            })

        return self.spark.createDataFrame(rows, schema=self.SCHEMA)


# =============================================================================
# Event Generator
# =============================================================================

EVENT_TYPES = ["page_view", "click", "search", "add_to_cart", "purchase", "login", "logout"]
PLATFORMS = ["web", "ios", "android", "api"]
PAGES = ["/home", "/products", "/pricing", "/docs", "/dashboard", "/settings", "/checkout"]


class EventGenerator(BaseGenerator):
    """Generates realistic user event/clickstream records.

    Each event has: event_id, user_id, event_type, platform, page,
    session_id, event_timestamp, properties.
    """

    SCHEMA = StructType([
        StructField("event_id", StringType(), False),
        StructField("user_id", StringType(), False),
        StructField("event_type", StringType(), False),
        StructField("platform", StringType(), False),
        StructField("page", StringType(), True),
        StructField("session_id", StringType(), False),
        StructField("event_timestamp", TimestampType(), False),
        StructField("duration_seconds", IntegerType(), True),
    ])

    def generate(
        self,
        count: int = 500,
        user_ids: Optional[List[str]] = None,
    ) -> DataFrame:
        """Generate a DataFrame of event records.

        Args:
            count: Number of event records to generate.
            user_ids: Optional list of user IDs. Generates random if None.

        Returns:
            DataFrame with event schema.
        """
        if user_ids is None:
            user_ids = [f"user_{self._deterministic_id('user', i)}" for i in range(30)]

        rows: List[Dict[str, Any]] = []

        for i in range(count):
            eid = f"evt_{self._deterministic_id('event', i)}"
            uid = self._random_choice(user_ids)
            event_type = self._random_choice(EVENT_TYPES)
            platform = self._random_choice(PLATFORMS)
            page = self._random_choice(PAGES) if event_type != "logout" else None
            session_id = f"ses_{self._deterministic_id('session', i // 5)}"
            ts = self._random_date(datetime(2025, 1, 1), datetime(2026, 1, 1))
            duration = self._rng.randint(1, 300) if event_type == "page_view" else None

            rows.append({
                "event_id": eid,
                "user_id": uid,
                "event_type": event_type,
                "platform": platform,
                "page": page,
                "session_id": session_id,
                "event_timestamp": ts,
                "duration_seconds": duration,
            })

        return self.spark.createDataFrame(rows, schema=self.SCHEMA)
