"""
Data Pipeline Testing Kit — Snapshot Testing
By Datanest Digital (https://datanest.dev) | Version 1.0.0

Golden-file snapshot testing for PySpark DataFrames. Compares pipeline
output against stored expected results, with support for updating
snapshots when schemas intentionally change.

Usage:
    from snapshot_testing import SnapshotTester

    tester = SnapshotTester(snapshot_dir="fixtures/expected_outputs")

    # First run: creates the snapshot file
    tester.update_snapshot(result_df, "customer_summary")

    # Subsequent runs: compares against the snapshot
    tester.assert_matches(result_df, "customer_summary")
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import StructType

logger = logging.getLogger(__name__)


class SnapshotMismatchError(Exception):
    """Raised when a DataFrame does not match its snapshot."""
    pass


class SnapshotNotFoundError(Exception):
    """Raised when a snapshot file does not exist."""
    pass


class SnapshotTester:
    """Golden-file snapshot testing for DataFrames.

    Stores expected DataFrame content as JSON files and compares
    pipeline output against these snapshots for regression detection.

    Args:
        snapshot_dir: Directory containing snapshot JSON files.
        auto_create: If True, automatically creates snapshots when missing.
    """

    def __init__(
        self,
        snapshot_dir: str = "fixtures/expected_outputs",
        auto_create: bool = False,
    ) -> None:
        self.snapshot_dir = Path(snapshot_dir)
        self.auto_create = auto_create

    def _snapshot_path(self, name: str) -> Path:
        """Get the path for a named snapshot."""
        return self.snapshot_dir / f"{name}.json"

    def _schema_path(self, name: str) -> Path:
        """Get the path for the schema companion file."""
        return self.snapshot_dir / f"{name}.schema.json"

    # =========================================================================
    # Snapshot Management
    # =========================================================================

    def update_snapshot(self, df: DataFrame, name: str) -> Path:
        """Write or overwrite a snapshot file from a DataFrame.

        Args:
            df: The DataFrame to snapshot.
            name: Snapshot name (used as filename without extension).

        Returns:
            Path to the created snapshot file.
        """
        self.snapshot_dir.mkdir(parents=True, exist_ok=True)

        # Collect data as list of dicts
        rows = [row.asDict(recursive=True) for row in df.collect()]

        # Serialize with consistent formatting
        snapshot_data = {
            "row_count": len(rows),
            "columns": df.columns,
            "data": rows,
        }

        path = self._snapshot_path(name)
        with open(path, "w") as f:
            json.dump(snapshot_data, f, indent=2, default=str, sort_keys=True)

        # Also store schema
        schema_path = self._schema_path(name)
        with open(schema_path, "w") as f:
            json.dump(json.loads(df.schema.json()), f, indent=2)

        logger.info("Snapshot updated: %s (%d rows)", path, len(rows))
        return path

    def load_snapshot(self, name: str) -> Dict[str, Any]:
        """Load a snapshot file.

        Args:
            name: Snapshot name.

        Returns:
            Dict with keys: row_count, columns, data.

        Raises:
            SnapshotNotFoundError: If snapshot file does not exist.
        """
        path = self._snapshot_path(name)
        if not path.exists():
            raise SnapshotNotFoundError(
                f"Snapshot not found: {path}. "
                f"Run update_snapshot() to create it."
            )

        with open(path) as f:
            return json.load(f)

    def load_schema(self, name: str) -> Optional[StructType]:
        """Load the schema for a snapshot.

        Args:
            name: Snapshot name.

        Returns:
            StructType schema, or None if schema file doesn't exist.
        """
        path = self._schema_path(name)
        if not path.exists():
            return None

        with open(path) as f:
            schema_json = json.load(f)
        return StructType.fromJson(schema_json)

    def snapshot_exists(self, name: str) -> bool:
        """Check whether a snapshot file exists."""
        return self._snapshot_path(name).exists()

    def delete_snapshot(self, name: str) -> None:
        """Delete a snapshot and its schema file."""
        self._snapshot_path(name).unlink(missing_ok=True)
        self._schema_path(name).unlink(missing_ok=True)

    # =========================================================================
    # Assertions
    # =========================================================================

    def assert_matches(
        self,
        df: DataFrame,
        name: str,
        check_order: bool = False,
        check_schema: bool = True,
        tolerance: float = 0.0,
    ) -> None:
        """Assert that a DataFrame matches a stored snapshot.

        Args:
            df: The DataFrame to compare.
            name: Snapshot name to compare against.
            check_order: If True, rows must be in the same order.
            check_schema: If True, validates schema matches.
            tolerance: Allowed tolerance for floating-point comparisons.

        Raises:
            SnapshotNotFoundError: If snapshot doesn't exist and auto_create is False.
            SnapshotMismatchError: If the DataFrame doesn't match the snapshot.
        """
        # Auto-create if missing
        if not self.snapshot_exists(name):
            if self.auto_create:
                logger.warning("Auto-creating snapshot: %s", name)
                self.update_snapshot(df, name)
                return
            raise SnapshotNotFoundError(
                f"Snapshot '{name}' not found. "
                f"Create it with: tester.update_snapshot(df, '{name}')"
            )

        snapshot = self.load_snapshot(name)

        # Schema check
        if check_schema:
            expected_schema = self.load_schema(name)
            if expected_schema is not None:
                actual_fields = {(f.name, f.dataType.simpleString()) for f in df.schema.fields}
                expected_fields = {(f.name, f.dataType.simpleString()) for f in expected_schema.fields}

                if actual_fields != expected_fields:
                    raise SnapshotMismatchError(
                        f"Schema mismatch for snapshot '{name}':\n"
                        f"  Missing: {expected_fields - actual_fields}\n"
                        f"  Extra:   {actual_fields - expected_fields}"
                    )

        # Row count check
        actual_count = df.count()
        expected_count = snapshot["row_count"]
        if actual_count != expected_count:
            raise SnapshotMismatchError(
                f"Row count mismatch for snapshot '{name}': "
                f"expected {expected_count}, got {actual_count}"
            )

        # Content check
        actual_rows = [row.asDict(recursive=True) for row in df.collect()]

        # Normalize for comparison (convert non-serializable types to strings)
        actual_normalized = self._normalize_rows(actual_rows)
        expected_normalized = self._normalize_rows(snapshot["data"])

        if not check_order:
            actual_normalized = sorted(actual_normalized, key=lambda r: json.dumps(r, sort_keys=True, default=str))
            expected_normalized = sorted(expected_normalized, key=lambda r: json.dumps(r, sort_keys=True, default=str))

        # Compare with optional tolerance
        if tolerance > 0:
            self._compare_with_tolerance(actual_normalized, expected_normalized, tolerance, name)
        else:
            if actual_normalized != expected_normalized:
                # Find first difference for helpful error message
                diff_msg = self._find_first_diff(actual_normalized, expected_normalized)
                raise SnapshotMismatchError(
                    f"Content mismatch for snapshot '{name}'.\n{diff_msg}"
                )

    # =========================================================================
    # Internal Helpers
    # =========================================================================

    @staticmethod
    def _normalize_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Normalize row values for comparison (convert datetimes to strings)."""
        normalized = []
        for row in rows:
            norm_row = {}
            for k, v in row.items():
                if v is None:
                    norm_row[k] = None
                elif isinstance(v, (int, float, bool, str)):
                    norm_row[k] = v
                else:
                    norm_row[k] = str(v)
            normalized.append(norm_row)
        return normalized

    @staticmethod
    def _find_first_diff(
        actual: List[Dict[str, Any]],
        expected: List[Dict[str, Any]],
    ) -> str:
        """Find and format the first difference between row lists."""
        for i, (a, e) in enumerate(zip(actual, expected)):
            if a != e:
                diff_keys = [k for k in set(list(a.keys()) + list(e.keys())) if a.get(k) != e.get(k)]
                return (
                    f"First difference at row {i}:\n"
                    f"  Columns: {diff_keys}\n"
                    f"  Actual:  { {k: a.get(k) for k in diff_keys} }\n"
                    f"  Expected: { {k: e.get(k) for k in diff_keys} }"
                )
        return "Rows differ in length or undetected difference."

    @staticmethod
    def _compare_with_tolerance(
        actual: List[Dict[str, Any]],
        expected: List[Dict[str, Any]],
        tolerance: float,
        name: str,
    ) -> None:
        """Compare rows with floating-point tolerance."""
        for i, (a, e) in enumerate(zip(actual, expected)):
            for k in set(list(a.keys()) + list(e.keys())):
                av = a.get(k)
                ev = e.get(k)
                if isinstance(av, float) and isinstance(ev, float):
                    if abs(av - ev) > tolerance:
                        raise SnapshotMismatchError(
                            f"Float mismatch in snapshot '{name}' at row {i}, "
                            f"column '{k}': {av} vs {ev} (tolerance={tolerance})"
                        )
                elif av != ev:
                    raise SnapshotMismatchError(
                        f"Value mismatch in snapshot '{name}' at row {i}, "
                        f"column '{k}': {av!r} vs {ev!r}"
                    )
