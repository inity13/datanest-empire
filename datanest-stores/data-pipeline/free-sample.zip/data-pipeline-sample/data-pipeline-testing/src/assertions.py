"""
Data Pipeline Testing Kit — Assertions Library
By Datanest Digital (https://datanest.dev) | Version 1.0.0

Custom assertion functions for validating PySpark DataFrames in tests.
Covers schema validation, null checks, uniqueness, value ranges,
referential integrity, and data quality rules.

Usage:
    from assertions import DataFrameAssertions

    assertions = DataFrameAssertions(spark)
    assertions.assert_schema_matches(df, expected_schema)
    assertions.assert_no_nulls(df, ["id", "name"])
    assertions.assert_unique(df, ["id"])
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Set, Union

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField


class AssertionError(Exception):
    """Raised when a DataFrame assertion fails."""
    pass


class DataFrameAssertions:
    """Library of DataFrame-level assertions for pipeline testing.

    Args:
        spark: Active SparkSession (used for creating comparison DataFrames).
    """

    def __init__(self, spark: SparkSession) -> None:
        self.spark = spark

    # =========================================================================
    # Schema Assertions
    # =========================================================================

    def assert_schema_matches(
        self,
        df: DataFrame,
        expected: StructType,
        check_nullable: bool = False,
    ) -> None:
        """Assert that the DataFrame schema matches the expected schema.

        Args:
            df: DataFrame to validate.
            expected: Expected StructType schema.
            check_nullable: If True, also validates nullable flags.
        """
        actual = df.schema

        if check_nullable:
            if actual != expected:
                raise AssertionError(
                    f"Schema mismatch (strict):\n"
                    f"  Expected: {expected.simpleString()}\n"
                    f"  Actual:   {actual.simpleString()}"
                )
        else:
            # Compare only names and types
            expected_fields = {(f.name, f.dataType) for f in expected.fields}
            actual_fields = {(f.name, f.dataType) for f in actual.fields}

            missing = expected_fields - actual_fields
            extra = actual_fields - expected_fields

            if missing or extra:
                msg = "Schema mismatch:\n"
                if missing:
                    msg += f"  Missing fields: {[(n, str(t)) for n, t in missing]}\n"
                if extra:
                    msg += f"  Extra fields: {[(n, str(t)) for n, t in extra]}\n"
                raise AssertionError(msg)

    def assert_columns_exist(
        self, df: DataFrame, columns: List[str]
    ) -> None:
        """Assert that all specified columns exist in the DataFrame."""
        missing = set(columns) - set(df.columns)
        if missing:
            raise AssertionError(
                f"Missing columns: {sorted(missing)}. "
                f"Available: {sorted(df.columns)}"
            )

    def assert_column_types(
        self, df: DataFrame, expected_types: Dict[str, str]
    ) -> None:
        """Assert column data types match expected types.

        Args:
            df: DataFrame to validate.
            expected_types: Dict mapping column name to type string
                (e.g., {"id": "string", "amount": "double"}).
        """
        actual_types = {f.name: f.dataType.simpleString() for f in df.schema.fields}

        mismatches = {}
        for col, expected_type in expected_types.items():
            if col not in actual_types:
                mismatches[col] = f"column not found"
            elif actual_types[col] != expected_type:
                mismatches[col] = f"expected {expected_type}, got {actual_types[col]}"

        if mismatches:
            raise AssertionError(f"Column type mismatches: {mismatches}")

    # =========================================================================
    # Null / Completeness Assertions
    # =========================================================================

    def assert_no_nulls(self, df: DataFrame, columns: List[str]) -> None:
        """Assert that specified columns contain no null values."""
        null_counts = {}
        for col in columns:
            count = df.filter(F.col(col).isNull()).count()
            if count > 0:
                null_counts[col] = count

        if null_counts:
            raise AssertionError(f"Null values found: {null_counts}")

    def assert_no_empty_strings(
        self, df: DataFrame, columns: List[str]
    ) -> None:
        """Assert that string columns contain no empty strings or whitespace-only values."""
        empty_counts = {}
        for col in columns:
            count = df.filter(
                F.col(col).isNull() | (F.trim(F.col(col)) == "")
            ).count()
            if count > 0:
                empty_counts[col] = count

        if empty_counts:
            raise AssertionError(f"Empty/blank string values found: {empty_counts}")

    def assert_completeness(
        self,
        df: DataFrame,
        column: str,
        min_completeness: float = 1.0,
    ) -> None:
        """Assert that a column meets a minimum completeness threshold.

        Args:
            df: DataFrame to validate.
            column: Column name.
            min_completeness: Minimum fraction of non-null values (0.0 to 1.0).
        """
        total = df.count()
        if total == 0:
            return  # Empty DataFrame is trivially complete

        non_null = df.filter(F.col(column).isNotNull()).count()
        actual_completeness = non_null / total

        if actual_completeness < min_completeness:
            raise AssertionError(
                f"Column '{column}' completeness {actual_completeness:.2%} "
                f"is below threshold {min_completeness:.2%}"
            )

    # =========================================================================
    # Uniqueness Assertions
    # =========================================================================

    def assert_unique(self, df: DataFrame, columns: List[str]) -> None:
        """Assert that the combination of columns has no duplicates.

        Args:
            df: DataFrame to validate.
            columns: Columns that should form a unique key.
        """
        total = df.count()
        distinct = df.select(columns).distinct().count()

        if distinct != total:
            duplicates = total - distinct
            raise AssertionError(
                f"Found {duplicates} duplicate(s) in columns {columns}. "
                f"Total rows: {total}, distinct: {distinct}"
            )

    def assert_no_duplicates(
        self, df: DataFrame, subset: Optional[List[str]] = None
    ) -> None:
        """Assert the DataFrame has no duplicate rows.

        Args:
            df: DataFrame to validate.
            subset: Optional subset of columns to check. If None, checks all columns.
        """
        cols = subset or df.columns
        self.assert_unique(df, cols)

    # =========================================================================
    # Value Range Assertions
    # =========================================================================

    def assert_column_values_in(
        self,
        df: DataFrame,
        column: str,
        allowed_values: List[Any],
    ) -> None:
        """Assert that all values in a column are within an allowed set.

        Args:
            df: DataFrame to validate.
            column: Column name.
            allowed_values: List of allowed values.
        """
        invalid = (
            df.filter(~F.col(column).isin(allowed_values) & F.col(column).isNotNull())
            .select(column)
            .distinct()
            .collect()
        )

        if invalid:
            bad_values = [row[0] for row in invalid]
            raise AssertionError(
                f"Column '{column}' contains invalid values: {bad_values[:10]}. "
                f"Allowed: {allowed_values}"
            )

    def assert_column_between(
        self,
        df: DataFrame,
        column: str,
        min_value: Any,
        max_value: Any,
    ) -> None:
        """Assert that all values in a numeric column are within a range.

        Args:
            df: DataFrame to validate.
            column: Column name.
            min_value: Minimum allowed value (inclusive).
            max_value: Maximum allowed value (inclusive).
        """
        out_of_range = df.filter(
            (F.col(column) < min_value) | (F.col(column) > max_value)
        ).count()

        if out_of_range > 0:
            raise AssertionError(
                f"Column '{column}' has {out_of_range} value(s) outside "
                f"range [{min_value}, {max_value}]"
            )

    def assert_positive(self, df: DataFrame, columns: List[str]) -> None:
        """Assert that numeric columns contain only positive values."""
        for col in columns:
            negative_count = df.filter(F.col(col) <= 0).count()
            if negative_count > 0:
                raise AssertionError(
                    f"Column '{col}' has {negative_count} non-positive value(s)"
                )

    # =========================================================================
    # Referential Integrity
    # =========================================================================

    def assert_referential_integrity(
        self,
        child_df: DataFrame,
        child_column: str,
        parent_df: DataFrame,
        parent_column: str,
    ) -> None:
        """Assert that all values in child column exist in parent column.

        Args:
            child_df: The referencing DataFrame.
            child_column: Column in child containing foreign keys.
            parent_df: The referenced DataFrame.
            parent_column: Column in parent containing primary keys.
        """
        orphans = (
            child_df.select(F.col(child_column).alias("_fk"))
            .join(
                parent_df.select(F.col(parent_column).alias("_pk")),
                F.col("_fk") == F.col("_pk"),
                "left_anti",
            )
            .distinct()
            .count()
        )

        if orphans > 0:
            raise AssertionError(
                f"Referential integrity violation: {orphans} orphan value(s) "
                f"in '{child_column}' not found in '{parent_column}'"
            )

    # =========================================================================
    # Row Count Assertions
    # =========================================================================

    def assert_row_count(self, df: DataFrame, expected: int) -> None:
        """Assert exact row count."""
        actual = df.count()
        if actual != expected:
            raise AssertionError(f"Expected {expected} rows, got {actual}")

    def assert_row_count_between(
        self, df: DataFrame, min_count: int, max_count: int
    ) -> None:
        """Assert row count is within a range."""
        actual = df.count()
        if actual < min_count or actual > max_count:
            raise AssertionError(
                f"Row count {actual} outside range [{min_count}, {max_count}]"
            )

    def assert_not_empty(self, df: DataFrame) -> None:
        """Assert that the DataFrame is not empty."""
        if df.count() == 0:
            raise AssertionError("DataFrame is empty")
