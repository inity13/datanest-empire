# Testing Data Pipelines — A Practical Guide

**By [Datanest Digital](https://datanest.dev) | Data Pipeline Testing Kit v1.0.0**

---

## Why Test Data Pipelines?

Data pipelines are notoriously difficult to test. Unlike application code, pipeline
failures often manifest as *silent data corruption* — wrong row counts, null values
where there shouldn't be any, or subtle type mismatches that propagate downstream for
days before anyone notices.

A solid test suite catches these issues **before** they reach production:

| Risk                        | What Testing Catches                          |
|-----------------------------|-----------------------------------------------|
| Schema drift                | Column added/removed/renamed upstream         |
| Null propagation            | Joins producing unexpected nulls              |
| Duplicate records           | Dedup logic silently dropping valid rows       |
| Type coercion bugs          | Strings cast to numbers losing precision       |
| Business-rule violations    | Aggregates producing negative revenue          |

---

## Testing Strategy: The Medallion Layers

This kit is organized around the **medallion architecture** (bronze / silver / gold).
Each layer has distinct testing concerns:

### Bronze Layer (Raw Ingestion)

**Goal:** Verify data lands correctly with no data loss.

Key tests:
- Row count matches source
- Metadata columns (`_ingested_at`, `_source_file`, `_batch_id`) are populated
- Schema enforcement catches unexpected column changes
- Deduplication removes exact duplicates by key

```python
from assertions import DataFrameAssertions

def test_bronze_row_count(spark, assertions):
    df = bronze_ingest_json(spark, "fixtures/sample_customers.json")
    assertions.assert_row_count(df, 50)
```

### Silver Layer (Cleansed & Enriched)

**Goal:** Verify cleaning, standardisation, and enrichment logic.

Key tests:
- String trimming and case normalisation
- Null sentinel values (`"N/A"`, `""`, `"null"`) replaced with actual `None`
- Derived columns computed correctly (e.g. `full_name`, `value_tier`)
- Invalid records filtered out (bad emails, null IDs)

```python
def test_value_tier_platinum(spark):
    df = create_customer(spark, lifetime_value=10000.0)
    result = silver_add_derived_columns(df)
    assert result.collect()[0]["value_tier"] == "platinum"
```

### Gold Layer (Business Aggregates)

**Goal:** Verify aggregation logic, KPIs, and referential integrity.

Key tests:
- Summary columns exist and have correct types
- Aggregation math checks out (avg = total / count)
- Value ranges are valid (completion_rate between 0 and 1)
- Top-N queries return correct ordering
- Snapshot comparison against known-good expected outputs

```python
def test_completion_rate_range(customer_summary_df):
    out_of_range = customer_summary_df.filter(
        (F.col("completion_rate") < 0.0) | (F.col("completion_rate") > 1.0)
    ).count()
    assert out_of_range == 0
```

---

## Test Types

### Unit Tests

Test individual transform functions in isolation with small, controlled DataFrames.

**Best practices:**
- Create DataFrames inline with `spark.createDataFrame()`
- Test edge cases: empty DataFrames, single row, all nulls, maximum values
- Keep tests fast (<1 second each)

### Integration Tests

Test the full layer pipeline end-to-end with realistic fixture data.

**Best practices:**
- Use the JSON fixtures (`fixtures/sample_customers.json`, etc.)
- Run the full transform chain: ingest → clean → enrich → filter
- Assert on the final output shape and quality

### Snapshot Tests

Compare pipeline output against a known-good "golden file."

**Best practices:**
- Generate expected outputs once, commit them to version control
- Use `SnapshotManager` for automatic diff generation
- Exclude volatile columns (timestamps, file paths) from comparison

```python
from snapshot_testing import SnapshotManager

def test_output_matches_golden(spark, customer_summary_df):
    mgr = SnapshotManager(snapshot_dir="fixtures/expected_outputs")
    mgr.assert_match(customer_summary_df, "customer_summary")
```

---

## Setting Up Your Test Environment

### 1. Install Dependencies

```bash
pip install pyspark pytest
# Optional: Delta Lake support
pip install delta-spark
```

### 2. Project Structure

```
my-pipeline/
├── src/
│   ├── bronze_ingest.py
│   ├── silver_transform.py
│   └── gold_aggregate.py
├── tests/
│   ├── conftest.py          # Shared fixtures (SparkSession, mock dbutils)
│   ├── test_bronze.py
│   ├── test_silver.py
│   └── test_gold.py
├── fixtures/
│   ├── sample_data.json
│   └── expected_outputs/
└── configs/
    └── test_config.yaml
```

### 3. conftest.py Essentials

Every test suite needs a session-scoped SparkSession and mock dbutils:

```python
import pytest
from pyspark.sql import SparkSession

@pytest.fixture(scope="session")
def spark():
    session = (
        SparkSession.builder
        .master("local[2]")
        .appName("PipelineTests")
        .config("spark.sql.shuffle.partitions", "4")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )
    yield session
    session.stop()
```

### 4. Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run a specific layer
pytest tests/test_bronze_pipeline.py -v

# Run with coverage
pytest tests/ --cov=src --cov-report=html
```

---

## Mocking `dbutils` and External Services

Databricks notebooks rely on `dbutils` for secrets, widgets, and file operations.
The `MockDbutils` class provides a drop-in replacement:

```python
from mock_utils import MockDbutils

def test_with_secrets(mock_dbutils):
    mock_dbutils.secrets.create_scope("prod")
    mock_dbutils.secrets.put("prod", "api-key", "test-key-123")

    # Your pipeline code calls dbutils.secrets.get("prod", "api-key")
    key = mock_dbutils.secrets.get("prod", "api-key")
    assert key == "test-key-123"
```

---

## Generating Test Data

The `data_generators` module creates realistic DataFrames with deterministic seeding:

```python
from data_generators import CustomerGenerator, OrderGenerator

gen = CustomerGenerator(spark, seed=42)
customers = gen.generate(count=1000)

order_gen = OrderGenerator(spark, seed=42)
orders = order_gen.generate(count=5000, customer_ids=["cust_001", "cust_002"])
```

**Why deterministic seeds matter:** Tests should produce the same results every time.
A fixed seed ensures generated data is identical across runs, making failures
reproducible.

---

## Common Pitfalls

### 1. Spark Session Overhead
Create a single session-scoped SparkSession, not one per test. Starting Spark
takes 2-5 seconds; sharing it across tests keeps the suite fast.

### 2. Shuffle Partitions
Default `spark.sql.shuffle.partitions` is 200 — far too many for test data.
Set it to 4 or 8 for tests.

### 3. Non-Deterministic Ordering
Spark DataFrames have no inherent order. Always `.orderBy()` before comparing
results, or use set-based assertions.

### 4. Timezone Assumptions
Set `spark.sql.session.timeZone` to `"UTC"` in tests. Timestamp comparisons
will break across CI environments otherwise.

### 5. File Path Hardcoding
Use `Path(__file__).parent` or `tmp_path` fixtures instead of absolute paths.
Tests must work on any machine.

---

## CI/CD Integration

### GitHub Actions Example

```yaml
name: Pipeline Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - run: pip install pyspark pytest
      - run: pytest tests/ -v --tb=short --junitxml=reports/results.xml
      - uses: actions/upload-artifact@v4
        with:
          name: test-results
          path: reports/results.xml
```

### Databricks CI with `dbx`

```bash
# Run tests on a Databricks cluster
dbx execute --cluster-name="test-cluster" --entry-point="tests"
```

---

## Further Reading

- [PySpark Testing Guide](https://spark.apache.org/docs/latest/api/python/development/testing.html)
- [Delta Lake Documentation](https://docs.delta.io/latest/)
- [pytest Documentation](https://docs.pytest.org/en/stable/)

---

*By [Datanest Digital](https://datanest.dev) — Production-ready data engineering toolkits.*
