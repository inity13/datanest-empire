# Schema Evolution Strategy Guide

*By [Datanest Digital](https://datanest.dev) — Schema Evolution Toolkit v1.0.0*

---

## Table of Contents

1. [Why Schema Evolution Matters](#why-schema-evolution-matters)
2. [Backward vs Forward Compatibility](#backward-vs-forward-compatibility)
3. [Avro vs JSON Schema Evolution](#avro-vs-json-schema-evolution)
4. [Versioning Strategies](#versioning-strategies)
5. [Migration Patterns](#migration-patterns)
6. [Delta Lake Schema Evolution Options](#delta-lake-schema-evolution-options)
7. [Putting It All Together](#putting-it-all-together)

---

## Why Schema Evolution Matters

In any data platform that runs longer than a few months, schemas **will** change. New business requirements add columns, rename fields, or alter data types. Without a deliberate strategy:

- Downstream consumers break silently.
- ETL pipelines fail at 2 AM.
- Data quality degrades because invalid data slips through.
- Rollbacks become impossible without knowing what the schema looked like yesterday.

A good schema evolution strategy turns these surprises into controlled, reversible operations.

---

## Backward vs Forward Compatibility

These terms originate from the Apache Avro ecosystem but apply to any columnar or structured format.

### Backward Compatible

A schema change is **backward compatible** if consumers using the *old* schema can still read data written with the *new* schema.

| Allowed                         | Forbidden                         |
|---------------------------------|-----------------------------------|
| Add a nullable column           | Remove a column                   |
| Widen a type (int -> bigint)    | Narrow a type (bigint -> int)     |
| Make a column nullable          | Make a column non-nullable        |

**Use case**: Producers evolve first; consumers catch up later.

### Forward Compatible

A schema change is **forward compatible** if consumers using the *new* schema can still read data written with the *old* schema.

| Allowed                         | Forbidden                              |
|---------------------------------|----------------------------------------|
| Remove a column                 | Add a required (non-nullable) column   |
| Add optional columns            | Incompatible type changes              |

**Use case**: Consumers upgrade first; old data remains readable.

### Full Compatible

The intersection of backward and forward. Only changes that satisfy **both** directions are permitted. In practice this limits you to:

- Adding nullable columns (with defaults for old data).
- Safe type widenings.

**Use case**: Strict environments (gold/business-critical tables) where both producers and consumers must remain in sync.

---

## Avro vs JSON Schema Evolution

### Apache Avro

- Built-in schema evolution with writer/reader schema resolution.
- Default values required for backward compatibility when adding fields.
- Aliases allow field renames without breaking readers.
- The Confluent Schema Registry enforces compatibility modes per subject.
- Best suited for streaming systems (Kafka, event sourcing).

### JSON Schema

- No built-in evolution mechanism — you manage it yourself.
- `additionalProperties: true` is the closest equivalent to "allow new fields."
- Versioned schema files (v1, v2, ...) with explicit migration scripts.
- Best suited for REST APIs and config-driven pipelines.

### Spark / Delta Lake StructType

- Schemas are StructType definitions — essentially nested column metadata.
- Delta Lake supports schema evolution via `mergeSchema` and `overwriteSchema`.
- No built-in compatibility checking — that's what this toolkit provides.

---

## Versioning Strategies

### Semantic Versioning for Schemas

Apply SemVer principles to schema versions:

| Change Type                          | Version Bump |
|--------------------------------------|-------------|
| Backward-compatible addition         | MINOR       |
| Backward-compatible bug fix          | PATCH       |
| Breaking change (remove, rename)     | MAJOR       |

Example: `customer:1.0.0` -> `customer:1.1.0` (added nullable `phone` column).

### Linear Integer Versioning

Simpler alternative: monotonically increasing integer versions stored in the schema registry.

```
customer v1 -> v2 -> v3 -> v4
```

Each version entry includes metadata about what changed. Rollback means registering a new version that mirrors an old one.

### Branch-Based Versioning

For teams using feature branches, schemas can diverge temporarily. Merge the schema the same way you merge code:

1. Feature branch modifies the schema.
2. CI checks compatibility against the main-branch schema.
3. On merge, the new version is registered.

---

## Migration Patterns

### 1. Additive-Only Migration

The safest pattern. Only add nullable columns; never remove or rename.

```python
migrator.add_columns("catalog.silver.customers", {
    "phone": "STRING",
    "loyalty_tier": "STRING",
})
```

**Pros**: Always backward and forward compatible.
**Cons**: Tables accumulate deprecated columns over time.

### 2. Dual-Write Migration

When a rename is required (e.g., `email` -> `contact_email`):

1. Add the new column (`contact_email`).
2. Backfill: `UPDATE ... SET contact_email = email`.
3. Update all producers to write both columns.
4. Update all consumers to read `contact_email`.
5. After a grace period, drop the old column (`email`).

This keeps both old and new consumers happy during the transition.

### 3. View-Based Migration

Create views that translate between schema versions:

```sql
CREATE OR REPLACE VIEW catalog.silver.customers_v2 AS
SELECT id, name, email AS contact_email, phone, created_at
FROM catalog.silver.customers;
```

Old consumers continue using the original table; new consumers use the view.

### 4. Schema-on-Read with Coercion

Use the SchemaValidator in `coerce` mode to handle mismatches at read time:

```python
result = validator.validate(df, expected_schema, mode="coerce")
clean_df = result.coerced_df  # columns cast, missing nullables added
```

Useful for bronze-layer ingestion where source schemas are unpredictable.

---

## Delta Lake Schema Evolution Options

### `mergeSchema`

Automatically adds new columns during a write operation:

```python
(
    df.write
    .format("delta")
    .option("mergeSchema", "true")
    .mode("append")
    .saveAsTable("catalog.bronze.events")
)
```

**When to use**: Bronze layer with permissive policies.
**Risk**: Typos in column names create junk columns silently.

### `overwriteSchema`

Replaces the entire table schema. Existing data is rewritten.

```python
(
    df.write
    .format("delta")
    .option("overwriteSchema", "true")
    .mode("overwrite")
    .saveAsTable("catalog.silver.customers")
)
```

**When to use**: Major version bumps where the table is fully rebuilt.
**Risk**: Downstream consumers break if they haven't upgraded.

### ALTER TABLE ADD COLUMNS

Explicit DDL — no surprises:

```sql
ALTER TABLE catalog.silver.customers ADD COLUMNS (phone STRING, address STRUCT<...>);
```

**When to use**: Silver/gold layers with strict change control.
**Risk**: None (additive only), but requires a separate migration step.

### ALTER TABLE ALTER COLUMN TYPE

Widen a column's type in place:

```sql
ALTER TABLE catalog.silver.events ALTER COLUMN event_count TYPE BIGINT;
```

Only safe widenings are allowed (int -> bigint, float -> double, etc.). Delta Lake will reject narrowing operations.

### Column Mapping Mode

Enable `delta.columnMapping.mode = 'name'` to support column renames and drops:

```sql
ALTER TABLE catalog.silver.customers SET TBLPROPERTIES (
  'delta.columnMapping.mode' = 'name',
  'delta.minReaderVersion' = '2',
  'delta.minWriterVersion' = '5'
);

ALTER TABLE catalog.silver.customers RENAME COLUMN email TO contact_email;
ALTER TABLE catalog.silver.customers DROP COLUMN deprecated_field;
```

**When to use**: When renames or drops are unavoidable.
**Risk**: Requires reader/writer version upgrades; older clients may not read the table.

---

## Putting It All Together

A recommended layered strategy:

| Layer   | Compatibility | Auto-Evolve | Notes                              |
|---------|---------------|-------------|------------------------------------|
| Bronze  | None          | Yes         | `mergeSchema=true`, detect drift   |
| Silver  | Backward      | Selective   | Add columns only, check before DDL |
| Gold    | Full          | No          | Manual review + approval required  |

### Workflow

1. **Detect** — Run `detect_drift.py` on a schedule to compare live schemas against the registry.
2. **Check** — Use the CompatibilityChecker to verify proposed changes meet the layer's policy.
3. **Migrate** — Apply approved changes via the SchemaMigrator (with dry-run first).
4. **Register** — Record the new version in the SchemaRegistry for auditing and rollback.
5. **Validate** — Use the SchemaValidator in downstream notebooks to catch regressions early.

---

*For questions or support, contact [Datanest Digital](https://datanest.dev).*
