"""
Tests for the SchemaDetector module.

Covers detection of column additions, removals, type changes, nullable
changes, and nested struct changes.
"""

from __future__ import annotations

import sys
import os

import pytest
from pyspark.sql.types import (
    DoubleType,
    IntegerType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

# Ensure src/ is importable
sys.path.insert(
    0, os.path.join(os.path.dirname(__file__), os.pardir, "src")
)

from schema_detector import ChangeKind, SchemaDetector, SchemaReport


@pytest.fixture()
def detector() -> SchemaDetector:
    """SchemaDetector without a SparkSession (pure schema comparison)."""
    return SchemaDetector()


# ------------------------------------------------------------------
# Column additions
# ------------------------------------------------------------------

class TestAddedColumns:
    """Detect columns present in target but absent from source."""

    def test_single_addition(
        self, detector: SchemaDetector, schema_v1: StructType
    ) -> None:
        target = StructType(
            schema_v1.fields + [StructField("phone", StringType(), True)]
        )
        report = detector.compare(schema_v1, target)

        assert report.has_changes
        assert len(report.added) == 1
        assert report.added[0].column == "phone"
        assert report.added[0].kind == ChangeKind.ADDED

    def test_multiple_additions(
        self, detector: SchemaDetector, schema_v1: StructType
    ) -> None:
        target = StructType(
            schema_v1.fields
            + [
                StructField("phone", StringType(), True),
                StructField("address", StringType(), True),
            ]
        )
        report = detector.compare(schema_v1, target)
        assert len(report.added) == 2
        added_names = {c.column for c in report.added}
        assert added_names == {"phone", "address"}


# ------------------------------------------------------------------
# Column removals
# ------------------------------------------------------------------

class TestRemovedColumns:
    """Detect columns present in source but absent from target."""

    def test_single_removal(
        self, detector: SchemaDetector, schema_v1: StructType
    ) -> None:
        target = StructType(
            [f for f in schema_v1.fields if f.name != "email"]
        )
        report = detector.compare(schema_v1, target)

        assert report.has_changes
        assert len(report.removed) == 1
        assert report.removed[0].column == "email"

    def test_no_changes(
        self, detector: SchemaDetector, schema_v1: StructType
    ) -> None:
        report = detector.compare(schema_v1, schema_v1)
        assert not report.has_changes
        assert report.summary().startswith("SchemaReport:")


# ------------------------------------------------------------------
# Type changes
# ------------------------------------------------------------------

class TestTypeChanges:
    """Detect data type changes on existing columns."""

    def test_type_widening(
        self,
        detector: SchemaDetector,
        schema_v1_with_int_id: StructType,
        schema_v1: StructType,
    ) -> None:
        # schema_v1_with_int_id has IntegerType id; schema_v1 has LongType id
        report = detector.compare(schema_v1_with_int_id, schema_v1)
        assert len(report.type_changes) == 1
        tc = report.type_changes[0]
        assert tc.column == "id"
        assert tc.old_value == "int"
        assert tc.new_value == "bigint"

    def test_incompatible_type_change(
        self, detector: SchemaDetector
    ) -> None:
        source = StructType([StructField("val", LongType(), True)])
        target = StructType([StructField("val", StringType(), True)])
        report = detector.compare(source, target)
        assert len(report.type_changes) == 1
        assert report.type_changes[0].new_value == "string"


# ------------------------------------------------------------------
# Nullable changes
# ------------------------------------------------------------------

class TestNullableChanges:
    """Detect nullable flag changes."""

    def test_nullable_to_non_nullable(
        self, detector: SchemaDetector
    ) -> None:
        source = StructType([StructField("val", StringType(), True)])
        target = StructType([StructField("val", StringType(), False)])
        report = detector.compare(source, target)
        assert len(report.nullable_changes) == 1
        nc = report.nullable_changes[0]
        assert nc.old_value == "True"
        assert nc.new_value == "False"

    def test_non_nullable_to_nullable(
        self, detector: SchemaDetector
    ) -> None:
        source = StructType([StructField("val", StringType(), False)])
        target = StructType([StructField("val", StringType(), True)])
        report = detector.compare(source, target)
        assert len(report.nullable_changes) == 1


# ------------------------------------------------------------------
# Nested struct changes
# ------------------------------------------------------------------

class TestNestedChanges:
    """Detect structural changes inside nested structs."""

    def test_nested_field_addition(
        self,
        detector: SchemaDetector,
        schema_with_nested: StructType,
        schema_with_nested_changed: StructType,
    ) -> None:
        report = detector.compare(schema_with_nested, schema_with_nested_changed)
        assert report.has_changes
        # Should detect a NESTED_CHANGED for address, plus an ADDED for address.country
        nested = report.nested_changes
        assert len(nested) == 1
        assert nested[0].column == "address"

        added = report.added
        assert len(added) == 1
        assert added[0].path == "address.country"

    def test_nested_no_change(
        self,
        detector: SchemaDetector,
        schema_with_nested: StructType,
    ) -> None:
        report = detector.compare(schema_with_nested, schema_with_nested)
        assert not report.has_changes


# ------------------------------------------------------------------
# Report serialisation
# ------------------------------------------------------------------

class TestSchemaReport:
    """Test report helper methods."""

    def test_to_dict(self, detector: SchemaDetector, schema_v1: StructType) -> None:
        target = StructType(
            schema_v1.fields + [StructField("phone", StringType(), True)]
        )
        report = detector.compare(schema_v1, target)
        d = report.to_dict()
        assert isinstance(d, dict)
        assert "changes" in d
        assert len(d["changes"]) == 1
        assert d["changes"][0]["kind"] == "added"
