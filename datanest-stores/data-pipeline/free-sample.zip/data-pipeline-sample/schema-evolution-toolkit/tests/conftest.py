"""
Shared pytest fixtures for the Schema Evolution Toolkit test suite.

Provides a local SparkSession and reusable sample StructTypes for testing
schema detection, compatibility checking, and validation.
"""

from __future__ import annotations

from typing import Generator

import pytest
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    DoubleType,
    IntegerType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)


@pytest.fixture(scope="session")
def spark() -> Generator[SparkSession, None, None]:
    """Create a local SparkSession for the entire test session."""
    session = (
        SparkSession.builder
        .master("local[1]")
        .appName("schema-evolution-toolkit-tests")
        .config("spark.sql.shuffle.partitions", "1")
        .config("spark.ui.enabled", "false")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config(
            "spark.sql.catalog.spark_catalog",
            "org.apache.spark.sql.delta.catalog.DeltaCatalog",
        )
        .getOrCreate()
    )
    yield session
    session.stop()


# ------------------------------------------------------------------
# Sample StructTypes
# ------------------------------------------------------------------

@pytest.fixture()
def schema_v1() -> StructType:
    """Customer schema v1: id, name, email, created_at."""
    return StructType(
        [
            StructField("id", LongType(), nullable=False),
            StructField("name", StringType(), nullable=False),
            StructField("email", StringType(), nullable=False),
            StructField("created_at", TimestampType(), nullable=False),
        ]
    )


@pytest.fixture()
def schema_v2() -> StructType:
    """Customer schema v2: adds phone (nullable), renames email -> contact_email."""
    return StructType(
        [
            StructField("id", LongType(), nullable=False),
            StructField("name", StringType(), nullable=False),
            StructField("contact_email", StringType(), nullable=False),
            StructField("phone", StringType(), nullable=True),
            StructField("created_at", TimestampType(), nullable=False),
        ]
    )


@pytest.fixture()
def schema_v1_with_int_id() -> StructType:
    """Like v1 but id is IntegerType (for type-widening tests)."""
    return StructType(
        [
            StructField("id", IntegerType(), nullable=False),
            StructField("name", StringType(), nullable=False),
            StructField("email", StringType(), nullable=False),
            StructField("created_at", TimestampType(), nullable=False),
        ]
    )


@pytest.fixture()
def schema_with_nested() -> StructType:
    """Schema with a nested address struct."""
    address_type = StructType(
        [
            StructField("street", StringType(), nullable=True),
            StructField("city", StringType(), nullable=True),
            StructField("zip_code", StringType(), nullable=True),
        ]
    )
    return StructType(
        [
            StructField("id", LongType(), nullable=False),
            StructField("name", StringType(), nullable=False),
            StructField("address", address_type, nullable=True),
        ]
    )


@pytest.fixture()
def schema_with_nested_changed() -> StructType:
    """Same as schema_with_nested but address gains a 'country' field."""
    address_type = StructType(
        [
            StructField("street", StringType(), nullable=True),
            StructField("city", StringType(), nullable=True),
            StructField("zip_code", StringType(), nullable=True),
            StructField("country", StringType(), nullable=True),
        ]
    )
    return StructType(
        [
            StructField("id", LongType(), nullable=False),
            StructField("name", StringType(), nullable=False),
            StructField("address", address_type, nullable=True),
        ]
    )
