"""
Tests for the CompatibilityChecker module.

Covers backward, forward, and full compatibility checking using
Avro-style schema evolution rules.
"""

from __future__ import annotations

import sys
import os

import pytest
from pyspark.sql.types import (
    DoubleType,
    IntegerType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

# Ensure src/ is importable
sys.path.insert(
    0, os.path.join(os.path.dirname(__file__), os.pardir, "src")
)

from compatibility_checker import CompatibilityChecker, CompatibilityMode, CompatibilityResult


@pytest.fixture()
def checker() -> CompatibilityChecker:
    return CompatibilityChecker()


# ------------------------------------------------------------------
# Backward compatibility
# ------------------------------------------------------------------

class TestBackwardCompatibility:
    """Old readers can consume new data."""

    def test_add_nullable_column_is_compatible(
        self, checker: CompatibilityChecker, schema_v1: StructType
    ) -> None:
        new_schema = StructType(
            schema_v1.fields + [StructField("phone", StringType(), True)]
        )
        result = checker.check_backward_compatible(schema_v1, new_schema)
        assert result.is_compatible
        assert len(result.warnings) >= 1  # column added warning

    def test_remove_column_breaks_backward(
        self, checker: CompatibilityChecker, schema_v1: StructType
    ) -> None:
        new_schema = StructType(
            [f for f in schema_v1.fields if f.name != "email"]
        )
        result = checker.check_backward_compatible(schema_v1, new_schema)
        assert not result.is_compatible
        assert any("removed" in issue.lower() for issue in result.issues)

    def test_narrow_type_breaks_backward(
        self, checker: CompatibilityChecker
    ) -> None:
        old = StructType([StructField("val", LongType(), True)])
        new = StructType([StructField("val", IntegerType(), True)])
        result = checker.check_backward_compatible(old, new)
        assert not result.is_compatible

    def test_make_non_nullable_breaks_backward(
        self, checker: CompatibilityChecker
    ) -> None:
        old = StructType([StructField("val", StringType(), True)])
        new = StructType([StructField("val", StringType(), False)])
        result = checker.check_backward_compatible(old, new)
        assert not result.is_compatible

    def test_identical_schemas_are_compatible(
        self, checker: CompatibilityChecker, schema_v1: StructType
    ) -> None:
        result = checker.check_backward_compatible(schema_v1, schema_v1)
        assert result.is_compatible
        assert len(result.issues) == 0


# ------------------------------------------------------------------
# Forward compatibility
# ------------------------------------------------------------------

class TestForwardCompatibility:
    """New readers can consume old data."""

    def test_add_required_column_breaks_forward(
        self, checker: CompatibilityChecker, schema_v1: StructType
    ) -> None:
        new_schema = StructType(
            schema_v1.fields + [StructField("phone", StringType(), False)]
        )
        result = checker.check_forward_compatible(schema_v1, new_schema)
        assert not result.is_compatible
        assert any("required" in i.lower() for i in result.issues)

    def test_add_nullable_column_is_forward_compatible(
        self, checker: CompatibilityChecker, schema_v1: StructType
    ) -> None:
        new_schema = StructType(
            schema_v1.fields + [StructField("phone", StringType(), True)]
        )
        result = checker.check_forward_compatible(schema_v1, new_schema)
        assert result.is_compatible

    def test_remove_column_is_forward_compatible(
        self, checker: CompatibilityChecker, schema_v1: StructType
    ) -> None:
        new_schema = StructType(
            [f for f in schema_v1.fields if f.name != "email"]
        )
        result = checker.check_forward_compatible(schema_v1, new_schema)
        assert result.is_compatible  # new readers just ignore the old column


# ------------------------------------------------------------------
# Full compatibility
# ------------------------------------------------------------------

class TestFullCompatibility:
    """Both backward and forward at the same time."""

    def test_add_nullable_is_full_compatible(
        self, checker: CompatibilityChecker, schema_v1: StructType
    ) -> None:
        new_schema = StructType(
            schema_v1.fields + [StructField("phone", StringType(), True)]
        )
        result = checker.check_full_compatible(schema_v1, new_schema)
        assert result.is_compatible

    def test_remove_column_breaks_full(
        self, checker: CompatibilityChecker, schema_v1: StructType
    ) -> None:
        new_schema = StructType(
            [f for f in schema_v1.fields if f.name != "email"]
        )
        result = checker.check_full_compatible(schema_v1, new_schema)
        assert not result.is_compatible

    def test_add_required_column_breaks_full(
        self, checker: CompatibilityChecker, schema_v1: StructType
    ) -> None:
        new_schema = StructType(
            schema_v1.fields + [StructField("phone", StringType(), False)]
        )
        result = checker.check_full_compatible(schema_v1, new_schema)
        assert not result.is_compatible


# ------------------------------------------------------------------
# CompatibilityMode.NONE
# ------------------------------------------------------------------

class TestNoneMode:
    """No compatibility check — always passes."""

    def test_none_mode_always_passes(
        self, checker: CompatibilityChecker, schema_v1: StructType
    ) -> None:
        radically_different = StructType(
            [StructField("x", DoubleType(), True)]
        )
        result = checker.check(schema_v1, radically_different, mode=CompatibilityMode.NONE)
        assert result.is_compatible


# ------------------------------------------------------------------
# Result object
# ------------------------------------------------------------------

class TestCompatibilityResult:
    """Test the CompatibilityResult helper."""

    def test_summary_format(self, checker: CompatibilityChecker, schema_v1: StructType) -> None:
        result = checker.check_backward_compatible(schema_v1, schema_v1)
        summary = result.summary()
        assert "BACKWARD" in summary
        assert "COMPATIBLE" in summary
