# Databricks notebook source
# MAGIC %md
# MAGIC # Detect Schema Drift
# MAGIC
# MAGIC Compare source table schemas against expected definitions stored in Unity
# MAGIC Catalog Volumes or the schema registry. Generates a drift report for each
# MAGIC table pair.
# MAGIC
# MAGIC **Schema Evolution Toolkit** by [Datanest Digital](https://datanest.dev)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Parameters

# COMMAND ----------

# Widget parameters — configure via the notebook UI or job parameters.
dbutils.widgets.text("catalog", "main", "Catalog name")  # type: ignore[name-defined]
dbutils.widgets.text("schema", "bronze", "Schema (database) name")  # type: ignore[name-defined]
dbutils.widgets.text("schemas_volume_path", "/Volumes/main/meta/schemas", "Path to expected schema JSONs")  # type: ignore[name-defined]
dbutils.widgets.dropdown("output_format", "table", ["table", "json"], "Report output format")  # type: ignore[name-defined]

catalog: str = dbutils.widgets.get("catalog")  # type: ignore[name-defined]
schema: str = dbutils.widgets.get("schema")  # type: ignore[name-defined]
schemas_path: str = dbutils.widgets.get("schemas_volume_path")  # type: ignore[name-defined]
output_format: str = dbutils.widgets.get("output_format")  # type: ignore[name-defined]

print(f"Scanning {catalog}.{schema} against schemas in {schemas_path}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setup

# COMMAND ----------

import json
import os
import sys
from typing import Dict, List

# Add the toolkit src directory to the path so imports work in Databricks.
# Adjust the path below to wherever you uploaded the toolkit files.
sys.path.insert(0, "/Workspace/Repos/schema-evolution-toolkit/src")

from schema_detector import SchemaDetector, SchemaReport  # type: ignore[import-untyped]

detector = SchemaDetector(spark)  # type: ignore[name-defined]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Discover Tables & Expected Schemas

# COMMAND ----------

def discover_tables(catalog: str, schema: str) -> List[str]:
    """List all tables in the given catalog.schema."""
    rows = spark.sql(f"SHOW TABLES IN {catalog}.{schema}").collect()  # type: ignore[name-defined]
    return [f"{catalog}.{schema}.{row.tableName}" for row in rows]


def discover_expected_schemas(volume_path: str) -> Dict[str, str]:
    """Map table base name -> JSON file path from a Volume directory."""
    mapping: Dict[str, str] = {}
    for entry in dbutils.fs.ls(volume_path):  # type: ignore[name-defined]
        if entry.name.endswith(".json"):
            # Convention: file name is '<table_name>.json' or 'v<N>_<table_name>.json'
            base = entry.name.rsplit(".", 1)[0]
            # Strip version prefix if present (e.g. v2_customer -> customer)
            if "_" in base and base.split("_")[0].startswith("v"):
                base = "_".join(base.split("_")[1:])
            mapping[base] = entry.path
    return mapping


tables = discover_tables(catalog, schema)
expected_schemas = discover_expected_schemas(schemas_path)

print(f"Found {len(tables)} tables, {len(expected_schemas)} expected schemas")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Run Drift Detection

# COMMAND ----------

from pyspark.sql import Row  # type: ignore[import-untyped]
from pyspark.sql.types import (  # type: ignore[import-untyped]
    IntegerType,
    StringType,
    StructField,
    StructType,
)

report_rows: List[Row] = []

for table_fqn in tables:
    table_short = table_fqn.rsplit(".", 1)[-1]
    if table_short not in expected_schemas:
        print(f"  SKIP {table_fqn} — no expected schema found")
        continue

    schema_path = expected_schemas[table_short]
    report: SchemaReport = detector.compare_table_to_schema(table_fqn, schema_path)

    for change in report.changes:
        report_rows.append(
            Row(
                table=table_fqn,
                change_kind=change.kind.value,
                column=change.column,
                path=change.path,
                old_value=change.old_value or "",
                new_value=change.new_value or "",
                details=change.details,
            )
        )
    print(f"  {table_fqn}: {report.summary()}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display Results

# COMMAND ----------

if report_rows:
    report_schema = StructType(
        [
            StructField("table", StringType(), False),
            StructField("change_kind", StringType(), False),
            StructField("column", StringType(), False),
            StructField("path", StringType(), False),
            StructField("old_value", StringType(), True),
            StructField("new_value", StringType(), True),
            StructField("details", StringType(), True),
        ]
    )
    report_df = spark.createDataFrame(report_rows, schema=report_schema)  # type: ignore[name-defined]

    if output_format == "table":
        display(report_df)  # type: ignore[name-defined]
    else:
        print(json.dumps([row.asDict() for row in report_rows], indent=2))
else:
    print("No schema drift detected across all scanned tables.")
