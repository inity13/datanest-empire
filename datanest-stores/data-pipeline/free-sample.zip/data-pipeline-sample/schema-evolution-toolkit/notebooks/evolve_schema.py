# Databricks notebook source
# MAGIC %md
# MAGIC # Evolve Schema
# MAGIC
# MAGIC Apply approved schema evolutions to Delta tables. Supports a **dry-run**
# MAGIC mode that previews the migration plan without executing any DDL.
# MAGIC
# MAGIC **Schema Evolution Toolkit** by [Datanest Digital](https://datanest.dev)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Parameters

# COMMAND ----------

dbutils.widgets.text("table_name", "", "Fully qualified table name")  # type: ignore[name-defined]
dbutils.widgets.text("expected_schema_path", "", "Path to expected schema JSON")  # type: ignore[name-defined]
dbutils.widgets.dropdown("dry_run", "true", ["true", "false"], "Dry-run mode")  # type: ignore[name-defined]
dbutils.widgets.dropdown("compatibility_mode", "backward", ["backward", "forward", "full", "none"], "Compatibility check")  # type: ignore[name-defined]

table_name: str = dbutils.widgets.get("table_name")  # type: ignore[name-defined]
expected_schema_path: str = dbutils.widgets.get("expected_schema_path")  # type: ignore[name-defined]
dry_run: bool = dbutils.widgets.get("dry_run").lower() == "true"  # type: ignore[name-defined]
compatibility_mode: str = dbutils.widgets.get("compatibility_mode")  # type: ignore[name-defined]

assert table_name, "table_name widget must be set"
assert expected_schema_path, "expected_schema_path widget must be set"

print(f"Table: {table_name}")
print(f"Expected schema: {expected_schema_path}")
print(f"Dry run: {dry_run}")
print(f"Compatibility: {compatibility_mode}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setup

# COMMAND ----------

import sys

sys.path.insert(0, "/Workspace/Repos/schema-evolution-toolkit/src")

from compatibility_checker import CompatibilityChecker, CompatibilityMode  # type: ignore[import-untyped]
from schema_detector import SchemaDetector  # type: ignore[import-untyped]
from schema_migrator import SchemaMigrator  # type: ignore[import-untyped]

detector = SchemaDetector(spark)  # type: ignore[name-defined]
migrator = SchemaMigrator(spark)  # type: ignore[name-defined]
checker = CompatibilityChecker()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 1 — Detect Changes

# COMMAND ----------

report = detector.compare_table_to_schema(table_name, expected_schema_path)

if not report.has_changes:
    print("Schema is already up to date. Nothing to do.")
    dbutils.notebook.exit("NO_CHANGES")  # type: ignore[name-defined]

print(report.summary())
for change in report.changes:
    print(f"  {change}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 2 — Compatibility Check

# COMMAND ----------

actual_schema = spark.table(table_name).schema  # type: ignore[name-defined]
expected_schema = detector.load_schema_json(expected_schema_path)

compat_result = checker.check(
    old_schema=actual_schema,
    new_schema=expected_schema,
    mode=CompatibilityMode(compatibility_mode),
)

print(compat_result.summary())

if not compat_result.is_compatible:
    print("\nSchema evolution blocked — incompatible changes detected.")
    if not dry_run:
        dbutils.notebook.exit("BLOCKED_INCOMPATIBLE")  # type: ignore[name-defined]
    else:
        print("(dry-run mode — continuing to show plan regardless)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 3 — Build & Apply Migration Plan

# COMMAND ----------

from schema_detector import ChangeKind  # type: ignore[import-untyped]

# Build column additions from the drift report
columns_to_add = {}
for change in report.changes:
    if change.kind == ChangeKind.ADDED and change.new_value:
        columns_to_add[change.column] = change.new_value.upper()

if columns_to_add:
    plan = migrator.add_columns(table_name, columns_to_add, dry_run=dry_run)
    print(plan.summary())
    if dry_run:
        print("\n--- DRY RUN: no DDL was executed ---")
        for action in plan.actions:
            print(f"  SQL: {action.sql}")
    else:
        print("\nMigration applied successfully.")
else:
    print("No additive column changes to apply.")
    print("Other change types (type widening, removals) require manual review.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 4 — Verify

# COMMAND ----------

if not dry_run and columns_to_add:
    post_report = detector.compare_table_to_schema(table_name, expected_schema_path)
    if not post_report.has_changes:
        print("Post-migration verification: schema matches expected definition.")
    else:
        print("Post-migration verification: residual differences remain:")
        for change in post_report.changes:
            print(f"  {change}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Done
# MAGIC
# MAGIC Review the output above. If running in dry-run mode, re-run with
# MAGIC `dry_run = false` to apply the changes.

# COMMAND ----------

if dry_run:
    dbutils.notebook.exit("DRY_RUN_COMPLETE")  # type: ignore[name-defined]
else:
    dbutils.notebook.exit("APPLIED")  # type: ignore[name-defined]
