"""
Schema Detector — Detect schema changes between two Spark DataFrames or StructTypes.

Identifies new columns, dropped columns, type changes, nullable changes,
and nested struct changes. Produces a structured SchemaReport for downstream
consumption by the compatibility checker or schema migrator.

Part of the Schema Evolution Toolkit by Datanest Digital (https://datanest.dev).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import (
    ArrayType,
    DataType,
    MapType,
    StructField,
    StructType,
)


class ChangeKind(Enum):
    """Categories of schema change."""

    ADDED = "added"
    REMOVED = "removed"
    TYPE_CHANGED = "type_changed"
    NULLABLE_CHANGED = "nullable_changed"
    NESTED_CHANGED = "nested_changed"


@dataclass
class SchemaChange:
    """A single detected schema change."""

    kind: ChangeKind
    column: str
    old_value: Optional[str] = None
    new_value: Optional[str] = None
    path: str = ""
    details: str = ""

    def __str__(self) -> str:
        parts = [f"{self.kind.value.upper()}: {self.path or self.column}"]
        if self.old_value and self.new_value:
            parts.append(f"({self.old_value} -> {self.new_value})")
        if self.details:
            parts.append(f"[{self.details}]")
        return " ".join(parts)


@dataclass
class SchemaReport:
    """Aggregated report of all detected schema changes."""

    source_label: str = "source"
    target_label: str = "target"
    changes: List[SchemaChange] = field(default_factory=list)

    @property
    def added(self) -> List[SchemaChange]:
        """Columns present in target but not in source."""
        return [c for c in self.changes if c.kind == ChangeKind.ADDED]

    @property
    def removed(self) -> List[SchemaChange]:
        """Columns present in source but not in target."""
        return [c for c in self.changes if c.kind == ChangeKind.REMOVED]

    @property
    def type_changes(self) -> List[SchemaChange]:
        """Columns whose data type changed."""
        return [c for c in self.changes if c.kind == ChangeKind.TYPE_CHANGED]

    @property
    def nullable_changes(self) -> List[SchemaChange]:
        """Columns whose nullable flag changed."""
        return [c for c in self.changes if c.kind == ChangeKind.NULLABLE_CHANGED]

    @property
    def nested_changes(self) -> List[SchemaChange]:
        """Structural changes inside nested structs."""
        return [c for c in self.changes if c.kind == ChangeKind.NESTED_CHANGED]

    @property
    def has_changes(self) -> bool:
        """Return True if any schema change was detected."""
        return len(self.changes) > 0

    def summary(self) -> str:
        """One-line human-readable summary."""
        return (
            f"SchemaReport: {len(self.added)} added, "
            f"{len(self.removed)} removed, "
            f"{len(self.type_changes)} type changes, "
            f"{len(self.nullable_changes)} nullable changes, "
            f"{len(self.nested_changes)} nested changes"
        )

    def to_dict(self) -> Dict:
        """Serialise the report to a plain dictionary."""
        return {
            "source_label": self.source_label,
            "target_label": self.target_label,
            "summary": self.summary(),
            "changes": [
                {
                    "kind": c.kind.value,
                    "column": c.column,
                    "path": c.path,
                    "old_value": c.old_value,
                    "new_value": c.new_value,
                    "details": c.details,
                }
                for c in self.changes
            ],
        }


class SchemaDetector:
    """Compare two schemas and produce a change report.

    Works with :class:`pyspark.sql.types.StructType` objects directly or
    reads schemas from JSON files / live Delta tables via a SparkSession.
    """

    def __init__(self, spark: Optional[SparkSession] = None) -> None:
        self.spark = spark

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def compare(
        self,
        source: StructType,
        target: StructType,
        source_label: str = "source",
        target_label: str = "target",
    ) -> SchemaReport:
        """Compare two StructTypes and return a SchemaReport."""
        report = SchemaReport(source_label=source_label, target_label=target_label)
        self._compare_structs(source, target, prefix="", report=report)
        return report

    def compare_dataframes(
        self, source_df: DataFrame, target_df: DataFrame
    ) -> SchemaReport:
        """Compare schemas of two DataFrames."""
        return self.compare(source_df.schema, target_df.schema, "source_df", "target_df")

    def compare_table_to_schema(
        self, table_name: str, expected_schema_path: str
    ) -> SchemaReport:
        """Compare a live table's schema to an expected JSON schema file.

        Parameters
        ----------
        table_name:
            Fully qualified table name (e.g. ``catalog.schema.table``).
        expected_schema_path:
            Path to a JSON file containing a StructType definition.
        """
        if self.spark is None:
            raise RuntimeError("SparkSession is required for table comparison.")

        actual_schema = self.spark.table(table_name).schema
        expected_schema = self.load_schema_json(expected_schema_path)
        return self.compare(actual_schema, expected_schema, table_name, expected_schema_path)

    # ------------------------------------------------------------------
    # Schema I/O helpers
    # ------------------------------------------------------------------

    @staticmethod
    def load_schema_json(path: str) -> StructType:
        """Load a StructType from a JSON file on the local filesystem."""
        raw = Path(path).read_text(encoding="utf-8")
        schema_dict = json.loads(raw)
        # Strip toolkit metadata key if present
        schema_dict.pop("_schema_meta", None)
        return StructType.fromJson(schema_dict)

    # ------------------------------------------------------------------
    # Internal comparison logic
    # ------------------------------------------------------------------

    def _compare_structs(
        self,
        source: StructType,
        target: StructType,
        prefix: str,
        report: SchemaReport,
    ) -> None:
        """Recursively compare two StructTypes, recording changes."""
        source_fields: Dict[str, StructField] = {f.name: f for f in source.fields}
        target_fields: Dict[str, StructField] = {f.name: f for f in target.fields}

        source_names = set(source_fields.keys())
        target_names = set(target_fields.keys())

        # Detect removed columns
        for name in sorted(source_names - target_names):
            report.changes.append(
                SchemaChange(
                    kind=ChangeKind.REMOVED,
                    column=name,
                    path=f"{prefix}{name}",
                    old_value=source_fields[name].dataType.simpleString(),
                )
            )

        # Detect added columns
        for name in sorted(target_names - source_names):
            report.changes.append(
                SchemaChange(
                    kind=ChangeKind.ADDED,
                    column=name,
                    path=f"{prefix}{name}",
                    new_value=target_fields[name].dataType.simpleString(),
                    details=f"nullable={target_fields[name].nullable}",
                )
            )

        # Detect changes in common columns
        for name in sorted(source_names & target_names):
            src_field = source_fields[name]
            tgt_field = target_fields[name]
            col_path = f"{prefix}{name}"

            # Type change
            if src_field.dataType != tgt_field.dataType:
                # If both are StructType, recurse
                if isinstance(src_field.dataType, StructType) and isinstance(
                    tgt_field.dataType, StructType
                ):
                    report.changes.append(
                        SchemaChange(
                            kind=ChangeKind.NESTED_CHANGED,
                            column=name,
                            path=col_path,
                            details="struct fields differ",
                        )
                    )
                    self._compare_structs(
                        src_field.dataType,
                        tgt_field.dataType,
                        prefix=f"{col_path}.",
                        report=report,
                    )
                else:
                    report.changes.append(
                        SchemaChange(
                            kind=ChangeKind.TYPE_CHANGED,
                            column=name,
                            path=col_path,
                            old_value=src_field.dataType.simpleString(),
                            new_value=tgt_field.dataType.simpleString(),
                        )
                    )

            # Nullable change
            if src_field.nullable != tgt_field.nullable:
                report.changes.append(
                    SchemaChange(
                        kind=ChangeKind.NULLABLE_CHANGED,
                        column=name,
                        path=col_path,
                        old_value=str(src_field.nullable),
                        new_value=str(tgt_field.nullable),
                    )
                )
