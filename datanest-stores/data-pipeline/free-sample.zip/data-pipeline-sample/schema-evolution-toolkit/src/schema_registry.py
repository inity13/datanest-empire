"""
Schema Registry — Local schema registry backed by a Delta table.

Store versioned schema definitions, diff between versions, and rollback to
a previous version when needed. Each schema is stored as a row keyed by
(subject, version).

Part of the Schema Evolution Toolkit by Datanest Digital (https://datanest.dev).
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional

from pyspark.sql import Row, SparkSession
from pyspark.sql.types import (
    IntegerType as SparkIntegerType,
    StringType as SparkStringType,
    StructField,
    StructType,
    TimestampType as SparkTimestampType,
)

from schema_detector import SchemaDetector, SchemaReport

# Schema of the registry Delta table itself
_REGISTRY_SCHEMA = StructType(
    [
        StructField("subject", SparkStringType(), nullable=False),
        StructField("version", SparkIntegerType(), nullable=False),
        StructField("schema_json", SparkStringType(), nullable=False),
        StructField("description", SparkStringType(), nullable=True),
        StructField("registered_at", SparkTimestampType(), nullable=False),
    ]
)


@dataclass
class SchemaVersion:
    """A single version entry in the registry."""

    subject: str
    version: int
    schema: StructType
    description: Optional[str]
    registered_at: datetime


class SchemaRegistry:
    """Delta-table-backed schema version registry.

    Parameters
    ----------
    spark:
        Active SparkSession.
    registry_table:
        Fully qualified name for the registry Delta table
        (e.g. ``catalog.meta.schema_registry``).
    """

    def __init__(self, spark: SparkSession, registry_table: str) -> None:
        self.spark = spark
        self.registry_table = registry_table
        self._detector = SchemaDetector()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def init_registry(self) -> None:
        """Create the registry Delta table if it does not already exist."""
        self.spark.sql(
            f"""
            CREATE TABLE IF NOT EXISTS {self.registry_table} (
                subject STRING NOT NULL,
                version INT NOT NULL,
                schema_json STRING NOT NULL,
                description STRING,
                registered_at TIMESTAMP NOT NULL
            )
            USING DELTA
            TBLPROPERTIES ('delta.columnMapping.mode' = 'name')
            """
        )

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(
        self,
        subject: str,
        version: int,
        schema: StructType,
        description: Optional[str] = None,
    ) -> None:
        """Register a new schema version.

        Parameters
        ----------
        subject:
            Logical name (e.g. ``"customers"``).
        version:
            Integer version number (must be unique per subject).
        schema:
            The StructType to store.
        description:
            Optional human-readable change description.
        """
        schema_json = schema.json()
        row = Row(
            subject=subject,
            version=version,
            schema_json=schema_json,
            description=description,
            registered_at=datetime.utcnow(),
        )
        df = self.spark.createDataFrame([row], schema=_REGISTRY_SCHEMA)
        df.write.format("delta").mode("append").saveAsTable(self.registry_table)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_latest(self, subject: str) -> Optional[SchemaVersion]:
        """Return the latest version for *subject*, or None."""
        rows = (
            self.spark.table(self.registry_table)
            .filter(f"subject = '{subject}'")
            .orderBy("version", ascending=False)
            .limit(1)
            .collect()
        )
        if not rows:
            return None
        return self._row_to_version(rows[0])

    def get_version(self, subject: str, version: int) -> Optional[SchemaVersion]:
        """Return a specific version, or None if not found."""
        rows = (
            self.spark.table(self.registry_table)
            .filter(f"subject = '{subject}' AND version = {version}")
            .collect()
        )
        if not rows:
            return None
        return self._row_to_version(rows[0])

    def list_versions(self, subject: str) -> List[SchemaVersion]:
        """Return all versions for *subject* ordered by version number."""
        rows = (
            self.spark.table(self.registry_table)
            .filter(f"subject = '{subject}'")
            .orderBy("version")
            .collect()
        )
        return [self._row_to_version(r) for r in rows]

    # ------------------------------------------------------------------
    # Diff & rollback
    # ------------------------------------------------------------------

    def diff(self, subject: str, version_a: int, version_b: int) -> SchemaReport:
        """Diff two registered versions and return a SchemaReport."""
        va = self.get_version(subject, version_a)
        vb = self.get_version(subject, version_b)
        if va is None or vb is None:
            raise ValueError(
                f"Version not found: subject={subject}, "
                f"a={version_a}, b={version_b}"
            )
        return self._detector.compare(
            va.schema,
            vb.schema,
            source_label=f"v{version_a}",
            target_label=f"v{version_b}",
        )

    def rollback(self, subject: str, to_version: int) -> None:
        """Soft-rollback: register *to_version*'s schema as the next version.

        This does **not** delete rows — it appends a new version entry
        whose schema matches the target rollback version.
        """
        target = self.get_version(subject, to_version)
        if target is None:
            raise ValueError(f"Cannot rollback: version {to_version} not found for {subject}.")
        latest = self.get_latest(subject)
        next_version = (latest.version + 1) if latest else 1
        self.register(
            subject=subject,
            version=next_version,
            schema=target.schema,
            description=f"Rollback to v{to_version}",
        )

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_version(row: Row) -> SchemaVersion:
        """Convert a Spark Row to a SchemaVersion dataclass."""
        return SchemaVersion(
            subject=row["subject"],
            version=row["version"],
            schema=StructType.fromJson(json.loads(row["schema_json"])),
            description=row["description"],
            registered_at=row["registered_at"],
        )
