"""
Schema Validator — Validate a DataFrame against an expected StructType.

Supports three validation modes:
- **strict**: columns must match exactly (names, types, nullable, order).
- **lenient**: extra columns in the DataFrame are allowed; missing nullable
  columns produce warnings instead of errors.
- **coerce**: attempt to cast mismatched columns to the expected types and
  add missing nullable columns filled with nulls.

Part of the Schema Evolution Toolkit by Datanest Digital (https://datanest.dev).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StructField, StructType


class ValidationMode(Enum):
    """Validation strictness level."""

    STRICT = "strict"
    LENIENT = "lenient"
    COERCE = "coerce"


@dataclass
class ValidationResult:
    """Outcome of a schema validation."""

    is_valid: bool
    mode: ValidationMode
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    coerced_df: Optional[DataFrame] = None

    def summary(self) -> str:
        status = "VALID" if self.is_valid else "INVALID"
        lines = [f"Validation ({self.mode.value}): {status}"]
        for err in self.errors:
            lines.append(f"  ERROR: {err}")
        for warn in self.warnings:
            lines.append(f"  WARNING: {warn}")
        return "\n".join(lines)


class SchemaValidator:
    """Validate DataFrame schemas against an expected StructType."""

    def __init__(self, spark: Optional[SparkSession] = None) -> None:
        self.spark = spark

    def validate(
        self,
        df: DataFrame,
        expected: StructType,
        mode: str = "strict",
    ) -> ValidationResult:
        """Validate *df* against *expected* schema.

        Parameters
        ----------
        df:
            The DataFrame to validate.
        expected:
            The StructType the DataFrame should conform to.
        mode:
            One of ``"strict"``, ``"lenient"``, or ``"coerce"``.
        """
        vmode = ValidationMode(mode)
        actual = df.schema
        actual_fields = {f.name: f for f in actual.fields}
        expected_fields = {f.name: f for f in expected.fields}

        errors: List[str] = []
        warnings: List[str] = []
        coerced_df: Optional[DataFrame] = df if vmode == ValidationMode.COERCE else None

        # Check for missing columns
        for name, exp_field in expected_fields.items():
            if name not in actual_fields:
                if vmode == ValidationMode.STRICT:
                    errors.append(f"Missing column: {name} ({exp_field.dataType.simpleString()})")
                elif vmode == ValidationMode.LENIENT:
                    if exp_field.nullable:
                        warnings.append(f"Missing nullable column: {name}")
                    else:
                        errors.append(f"Missing required column: {name}")
                elif vmode == ValidationMode.COERCE:
                    if exp_field.nullable:
                        warnings.append(f"Added missing column as null: {name}")
                        coerced_df = coerced_df.withColumn(  # type: ignore[union-attr]
                            name, F.lit(None).cast(exp_field.dataType)
                        )
                    else:
                        errors.append(f"Missing required column (cannot coerce): {name}")
                continue

            act_field = actual_fields[name]

            # Type mismatch
            if act_field.dataType != exp_field.dataType:
                if vmode == ValidationMode.COERCE:
                    warnings.append(
                        f"Casting {name}: {act_field.dataType.simpleString()} "
                        f"-> {exp_field.dataType.simpleString()}"
                    )
                    coerced_df = coerced_df.withColumn(  # type: ignore[union-attr]
                        name, F.col(name).cast(exp_field.dataType)
                    )
                else:
                    errors.append(
                        f"Type mismatch for {name}: expected "
                        f"{exp_field.dataType.simpleString()}, "
                        f"got {act_field.dataType.simpleString()}"
                    )

            # Nullable mismatch (strict only)
            if vmode == ValidationMode.STRICT:
                if act_field.nullable != exp_field.nullable:
                    errors.append(
                        f"Nullable mismatch for {name}: expected "
                        f"{exp_field.nullable}, got {act_field.nullable}"
                    )

        # Extra columns
        extra = set(actual_fields.keys()) - set(expected_fields.keys())
        if extra:
            if vmode == ValidationMode.STRICT:
                errors.append(f"Unexpected columns: {sorted(extra)}")
            else:
                warnings.append(f"Extra columns ignored: {sorted(extra)}")

        is_valid = len(errors) == 0
        return ValidationResult(
            is_valid=is_valid,
            mode=vmode,
            errors=errors,
            warnings=warnings,
            coerced_df=coerced_df if vmode == ValidationMode.COERCE else None,
        )
