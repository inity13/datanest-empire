"""
Schema Migrator — Apply schema changes to Delta tables safely.

Supports ALTER TABLE ADD COLUMNS, type widening, and backward-compatible
migrations. Includes dry-run mode and rollback via Delta time travel.

Part of the Schema Evolution Toolkit by Datanest Digital (https://datanest.dev).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from pyspark.sql import SparkSession
from pyspark.sql.types import StructField, StructType


# Allowed type widening paths (source -> target)
_WIDENING_RULES: Dict[str, List[str]] = {
    "ByteType": ["ShortType", "IntegerType", "LongType"],
    "ShortType": ["IntegerType", "LongType"],
    "IntegerType": ["LongType", "DoubleType"],
    "LongType": ["DoubleType"],
    "FloatType": ["DoubleType"],
    "DateType": ["TimestampType"],
}


@dataclass
class MigrationAction:
    """One discrete migration step."""

    action: str  # add_columns | widen_type | set_nullable
    table: str
    details: str
    sql: str


@dataclass
class MigrationPlan:
    """Ordered list of migration actions to be applied."""

    table: str
    actions: List[MigrationAction] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        return len(self.actions) == 0

    def summary(self) -> str:
        if self.is_empty:
            return f"No migrations needed for {self.table}."
        lines = [f"Migration plan for {self.table} ({len(self.actions)} actions):"]
        for i, a in enumerate(self.actions, 1):
            lines.append(f"  {i}. [{a.action}] {a.details}")
        return "\n".join(lines)


class SchemaMigrator:
    """Apply safe schema migrations to Delta tables.

    All mutations go through :meth:`apply_plan` which can optionally run in
    *dry-run* mode (``dry_run=True``) to preview the generated SQL without
    executing anything.
    """

    def __init__(self, spark: SparkSession) -> None:
        self.spark = spark

    # ------------------------------------------------------------------
    # High-level helpers
    # ------------------------------------------------------------------

    def add_columns(
        self,
        table_name: str,
        columns: Dict[str, str],
        dry_run: bool = False,
    ) -> MigrationPlan:
        """Add one or more nullable columns to a Delta table.

        Parameters
        ----------
        table_name:
            Fully qualified table name.
        columns:
            Mapping of ``column_name -> SQL type`` (e.g. ``{"phone": "STRING"}``).
        dry_run:
            If True, return the plan without executing SQL.
        """
        plan = MigrationPlan(table=table_name)
        for col_name, col_type in columns.items():
            sql = f"ALTER TABLE {table_name} ADD COLUMNS ({col_name} {col_type})"
            plan.actions.append(
                MigrationAction(
                    action="add_columns",
                    table=table_name,
                    details=f"Add column {col_name} {col_type}",
                    sql=sql,
                )
            )
        if not dry_run:
            self._execute_plan(plan)
        return plan

    def widen_type(
        self,
        table_name: str,
        column_name: str,
        new_type: str,
        dry_run: bool = False,
    ) -> MigrationPlan:
        """Widen a column's type (e.g. INT -> BIGINT).

        Parameters
        ----------
        table_name:
            Fully qualified table name.
        column_name:
            Column to widen.
        new_type:
            Target SQL type string.
        dry_run:
            If True, return the plan without executing SQL.
        """
        plan = MigrationPlan(table=table_name)
        sql = f"ALTER TABLE {table_name} ALTER COLUMN {column_name} TYPE {new_type}"
        plan.actions.append(
            MigrationAction(
                action="widen_type",
                table=table_name,
                details=f"Widen {column_name} to {new_type}",
                sql=sql,
            )
        )
        if not dry_run:
            self._execute_plan(plan)
        return plan

    def set_nullable(
        self,
        table_name: str,
        column_name: str,
        dry_run: bool = False,
    ) -> MigrationPlan:
        """Change a column to nullable (DROP NOT NULL).

        Parameters
        ----------
        table_name:
            Fully qualified table name.
        column_name:
            Column to make nullable.
        dry_run:
            If True, return the plan without executing SQL.
        """
        plan = MigrationPlan(table=table_name)
        sql = f"ALTER TABLE {table_name} ALTER COLUMN {column_name} DROP NOT NULL"
        plan.actions.append(
            MigrationAction(
                action="set_nullable",
                table=table_name,
                details=f"Set {column_name} nullable",
                sql=sql,
            )
        )
        if not dry_run:
            self._execute_plan(plan)
        return plan

    def apply_plan(self, plan: MigrationPlan, dry_run: bool = False) -> MigrationPlan:
        """Execute an existing migration plan.

        Parameters
        ----------
        plan:
            The plan to apply.
        dry_run:
            If True, skip SQL execution and just return the plan.
        """
        if not dry_run:
            self._execute_plan(plan)
        return plan

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    @staticmethod
    def is_safe_widening(from_type: str, to_type: str) -> bool:
        """Check whether widening *from_type* to *to_type* is safe."""
        return to_type in _WIDENING_RULES.get(from_type, [])

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _execute_plan(self, plan: MigrationPlan) -> None:
        """Execute every action's SQL statement in order."""
        for action in plan.actions:
            self.spark.sql(action.sql)
