"""
Compatibility Checker — Check forward, backward, and full compatibility
between schema versions using Avro-style rules.

Rules:
- **Backward compatible**: consumers using the *old* schema can read data
  written with the *new* schema. Adding nullable columns and widening types
  is allowed; removing columns and narrowing types is not.
- **Forward compatible**: consumers using the *new* schema can read data
  written with the *old* schema. Removing columns is allowed; adding
  required columns is not.
- **Full compatible**: both backward and forward compatible simultaneously.

Part of the Schema Evolution Toolkit by Datanest Digital (https://datanest.dev).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set

from pyspark.sql.types import StructField, StructType

from schema_detector import ChangeKind, SchemaDetector, SchemaReport


class CompatibilityMode(Enum):
    """Supported compatibility modes."""

    BACKWARD = "backward"
    FORWARD = "forward"
    FULL = "full"
    NONE = "none"


# Safe type widening paths (same as migrator)
_SAFE_WIDENINGS: Dict[str, Set[str]] = {
    "byte": {"short", "int", "bigint", "double"},
    "short": {"int", "bigint", "double"},
    "int": {"bigint", "double"},
    "bigint": {"double"},
    "float": {"double"},
    "date": {"timestamp"},
}


@dataclass
class CompatibilityResult:
    """Result of a compatibility check."""

    mode: CompatibilityMode
    is_compatible: bool
    issues: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def summary(self) -> str:
        status = "COMPATIBLE" if self.is_compatible else "INCOMPATIBLE"
        lines = [f"{self.mode.value.upper()} check: {status}"]
        for issue in self.issues:
            lines.append(f"  BREAKING: {issue}")
        for warning in self.warnings:
            lines.append(f"  WARNING: {warning}")
        return "\n".join(lines)


class CompatibilityChecker:
    """Check schema compatibility between two StructType versions."""

    def __init__(self) -> None:
        self._detector = SchemaDetector()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check(
        self,
        old_schema: StructType,
        new_schema: StructType,
        mode: CompatibilityMode = CompatibilityMode.BACKWARD,
    ) -> CompatibilityResult:
        """Run a compatibility check for the given mode.

        Parameters
        ----------
        old_schema:
            The previously registered / deployed schema.
        new_schema:
            The proposed new schema.
        mode:
            Which compatibility guarantee to verify.
        """
        if mode == CompatibilityMode.NONE:
            return CompatibilityResult(mode=mode, is_compatible=True)
        if mode == CompatibilityMode.BACKWARD:
            return self.check_backward_compatible(old_schema, new_schema)
        if mode == CompatibilityMode.FORWARD:
            return self.check_forward_compatible(old_schema, new_schema)
        # FULL = backward AND forward
        return self.check_full_compatible(old_schema, new_schema)

    def check_backward_compatible(
        self, old_schema: StructType, new_schema: StructType
    ) -> CompatibilityResult:
        """Verify backward compatibility (old readers can consume new data)."""
        report = self._detector.compare(old_schema, new_schema, "old", "new")
        result = CompatibilityResult(mode=CompatibilityMode.BACKWARD, is_compatible=True)

        for change in report.changes:
            if change.kind == ChangeKind.REMOVED:
                result.issues.append(f"Column removed: {change.path}")
                result.is_compatible = False
            elif change.kind == ChangeKind.TYPE_CHANGED:
                if not self._is_safe_widening(change.old_value, change.new_value):
                    result.issues.append(
                        f"Type narrowed or incompatible: {change.path} "
                        f"({change.old_value} -> {change.new_value})"
                    )
                    result.is_compatible = False
                else:
                    result.warnings.append(
                        f"Type widened: {change.path} ({change.old_value} -> {change.new_value})"
                    )
            elif change.kind == ChangeKind.NULLABLE_CHANGED:
                if change.old_value == "True" and change.new_value == "False":
                    result.issues.append(f"Column became non-nullable: {change.path}")
                    result.is_compatible = False
            elif change.kind == ChangeKind.ADDED:
                result.warnings.append(f"Column added: {change.path}")

        return result

    def check_forward_compatible(
        self, old_schema: StructType, new_schema: StructType
    ) -> CompatibilityResult:
        """Verify forward compatibility (new readers can consume old data)."""
        report = self._detector.compare(old_schema, new_schema, "old", "new")
        result = CompatibilityResult(mode=CompatibilityMode.FORWARD, is_compatible=True)

        for change in report.changes:
            if change.kind == ChangeKind.ADDED:
                # New required column won't have values in old data
                if change.details and "nullable=False" in change.details:
                    result.issues.append(
                        f"Required column added (no default for old data): {change.path}"
                    )
                    result.is_compatible = False
                else:
                    result.warnings.append(f"Nullable column added: {change.path}")
            elif change.kind == ChangeKind.TYPE_CHANGED:
                if not self._is_safe_widening(change.old_value, change.new_value):
                    result.issues.append(
                        f"Incompatible type change: {change.path} "
                        f"({change.old_value} -> {change.new_value})"
                    )
                    result.is_compatible = False
            elif change.kind == ChangeKind.REMOVED:
                result.warnings.append(f"Column removed (new readers skip it): {change.path}")

        return result

    def check_full_compatible(
        self, old_schema: StructType, new_schema: StructType
    ) -> CompatibilityResult:
        """Verify full compatibility (backward AND forward)."""
        backward = self.check_backward_compatible(old_schema, new_schema)
        forward = self.check_forward_compatible(old_schema, new_schema)

        result = CompatibilityResult(
            mode=CompatibilityMode.FULL,
            is_compatible=backward.is_compatible and forward.is_compatible,
            issues=backward.issues + forward.issues,
            warnings=backward.warnings + forward.warnings,
        )
        return result

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _is_safe_widening(old_type: Optional[str], new_type: Optional[str]) -> bool:
        """Check if *old_type* can be safely widened to *new_type*."""
        if old_type is None or new_type is None:
            return False
        allowed = _SAFE_WIDENINGS.get(old_type, set())
        return new_type in allowed
