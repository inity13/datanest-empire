# OKR & Goal Setting Kit

OKR templates with cascading objectives, key results tracking, check-in formats, and quarterly review frameworks.

## Contents

- `config.example.yaml`
- `pyproject.toml`
- `src/okr_goal_setting_kit/__init__.py`
- `src/okr_goal_setting_kit/core.py`
- `src/okr_goal_setting_kit/utils.py`

## Quick Start

1. Extract the ZIP archive
2. Review the README and documentation
3. Customize configuration files for your environment
4. Follow the setup guide for your specific use case

## Requirements

- Python 3.10+ (for Python scripts)
- Relevant CLI tools for your platform
- Access to your target environment

## License

MIT License — see LICENSE file.

## Support

Questions or issues? Email megafolder122122@hotmail.com

---
Part of [Pm Toolkit](https://inity13.github.io/pm-toolkit-pro/)
