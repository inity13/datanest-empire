# Pre-Deployment Checklist — REST API Design Guide

## Infrastructure
- [ ] All required cloud resources provisioned
- [ ] Network connectivity verified between components
- [ ] DNS records configured
- [ ] SSL/TLS certificates installed
- [ ] Firewall rules reviewed and applied

## Security
- [ ] All secrets stored in vault/secrets manager
- [ ] Service accounts created with least privilege
- [ ] Encryption at rest enabled
- [ ] Encryption in transit enabled
- [ ] Audit logging configured

## Monitoring
- [ ] Health check endpoints verified
- [ ] Alerting rules configured
- [ ] Dashboards created
- [ ] Log aggregation confirmed
- [ ] On-call rotation set up

## Testing
- [ ] Integration tests passing
- [ ] Load testing completed
- [ ] Failover testing completed
- [ ] Rollback procedure tested
- [ ] Documentation reviewed

## Sign-off
- [ ] Architecture review completed
- [ ] Security review completed
- [ ] Operations team briefed
- [ ] Runbooks written
