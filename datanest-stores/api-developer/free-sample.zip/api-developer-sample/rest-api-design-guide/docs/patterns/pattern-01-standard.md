# Pattern 1: Standard Implementation

## When to Use
- Greenfield projects with moderate complexity
- Teams of 3-10 engineers
- Standard compliance requirements

## Architecture
```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│   Ingestion  │────>│  Processing  │────>│   Serving    │
└─────────────┘     └──────────────┘     └─────────────┘
       │                    │                    │
       └────────────────────┴────────────────────┘
                            │
                    ┌───────▼───────┐
                    │  Monitoring   │
                    └───────────────┘
```

## Configuration

See `templates/standard/` for ready-to-use configuration files.

## Trade-offs

| Aspect | Pros | Cons |
|--------|------|------|
| Complexity | Simple to understand | Limited scalability |
| Cost | Low initial cost | May need rearchitecture later |
| Time to deploy | Days | — |
| Team skill required | Intermediate | — |
