# Personal Budget & Net Worth Tracker

Monthly budget, expense categories, savings goals, investment tracking, and net worth calculation with trend charts.

## Contents

- `config.example.yaml`

## Quick Start

1. Extract the ZIP archive
2. Review the README and documentation
3. Customize configuration files for your environment
4. Follow the setup guide for your specific use case

## Requirements

- Python 3.10+ (for Python scripts)
- Relevant CLI tools for your platform
- Access to your target environment

## License

MIT License — see LICENSE file.

## Support

Questions or issues? Email megafolder122122@hotmail.com

---
Part of [Spreadsheet Tools](https://inity13.github.io/spreadsheet-tools-pro/)
