# Python Logging Config — Production-Ready Logging Setup

> Structured logging, request context, ASGI/WSGI middleware, and environment-specific configs in one drop-in package.

## What You Get

- **One-call setup** — `configure_logging("prod")` loads the right YAML config
- **Structured JSON formatter** — machine-readable logs for Datadog, ELK, CloudWatch
- **Request context** — automatic `request_id`, `user_id` in every log line
- **ASGI & WSGI middleware** — plug into FastAPI, Starlette, Flask, Django
- **Smart filters** — suppress noisy loggers, rate-limit repeated messages
- **3 YAML configs** — dev (colorized console), prod (JSON to file + stdout), test (minimal)

## File Tree

```
python-logging-config/
├── README.md
├── manifest.json
├── LICENSE
├── src/
│   ├── setup.py          # One-call logging configuration
│   ├── formatters.py     # JSON, colored, and key-value formatters
│   ├── handlers.py       # Rotating file, async queue handler
│   ├── context.py        # Context variables (request_id, user_id)
│   ├── middleware.py      # ASGI and WSGI middleware
│   └── filters.py        # Rate-limit and suppression filters
├── configs/
│   ├── logging_dev.yaml   # Development config
│   ├── logging_prod.yaml  # Production config
│   └── logging_test.yaml  # Test config
├── examples/
│   ├── fastapi_example.py # FastAPI integration
│   └── celery_example.py  # Celery task logging
├── tests/
│   └── test_logging.py
└── guides/
    └── logging-guide.md
```

## Getting Started

### Quick setup

```python
from src.setup import configure_logging

configure_logging("dev")  # Colorized console output

import logging
logger = logging.getLogger(__name__)
logger.info("Application started")
```

### Structured JSON logging (production)

```python
configure_logging("prod")
logger.info("Order placed", extra={"order_id": "ORD-123", "total": 49.99})
# {"timestamp": "2026-03-10T12:00:00Z", "level": "INFO", "message": "Order placed", "order_id": "ORD-123", ...}
```

### Request context in FastAPI

```python
from fastapi import FastAPI
from src.middleware import ASGILoggingMiddleware
from src.setup import configure_logging

configure_logging("prod")
app = FastAPI()
app.add_middleware(ASGILoggingMiddleware)

# Every log line inside a request now includes request_id automatically
```

### Rate-limited filter

```python
from src.filters import RateLimitFilter

# Suppress repeated messages — at most 1 per 60 seconds per message
handler.addFilter(RateLimitFilter(period_seconds=60))
```

## Requirements

- Python 3.10+
- PyYAML (`pip install pyyaml`)
- `pytest` for running tests

```bash
pip install pyyaml
pytest tests/test_logging.py -v
```

## Architecture

```
┌─────────────────────────────────────────────┐
│           configure_logging(env)             │
│  Loads YAML → logging.config.dictConfig()    │
├──────────┬──────────────┬───────────────────┤
│Formatters│   Handlers   │     Filters       │
│ JSON     │ RotatingFile │ RateLimit         │
│ Colored  │ AsyncQueue   │ SuppressLogger    │
│ KeyValue │ Stream       │                   │
├──────────┴──────────────┴───────────────────┤
│           Context Variables                  │
│  request_id │ user_id │ correlation_id      │
├─────────────┴─────────┴────────────────────┤
│  ASGI Middleware  │  WSGI Middleware         │
└───────────────────┴─────────────────────────┘
```

## License

MIT License — Copyright (c) 2026 Datanest Digital

By [Datanest Digital](https://datanest.dev) | Version 1.0.0 | $19
