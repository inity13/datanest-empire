"""Logging context variables — propagate request_id, user_id, etc.

Uses :mod:`contextvars` so each async task / thread gets its own context
automatically.

Usage:
    from src.context import set_context, get_context

    set_context(request_id="req-abc-123", user_id="usr-42")
    # ... later, in any log formatter:
    ctx = get_context()  # {"request_id": "req-abc-123", "user_id": "usr-42"}
"""

from __future__ import annotations

import contextvars
import uuid
from typing import Any

_request_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "request_id", default=None
)
_user_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "user_id", default=None
)
_correlation_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "correlation_id", default=None
)
_extra: contextvars.ContextVar[dict[str, Any]] = contextvars.ContextVar(
    "log_extra", default={}
)


def set_context(
    *,
    request_id: str | None = None,
    user_id: str | None = None,
    correlation_id: str | None = None,
    **kwargs: Any,
) -> None:
    """Set context variables for the current execution context.

    Args:
        request_id: Unique ID for the current request.
        user_id: Authenticated user identifier.
        correlation_id: Cross-service correlation ID.
        **kwargs: Additional key-value pairs added to context.
    """
    if request_id is not None:
        _request_id.set(request_id)
    if user_id is not None:
        _user_id.set(user_id)
    if correlation_id is not None:
        _correlation_id.set(correlation_id)
    if kwargs:
        current = dict(_extra.get())
        current.update(kwargs)
        _extra.set(current)


def get_context() -> dict[str, Any]:
    """Return all non-None context variables as a dictionary.

    Returns:
        Dictionary of current context values.
    """
    ctx: dict[str, Any] = {}

    rid = _request_id.get()
    if rid:
        ctx["request_id"] = rid

    uid = _user_id.get()
    if uid:
        ctx["user_id"] = uid

    cid = _correlation_id.get()
    if cid:
        ctx["correlation_id"] = cid

    ctx.update(_extra.get())
    return ctx


def clear_context() -> None:
    """Reset all context variables."""
    _request_id.set(None)
    _user_id.set(None)
    _correlation_id.set(None)
    _extra.set({})


def generate_request_id() -> str:
    """Generate a short unique request ID.

    Returns:
        A string like ``"req-a1b2c3d4"``.
    """
    return f"req-{uuid.uuid4().hex[:8]}"
