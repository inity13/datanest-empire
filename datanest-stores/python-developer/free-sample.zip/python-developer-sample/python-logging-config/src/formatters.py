"""Log formatters — JSON, colored, and key-value.

Usage:
    from src.formatters import JsonFormatter

    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from .context import get_context


class JsonFormatter(logging.Formatter):
    """Structured JSON log formatter for machine consumption.

    Includes timestamp, level, logger name, message, and any ``extra``
    fields. Context variables (request_id, user_id) are automatically
    included when present.

    Args:
        include_stacktrace: Embed exception tracebacks in the JSON.
    """

    def __init__(self, include_stacktrace: bool = True) -> None:
        super().__init__()
        self._include_stacktrace = include_stacktrace

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(
                record.created, tz=timezone.utc
            ).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Inject context variables
        ctx = get_context()
        if ctx:
            payload["context"] = ctx

        # Include extra fields (skip standard LogRecord attributes)
        standard = set(logging.LogRecord("", 0, "", 0, "", (), None).__dict__)
        for key, value in record.__dict__.items():
            if key not in standard and key not in ("message", "msg"):
                payload[key] = value

        # Exception info
        if self._include_stacktrace and record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)

        return json.dumps(payload, default=str)


class ColoredFormatter(logging.Formatter):
    """Colorized console formatter for development.

    Uses ANSI escape codes for level-based coloring.
    """

    COLORS: dict[int, str] = {
        logging.DEBUG: "\033[36m",     # Cyan
        logging.INFO: "\033[32m",      # Green
        logging.WARNING: "\033[33m",   # Yellow
        logging.ERROR: "\033[31m",     # Red
        logging.CRITICAL: "\033[1;31m",  # Bold Red
    }
    RESET = "\033[0m"

    def __init__(self, fmt: str | None = None) -> None:
        super().__init__(
            fmt or "%(asctime)s %(levelname)-8s %(name)s — %(message)s",
            datefmt="%H:%M:%S",
        )

    def format(self, record: logging.LogRecord) -> str:
        color = self.COLORS.get(record.levelno, "")
        record.levelname = f"{color}{record.levelname}{self.RESET}"
        return super().format(record)


class KeyValueFormatter(logging.Formatter):
    """Key=value formatter — easy to parse with grep/awk.

    Output example::

        ts=2026-03-10T12:00:00Z level=INFO logger=app msg="Order placed" order_id=ORD-123
    """

    def format(self, record: logging.LogRecord) -> str:
        ts = datetime.fromtimestamp(
            record.created, tz=timezone.utc
        ).isoformat()

        parts = [
            f"ts={ts}",
            f"level={record.levelname}",
            f"logger={record.name}",
            f'msg="{record.getMessage()}"',
        ]

        # Context
        ctx = get_context()
        for k, v in ctx.items():
            parts.append(f"{k}={v}")

        # Extra fields
        standard = set(logging.LogRecord("", 0, "", 0, "", (), None).__dict__)
        for key, value in record.__dict__.items():
            if key not in standard and key not in ("message", "msg"):
                parts.append(f"{key}={value}")

        return " ".join(parts)
