"""One-call logging configuration.

Usage:
    from src.setup import configure_logging

    configure_logging("dev")   # Colorized console
    configure_logging("prod")  # JSON to file + stdout
    configure_logging("test")  # Minimal output
"""

from __future__ import annotations

import logging
import logging.config
from pathlib import Path
from typing import Any

import yaml

CONFIGS_DIR = Path(__file__).resolve().parent.parent / "configs"

_VALID_ENVS = {"dev", "prod", "test"}


def configure_logging(
    env: str = "dev",
    *,
    config_dir: str | Path | None = None,
    overrides: dict[str, Any] | None = None,
) -> None:
    """Configure the Python logging system from a YAML config file.

    Loads ``logging_{env}.yaml`` from the configs directory and applies
    it via :func:`logging.config.dictConfig`.

    Args:
        env: Environment name — ``"dev"``, ``"prod"``, or ``"test"``.
        config_dir: Override the default configs directory.
        overrides: Dictionary of overrides merged into the loaded config.

    Raises:
        ValueError: If *env* is not recognized.
        FileNotFoundError: If the config file doesn't exist.
    """
    if env not in _VALID_ENVS:
        raise ValueError(
            f"Unknown environment '{env}'. Choose from: {sorted(_VALID_ENVS)}"
        )

    base = Path(config_dir) if config_dir else CONFIGS_DIR
    config_path = base / f"logging_{env}.yaml"

    if not config_path.exists():
        raise FileNotFoundError(f"Logging config not found: {config_path}")

    with open(config_path) as f:
        config = yaml.safe_load(f)

    if overrides:
        _deep_merge(config, overrides)

    logging.config.dictConfig(config)
    logging.getLogger(__name__).debug("Logging configured for env=%s", env)


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> None:
    """Recursively merge *override* into *base* in place."""
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
