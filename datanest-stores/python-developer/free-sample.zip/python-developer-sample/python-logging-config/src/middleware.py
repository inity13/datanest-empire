"""ASGI and WSGI logging middleware.

Automatically sets request context (request_id, method, path) and
logs request start/finish with timing.

Usage (FastAPI/Starlette):
    app.add_middleware(ASGILoggingMiddleware)

Usage (Flask/Django WSGI):
    app.wsgi_app = WSGILoggingMiddleware(app.wsgi_app)
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable

from .context import clear_context, generate_request_id, set_context

logger = logging.getLogger("middleware")


class ASGILoggingMiddleware:
    """ASGI middleware that injects request context into logs.

    For each HTTP request:
    1. Generates or extracts a request_id
    2. Sets context variables
    3. Logs request start and finish with duration

    Args:
        app: The ASGI application.
        header_name: Header to read an existing request ID from.
    """

    def __init__(
        self,
        app: Any,
        header_name: str = "x-request-id",
    ) -> None:
        self.app = app
        self.header_name = header_name.lower().encode()

    async def __call__(
        self, scope: dict[str, Any], receive: Any, send: Any
    ) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        # Extract or generate request ID
        headers = dict(scope.get("headers", []))
        request_id = (
            headers.get(self.header_name, b"").decode() or generate_request_id()
        )

        method = scope.get("method", "WS")
        path = scope.get("path", "/")

        set_context(request_id=request_id)
        logger.info("Request started: %s %s", method, path)

        start = time.monotonic()
        try:
            await self.app(scope, receive, send)
        except Exception:
            logger.exception("Request failed: %s %s", method, path)
            raise
        finally:
            duration_ms = (time.monotonic() - start) * 1000
            logger.info(
                "Request finished: %s %s (%.1fms)",
                method,
                path,
                duration_ms,
            )
            clear_context()


class WSGILoggingMiddleware:
    """WSGI middleware that injects request context into logs.

    Args:
        app: The WSGI application.
        header_name: Environment key for the request ID header.
    """

    def __init__(
        self,
        app: Callable[..., Any],
        header_name: str = "HTTP_X_REQUEST_ID",
    ) -> None:
        self.app = app
        self.header_name = header_name

    def __call__(
        self, environ: dict[str, Any], start_response: Any
    ) -> Any:
        request_id = environ.get(self.header_name) or generate_request_id()
        method = environ.get("REQUEST_METHOD", "?")
        path = environ.get("PATH_INFO", "/")

        set_context(request_id=request_id)
        logger.info("Request started: %s %s", method, path)

        start = time.monotonic()
        try:
            response = self.app(environ, start_response)
        except Exception:
            logger.exception("Request failed: %s %s", method, path)
            raise
        finally:
            duration_ms = (time.monotonic() - start) * 1000
            logger.info(
                "Request finished: %s %s (%.1fms)",
                method,
                path,
                duration_ms,
            )
            clear_context()

        return response
