"""Log filters — rate limiting and logger suppression.

Usage:
    from src.filters import RateLimitFilter, SuppressLoggerFilter

    handler.addFilter(RateLimitFilter(period_seconds=60))
    handler.addFilter(SuppressLoggerFilter(["urllib3", "botocore"]))
"""

from __future__ import annotations

import logging
import time
from typing import Any


class RateLimitFilter(logging.Filter):
    """Suppress duplicate log messages within a time window.

    Groups messages by their format string (``record.msg``) and drops
    duplicates within the configured period.

    Args:
        period_seconds: Minimum seconds between identical messages.
    """

    def __init__(self, period_seconds: float = 60.0) -> None:
        super().__init__()
        self._period = period_seconds
        self._seen: dict[str, float] = {}

    def filter(self, record: logging.LogRecord) -> bool:
        key = f"{record.name}:{record.msg}"
        now = time.monotonic()

        last_seen = self._seen.get(key)
        if last_seen is not None and (now - last_seen) < self._period:
            return False

        self._seen[key] = now
        return True

    def reset(self) -> None:
        """Clear the seen-message cache."""
        self._seen.clear()


class SuppressLoggerFilter(logging.Filter):
    """Drop log records from specified logger names.

    Useful for silencing noisy third-party libraries.

    Args:
        logger_names: Logger name prefixes to suppress.
    """

    def __init__(self, logger_names: list[str]) -> None:
        super().__init__()
        self._prefixes = tuple(logger_names)

    def filter(self, record: logging.LogRecord) -> bool:
        return not record.name.startswith(self._prefixes)


class MinLevelFilter(logging.Filter):
    """Only allow records at or above a minimum level.

    Useful when you want a handler that only processes ERROR+
    while the logger itself is set to DEBUG.

    Args:
        min_level: Minimum logging level (e.g. ``logging.ERROR``).
    """

    def __init__(self, min_level: int = logging.WARNING) -> None:
        super().__init__()
        self._min_level = min_level

    def filter(self, record: logging.LogRecord) -> bool:
        return record.levelno >= self._min_level
