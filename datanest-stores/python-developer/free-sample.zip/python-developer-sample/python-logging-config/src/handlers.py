"""Custom log handlers — rotating file and async queue handler.

Usage:
    from src.handlers import create_rotating_handler, create_async_handler

    file_handler = create_rotating_handler("app.log", max_mb=50, backup_count=5)
    async_handler = create_async_handler(file_handler)
"""

from __future__ import annotations

import atexit
import logging
import logging.handlers
import queue
from pathlib import Path


def create_rotating_handler(
    filename: str | Path,
    *,
    max_mb: float = 50,
    backup_count: int = 5,
    encoding: str = "utf-8",
) -> logging.handlers.RotatingFileHandler:
    """Create a size-based rotating file handler.

    Args:
        filename: Path to the log file.
        max_mb: Maximum file size in megabytes before rotation.
        backup_count: Number of backup files to keep.
        encoding: File encoding.

    Returns:
        Configured :class:`RotatingFileHandler`.
    """
    path = Path(filename)
    path.parent.mkdir(parents=True, exist_ok=True)

    return logging.handlers.RotatingFileHandler(
        filename=str(path),
        maxBytes=int(max_mb * 1024 * 1024),
        backupCount=backup_count,
        encoding=encoding,
    )


def create_timed_handler(
    filename: str | Path,
    *,
    when: str = "midnight",
    interval: int = 1,
    backup_count: int = 30,
    encoding: str = "utf-8",
) -> logging.handlers.TimedRotatingFileHandler:
    """Create a time-based rotating file handler.

    Args:
        filename: Path to the log file.
        when: Rotation interval type (``"midnight"``, ``"h"``, ``"d"``).
        interval: Number of intervals between rotations.
        backup_count: Number of backup files to keep.
        encoding: File encoding.

    Returns:
        Configured :class:`TimedRotatingFileHandler`.
    """
    path = Path(filename)
    path.parent.mkdir(parents=True, exist_ok=True)

    return logging.handlers.TimedRotatingFileHandler(
        filename=str(path),
        when=when,
        interval=interval,
        backupCount=backup_count,
        encoding=encoding,
    )


def create_async_handler(
    target_handler: logging.Handler,
    *,
    queue_size: int = 10_000,
) -> logging.handlers.QueueHandler:
    """Wrap a handler in an async queue for non-blocking logging.

    The listener is started immediately and registered for cleanup
    at interpreter exit via :func:`atexit`.

    Args:
        target_handler: The handler that will process log records.
        queue_size: Maximum queue depth (0 = unlimited).

    Returns:
        A :class:`QueueHandler` that feeds the listener.
    """
    log_queue: queue.Queue[logging.LogRecord] = queue.Queue(maxsize=queue_size)
    queue_handler = logging.handlers.QueueHandler(log_queue)

    listener = logging.handlers.QueueListener(
        log_queue, target_handler, respect_handler_level=True
    )
    listener.start()
    atexit.register(listener.stop)

    return queue_handler
