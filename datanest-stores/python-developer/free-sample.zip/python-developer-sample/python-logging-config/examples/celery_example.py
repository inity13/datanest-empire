"""Celery task logging example.

Shows how to configure structured logging for Celery workers
with task_id context propagation.

Run:
    pip install celery pyyaml
    celery -A examples.celery_example worker --loglevel=info
"""

from __future__ import annotations

import logging

from src.context import set_context
from src.setup import configure_logging

configure_logging("prod")

logger = logging.getLogger(__name__)

try:
    from celery import Celery
    from celery.signals import task_postrun, task_prerun

    app = Celery("demo", broker="redis://localhost:6379/0")

    @task_prerun.connect
    def on_task_prerun(
        sender: object = None, task_id: str = "", **kwargs: object
    ) -> None:
        """Inject task_id into logging context before each task."""
        set_context(request_id=task_id)
        logger.info("Task starting: %s", sender)

    @task_postrun.connect
    def on_task_postrun(
        sender: object = None, task_id: str = "", **kwargs: object
    ) -> None:
        """Log task completion."""
        logger.info("Task finished: %s", sender)

    @app.task(name="process_order")
    def process_order(order_id: str) -> dict[str, str]:
        """Example task that processes an order."""
        logger.info("Processing order %s", order_id)
        # ... business logic ...
        logger.info("Order %s processed successfully", order_id)
        return {"order_id": order_id, "status": "processed"}

    @app.task(name="send_notification")
    def send_notification(user_id: str, message: str) -> dict[str, str]:
        """Example task that sends a notification."""
        set_context(user_id=user_id)
        logger.info("Sending notification to user %s", user_id)
        return {"user_id": user_id, "status": "sent"}

except ImportError:
    app = None  # type: ignore[assignment]
    logger.info("Celery not installed. Install with: pip install celery")
