"""FastAPI integration example.

Run:
    pip install fastapi uvicorn pyyaml
    uvicorn examples.fastapi_example:app --reload

Every request gets a unique request_id in all log output.
"""

from __future__ import annotations

import logging

from src.context import get_context, set_context
from src.middleware import ASGILoggingMiddleware
from src.setup import configure_logging

# Configure structured JSON logging
configure_logging("prod")

logger = logging.getLogger(__name__)

# --- FastAPI app (import only if FastAPI is installed) ---
try:
    from fastapi import FastAPI, Request

    app = FastAPI(title="Logging Demo")
    app.add_middleware(ASGILoggingMiddleware)

    @app.get("/")
    async def root() -> dict[str, str]:
        logger.info("Handling root request")
        ctx = get_context()
        return {"message": "Hello", "request_id": ctx.get("request_id", "")}

    @app.get("/users/{user_id}")
    async def get_user(user_id: int) -> dict[str, object]:
        set_context(user_id=str(user_id))
        logger.info("Fetching user %d", user_id)
        return {"user_id": user_id, "name": "Alice"}

    @app.get("/error")
    async def trigger_error() -> None:
        logger.warning("About to raise an error")
        raise ValueError("Intentional error for demo")

except ImportError:
    # FastAPI not installed — provide a stub for import
    app = None  # type: ignore[assignment]
    logger.info("FastAPI not installed. Install with: pip install fastapi uvicorn")
