"""Tests for the logging configuration toolkit."""

from __future__ import annotations

import json
import logging
from pathlib import Path

import pytest


# ─── Context ─────────────────────────────────────────────────

class TestContext:
    def test_set_and_get(self) -> None:
        from src.context import clear_context, get_context, set_context

        clear_context()
        set_context(request_id="req-123", user_id="usr-42")
        ctx = get_context()
        assert ctx["request_id"] == "req-123"
        assert ctx["user_id"] == "usr-42"
        clear_context()

    def test_clear_context(self) -> None:
        from src.context import clear_context, get_context, set_context

        set_context(request_id="req-abc")
        clear_context()
        assert get_context() == {}

    def test_generate_request_id(self) -> None:
        from src.context import generate_request_id

        rid = generate_request_id()
        assert rid.startswith("req-")
        assert len(rid) == 12  # "req-" + 8 hex chars

    def test_extra_kwargs(self) -> None:
        from src.context import clear_context, get_context, set_context

        clear_context()
        set_context(tenant="acme", region="eu")
        ctx = get_context()
        assert ctx["tenant"] == "acme"
        assert ctx["region"] == "eu"
        clear_context()


# ─── Formatters ──────────────────────────────────────────────

class TestJsonFormatter:
    def test_basic_format(self) -> None:
        from src.formatters import JsonFormatter

        formatter = JsonFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="Hello %s",
            args=("World",),
            exc_info=None,
        )
        output = formatter.format(record)
        data = json.loads(output)
        assert data["level"] == "INFO"
        assert data["message"] == "Hello World"
        assert "timestamp" in data

    def test_includes_context(self) -> None:
        from src.context import clear_context, set_context
        from src.formatters import JsonFormatter

        clear_context()
        set_context(request_id="req-test")

        formatter = JsonFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="test",
            args=(),
            exc_info=None,
        )
        output = formatter.format(record)
        data = json.loads(output)
        assert data["context"]["request_id"] == "req-test"
        clear_context()


class TestColoredFormatter:
    def test_format_contains_message(self) -> None:
        from src.formatters import ColoredFormatter

        formatter = ColoredFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.WARNING,
            pathname="",
            lineno=0,
            msg="Watch out",
            args=(),
            exc_info=None,
        )
        output = formatter.format(record)
        assert "Watch out" in output


class TestKeyValueFormatter:
    def test_format(self) -> None:
        from src.formatters import KeyValueFormatter

        formatter = KeyValueFormatter()
        record = logging.LogRecord(
            name="app",
            level=logging.ERROR,
            pathname="",
            lineno=0,
            msg="Disk full",
            args=(),
            exc_info=None,
        )
        output = formatter.format(record)
        assert "level=ERROR" in output
        assert 'msg="Disk full"' in output


# ─── Filters ────────────────────────────────────────────────

class TestRateLimitFilter:
    def test_suppresses_duplicates(self) -> None:
        from src.filters import RateLimitFilter

        f = RateLimitFilter(period_seconds=60)
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="same message",
            args=(),
            exc_info=None,
        )
        assert f.filter(record) is True
        assert f.filter(record) is False  # suppressed

    def test_allows_different_messages(self) -> None:
        from src.filters import RateLimitFilter

        f = RateLimitFilter(period_seconds=60)
        r1 = logging.LogRecord("a", logging.INFO, "", 0, "msg1", (), None)
        r2 = logging.LogRecord("a", logging.INFO, "", 0, "msg2", (), None)
        assert f.filter(r1) is True
        assert f.filter(r2) is True


class TestSuppressLoggerFilter:
    def test_suppresses_named_loggers(self) -> None:
        from src.filters import SuppressLoggerFilter

        f = SuppressLoggerFilter(["urllib3", "botocore"])
        r1 = logging.LogRecord("urllib3.connection", logging.INFO, "", 0, "", (), None)
        r2 = logging.LogRecord("myapp", logging.INFO, "", 0, "", (), None)
        assert f.filter(r1) is False
        assert f.filter(r2) is True


# ─── Handlers ────────────────────────────────────────────────

class TestHandlers:
    def test_rotating_handler(self, tmp_path: Path) -> None:
        from src.handlers import create_rotating_handler

        handler = create_rotating_handler(tmp_path / "test.log", max_mb=1)
        assert handler.maxBytes == 1 * 1024 * 1024
        handler.close()

    def test_timed_handler(self, tmp_path: Path) -> None:
        from src.handlers import create_timed_handler

        handler = create_timed_handler(tmp_path / "test.log")
        assert handler.when == "MIDNIGHT"
        handler.close()


# ─── Setup ───────────────────────────────────────────────────

class TestSetup:
    def test_invalid_env_raises(self) -> None:
        from src.setup import configure_logging

        with pytest.raises(ValueError, match="Unknown environment"):
            configure_logging("staging")

    def test_missing_config_raises(self) -> None:
        from src.setup import configure_logging

        with pytest.raises(FileNotFoundError):
            configure_logging("dev", config_dir="/nonexistent")
