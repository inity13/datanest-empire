"""Core module demonstrating proper Python module structure.

This module serves as a template — replace these functions with your
actual library logic while preserving the structural patterns.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def greet(name: str) -> str:
    """Return a greeting message.

    Args:
        name: The name to greet.

    Returns:
        A formatted greeting string.
    """
    return f"Hello, {name}!"


def process_data(data: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Process a list of records, filtering out invalid entries.

    Args:
        data: List of dictionaries representing data records.

    Returns:
        Filtered and validated records.
    """
    results: list[dict[str, Any]] = []
    for record in data:
        if not isinstance(record, dict):
            logger.warning("Skipping non-dict record: %r", record)
            continue
        if "id" not in record:
            logger.warning("Skipping record without 'id': %r", record)
            continue
        results.append(record)
    logger.info("Processed %d/%d records", len(results), len(data))
    return results


def main() -> None:
    """CLI entry point for the example package."""
    print(greet("World"))
