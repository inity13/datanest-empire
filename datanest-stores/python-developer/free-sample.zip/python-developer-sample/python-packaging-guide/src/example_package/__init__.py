"""Example Package — a template for well-structured Python libraries.

This package demonstrates proper packaging conventions including version
management, public API exports, and PEP 561 type stub support.
"""

from __future__ import annotations

from example_package.core import greet, process_data

__version__ = "1.0.0"
__author__ = "Your Name"
__all__ = ["greet", "process_data", "__version__"]
