#!/usr/bin/env bash
# publish.sh — Build and upload package to PyPI or TestPyPI.
#
# Usage:
#   bash scripts/publish.sh          # Publish to PyPI
#   bash scripts/publish.sh --test   # Publish to TestPyPI
#
set -euo pipefail

REPO="pypi"
TWINE_ARGS=()

if [[ "${1:-}" == "--test" ]]; then
    REPO="testpypi"
    TWINE_ARGS+=(--repository testpypi)
    echo "==> Publishing to TestPyPI"
else
    echo "==> Publishing to PyPI"
fi

# Ensure build tools are available
echo "==> Checking build dependencies..."
python3 -m pip install --quiet --upgrade build twine

# Clean previous builds
echo "==> Cleaning old builds..."
rm -rf dist/ build/ *.egg-info src/*.egg-info

# Build sdist and wheel
echo "==> Building sdist and wheel..."
python3 -m build

# Validate distribution files
echo "==> Validating distributions..."
python3 -m twine check dist/*

# Show what will be uploaded
echo ""
echo "==> Distributions to upload:"
ls -lh dist/
echo ""

# Confirm before uploading to production PyPI
if [[ "$REPO" == "pypi" ]]; then
    read -rp "Upload to PyPI? (y/N): " confirm
    if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
        echo "Aborted."
        exit 0
    fi
fi

# Upload
echo "==> Uploading to ${REPO}..."
python3 -m twine upload "${TWINE_ARGS[@]}" dist/*

echo "==> Done! Package published to ${REPO}."
