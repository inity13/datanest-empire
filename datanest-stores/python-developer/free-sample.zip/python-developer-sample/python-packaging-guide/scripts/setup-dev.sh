#!/usr/bin/env bash
# setup-dev.sh — Create a virtual environment and install in editable mode.
#
# Usage: bash scripts/setup-dev.sh
#
set -euo pipefail

VENV_DIR=".venv"

echo "==> Creating virtual environment in ${VENV_DIR}/..."
python3 -m venv "$VENV_DIR"

echo "==> Activating venv and upgrading pip..."
source "${VENV_DIR}/bin/activate"
pip install --quiet --upgrade pip setuptools wheel

echo "==> Installing package in editable mode with dev dependencies..."
pip install -e ".[dev]"

echo "==> Installing pre-commit hooks..."
pre-commit install

echo ""
echo "Done! Activate your environment with:"
echo "  source ${VENV_DIR}/bin/activate"
