# Python Packaging Guide

**Ship your Python library to PyPI with confidence.**

Production-ready templates, configs, and scripts for modern Python packaging — from `pyproject.toml` to automated publishing.

---

## What You Get

- Complete **pyproject.toml** template with setuptools, optional deps, and tool configs
- **setup.cfg** for backwards compatibility with older build systems
- **MANIFEST.in** with correct include/exclude patterns for sdist
- **Makefile** with common dev targets (install, test, lint, build, publish)
- Example package source with **PEP 561 type stub marker**
- **publish.sh** script for building and uploading to PyPI / TestPyPI
- **setup-dev.sh** for bootstrapping dev environments
- Linter/formatter configs for **Ruff**, **mypy**, and **pre-commit**
- Comprehensive packaging guide covering versioning, wheels, namespaces, and CI

## File Tree

```
python-packaging-guide/
├── README.md
├── LICENSE
├── manifest.json
├── templates/
│   ├── pyproject.toml          # Modern project metadata & build config
│   ├── setup.cfg               # Backwards-compatible setup config
│   ├── MANIFEST.in             # Source distribution includes/excludes
│   └── Makefile                # Dev workflow targets
├── src/
│   └── example_package/
│       ├── __init__.py         # Version & public API exports
│       ├── core.py             # Example module with proper structure
│       └── py.typed            # PEP 561 marker
├── scripts/
│   ├── publish.sh              # Build + upload to PyPI
│   └── setup-dev.sh            # Bootstrap dev environment
├── configs/
│   ├── ruff.toml               # Ruff linter/formatter config
│   ├── .pre-commit-config.yaml # Pre-commit hook definitions
│   └── mypy.ini                # Strict mypy config
└── guides/
    └── python-packaging-guide.md
```

## Getting Started

### 1. Copy the template into your project

```bash
cp templates/pyproject.toml my-project/pyproject.toml
```

### 2. Customize project metadata

```toml
[project]
name = "my-awesome-lib"
version = "0.1.0"
description = "A short description of your library"
authors = [{name = "Your Name", email = "you@example.com"}]
```

### 3. Set up your dev environment

```bash
bash scripts/setup-dev.sh
```

### 4. Build and publish

```bash
# Dry run to TestPyPI first
bash scripts/publish.sh --test

# Publish to production PyPI
bash scripts/publish.sh
```

### 5. Use the Makefile for daily workflow

```bash
make install   # Install in editable mode with dev deps
make lint      # Run ruff + mypy
make test      # Run pytest
make build     # Build sdist + wheel
make publish   # Upload to PyPI
```

## Requirements

- Python 3.9+
- pip 21.3+ (for PEP 660 editable installs)
- build (`pip install build`)
- twine (`pip install twine`)

## Architecture

```
┌─────────────────────────────────────────────────┐
│                 Developer Workflow               │
├─────────────┬───────────────┬───────────────────┤
│  Makefile   │  scripts/     │  configs/         │
│  (targets)  │  (automation) │  (lint/type/hook) │
├─────────────┴───────────────┴───────────────────┤
│              pyproject.toml                      │
│  (metadata, deps, build system, tool configs)    │
├─────────────────────────────────────────────────┤
│              src/ layout                         │
│  (PEP 621 source tree with py.typed marker)     │
├─────────────────────────────────────────────────┤
│    build → sdist + wheel → twine → PyPI         │
└─────────────────────────────────────────────────┘
```

## Key Concepts

| Concept | File | Purpose |
|---------|------|---------|
| Build metadata | `pyproject.toml` | Single source of truth for project config |
| Backwards compat | `setup.cfg` | Support older pip/setuptools |
| Source dist | `MANIFEST.in` | Control what goes into `sdist` tarballs |
| Type checking | `py.typed` | PEP 561 marker for downstream type checkers |
| CI/CD publish | `publish.sh` | Automated build + upload with validation |

## License

MIT License - Copyright (c) 2026 Datanest Digital

By [Datanest Digital](https://datanest.dev) | Version 1.0.0 | $19
