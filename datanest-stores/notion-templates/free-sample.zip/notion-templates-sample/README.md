# Notion Developer Pro — Free Sample Pack

Thank you for downloading the free sample pack!

## What's Included

- **Learning Roadmap System** — Track courses, books, certifications, and skills. Includes progress bars, spaced repetition reminders, and goal mileston...
- **Sprint Planning Dashboard** — Agile sprint planning system with backlog management, velocity tracking, burndown charts, and standup note templates....

## Get the Full Collection

This sample includes a preview of what's available in Notion Developer Pro.
The full store has 11 products covering Notion templates and systems built specifically for software engineers.

Visit: https://inity13.github.io/notion-developer-pro/

Use code **COMMUNITY** for 15% off your first purchase.
Students/bootcamp grads: use code **STUDENT** for 50% off.

## Contact

Questions? Reach out at megafolder122122@hotmail.com
