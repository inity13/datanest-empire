# Docker Compose Templates

**Production-ready Docker Compose stacks for web apps, monitoring, logging, databases, and CI runners.**

Drop-in Compose files for the most common self-hosted infrastructure. Each stack is tested, commented, and ready to deploy with a single `docker compose up -d`. Includes a Traefik reverse proxy with automatic TLS and a stack manager script.

---

## What You Get

- **7 ready-to-deploy stacks** — Web app, monitoring, ELK, CI runner, database, WordPress, Traefik
- **Shared reverse proxy** — Traefik with automatic Let's Encrypt certificates
- **Stack manager script** — Deploy, stop, restart, and check status of any stack
- **Environment template** — Documented `.env.example` with all configurable variables
- **Patterns guide** — Networking, volumes, health checks, secrets, and multi-service patterns

## File Tree

```
docker-compose-templates/
├── README.md
├── manifest.json
├── LICENSE
├── stacks/
│   ├── web-app/docker-compose.yml       # Nginx + Node.js + PostgreSQL + Redis
│   ├── monitoring/docker-compose.yml    # Prometheus + Grafana + AlertManager
│   ├── elk/docker-compose.yml           # Elasticsearch + Logstash + Kibana
│   ├── ci-runner/docker-compose.yml     # GitLab Runner with Docker executor
│   ├── database/docker-compose.yml      # PostgreSQL + pgAdmin + pgBouncer
│   └── wordpress/docker-compose.yml     # WordPress + MariaDB + Redis + Nginx
├── shared/
│   ├── traefik/docker-compose.yml       # Traefik v3 reverse proxy + Let's Encrypt
│   └── .env.example                     # Template environment variables
├── scripts/
│   └── stack-manager.sh                 # Deploy/stop/restart any stack
└── guides/
    └── docker-compose-patterns.md       # Networking, volumes, health checks
```

## Getting Started

### 1. Configure Environment

```bash
cp shared/.env.example .env
# Edit .env with your domain, email, passwords, etc.
```

### 2. Start the Reverse Proxy

```bash
docker compose -f shared/traefik/docker-compose.yml up -d
```

### 3. Deploy a Stack

```bash
# Using the stack manager
./scripts/stack-manager.sh deploy web-app

# Or directly with Docker Compose
docker compose -f stacks/web-app/docker-compose.yml up -d
```

### 4. Check Status

```bash
./scripts/stack-manager.sh status
# Shows running containers for all stacks
```

## Architecture

```
                        Internet
                           │
                    ┌──────▼──────┐
                    │   Traefik   │  :80 / :443
                    │  (reverse   │  Let's Encrypt
                    │   proxy)    │  auto-TLS
                    └──┬───┬───┬──┘
           ┌───────────┘   │   └───────────┐
    ┌──────▼──────┐ ┌──────▼──────┐ ┌──────▼──────┐
    │   Web App   │ │  Grafana    │ │   Kibana    │
    │  Nginx+Node │ │  :3000      │ │   :5601     │
    │  +PG+Redis  │ │  Prometheus │ │   ELK Stack │
    └─────────────┘ └─────────────┘ └─────────────┘
```

## Requirements

| Tool           | Version |
|----------------|---------|
| Docker         | >= 24.0 |
| Docker Compose | >= 2.20 |
| Bash           | >= 4.0  |

## Stack Reference

| Stack        | Services                              | Ports         |
|--------------|---------------------------------------|---------------|
| `web-app`    | Nginx, Node.js, PostgreSQL, Redis     | 80, 443       |
| `monitoring` | Prometheus, Grafana, AlertManager     | 3000, 9090    |
| `elk`        | Elasticsearch, Logstash, Kibana       | 5601, 9200    |
| `ci-runner`  | GitLab Runner, Docker-in-Docker       | --            |
| `database`   | PostgreSQL, pgAdmin, pgBouncer        | 5432, 8080    |
| `wordpress`  | WordPress, MariaDB, Redis, Nginx      | 80, 443       |
| `traefik`    | Traefik v3 reverse proxy              | 80, 443, 8080 |

---

## License & Support

MIT License -- (c) 2026 Datanest Digital (datanest.dev)

For questions and support, visit [datanest.dev/support](https://datanest.dev/support).
