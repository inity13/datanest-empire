#!/usr/bin/env bash
# =============================================================================
# Stack Manager — deploy, stop, restart, and inspect Docker Compose stacks
# =============================================================================
#
# Usage:
#   ./scripts/stack-manager.sh <command> [stack]
#
# Commands:
#   deploy <stack|all>   Start a stack (or every stack) in detached mode
#   stop   <stack|all>   Stop a running stack
#   restart <stack>      Restart a single stack
#   status               Show running containers across all stacks
#   logs   <stack>       Tail logs for a stack (Ctrl-C to quit)
#   pull   <stack|all>   Pull latest images without restarting
#   ps                   Alias for status
#
# Examples:
#   ./scripts/stack-manager.sh deploy web-app
#   ./scripts/stack-manager.sh deploy all
#   ./scripts/stack-manager.sh status
#   ./scripts/stack-manager.sh logs monitoring
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Paths — resolve relative to this script so it works from any working dir
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
STACKS_DIR="$PROJECT_ROOT/stacks"
SHARED_DIR="$PROJECT_ROOT/shared"

# All available stack names (subdirectories of stacks/)
AVAILABLE_STACKS=()
for dir in "$STACKS_DIR"/*/; do
  [ -d "$dir" ] && AVAILABLE_STACKS+=("$(basename "$dir")")
done

# Colors for terminal output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
info()    { echo -e "${CYAN}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[OK]${NC}   $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERR]${NC}  $*" >&2; }

usage() {
  echo "Usage: $(basename "$0") <command> [stack]"
  echo ""
  echo "Commands:"
  echo "  deploy <stack|all>   Start a stack in detached mode"
  echo "  stop   <stack|all>   Stop a running stack"
  echo "  restart <stack>      Restart a stack"
  echo "  status               Show running containers"
  echo "  logs   <stack>       Tail stack logs"
  echo "  pull   <stack|all>   Pull latest images"
  echo "  ps                   Alias for status"
  echo ""
  echo "Available stacks: ${AVAILABLE_STACKS[*]}"
  exit 1
}

# Resolve the compose file for a given stack name
compose_file() {
  local stack="$1"
  local file="$STACKS_DIR/$stack/docker-compose.yml"
  if [[ ! -f "$file" ]]; then
    error "Compose file not found: $file"
    exit 1
  fi
  echo "$file"
}

# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

cmd_deploy() {
  local target="${1:-}"
  [[ -z "$target" ]] && { error "Specify a stack name or 'all'"; usage; }

  if [[ "$target" == "all" ]]; then
    # Start Traefik first (shared reverse proxy)
    if [[ -f "$SHARED_DIR/traefik/docker-compose.yml" ]]; then
      info "Starting Traefik reverse proxy..."
      docker compose -f "$SHARED_DIR/traefik/docker-compose.yml" up -d
      success "Traefik is running"
    fi
    # Then start every stack
    for stack in "${AVAILABLE_STACKS[@]}"; do
      info "Deploying $stack..."
      docker compose -f "$(compose_file "$stack")" up -d
      success "$stack deployed"
    done
  else
    info "Deploying $target..."
    docker compose -f "$(compose_file "$target")" up -d
    success "$target deployed"
  fi
}

cmd_stop() {
  local target="${1:-}"
  [[ -z "$target" ]] && { error "Specify a stack name or 'all'"; usage; }

  if [[ "$target" == "all" ]]; then
    for stack in "${AVAILABLE_STACKS[@]}"; do
      info "Stopping $stack..."
      docker compose -f "$(compose_file "$stack")" down
      success "$stack stopped"
    done
    # Stop Traefik last
    if [[ -f "$SHARED_DIR/traefik/docker-compose.yml" ]]; then
      info "Stopping Traefik..."
      docker compose -f "$SHARED_DIR/traefik/docker-compose.yml" down
      success "Traefik stopped"
    fi
  else
    info "Stopping $target..."
    docker compose -f "$(compose_file "$target")" down
    success "$target stopped"
  fi
}

cmd_restart() {
  local target="${1:-}"
  [[ -z "$target" ]] && { error "Specify a stack name"; usage; }
  info "Restarting $target..."
  docker compose -f "$(compose_file "$target")" down
  docker compose -f "$(compose_file "$target")" up -d
  success "$target restarted"
}

cmd_status() {
  echo ""
  info "=== Stack Status ==="
  echo ""

  # Traefik
  if [[ -f "$SHARED_DIR/traefik/docker-compose.yml" ]]; then
    echo -e "${CYAN}traefik (shared):${NC}"
    docker compose -f "$SHARED_DIR/traefik/docker-compose.yml" ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null || echo "  (not running)"
    echo ""
  fi

  # Each stack
  for stack in "${AVAILABLE_STACKS[@]}"; do
    local file
    file="$(compose_file "$stack")" 2>/dev/null || continue
    echo -e "${CYAN}${stack}:${NC}"
    docker compose -f "$file" ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null || echo "  (not running)"
    echo ""
  done
}

cmd_logs() {
  local target="${1:-}"
  [[ -z "$target" ]] && { error "Specify a stack name"; usage; }
  info "Tailing logs for $target (Ctrl-C to stop)..."
  docker compose -f "$(compose_file "$target")" logs -f --tail 100
}

cmd_pull() {
  local target="${1:-}"
  [[ -z "$target" ]] && { error "Specify a stack name or 'all'"; usage; }

  if [[ "$target" == "all" ]]; then
    for stack in "${AVAILABLE_STACKS[@]}"; do
      info "Pulling images for $stack..."
      docker compose -f "$(compose_file "$stack")" pull
      success "$stack images updated"
    done
  else
    info "Pulling images for $target..."
    docker compose -f "$(compose_file "$target")" pull
    success "$target images updated"
  fi
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
COMMAND="${1:-}"
shift || true

case "$COMMAND" in
  deploy)  cmd_deploy "$@" ;;
  stop)    cmd_stop "$@" ;;
  restart) cmd_restart "$@" ;;
  status)  cmd_status ;;
  ps)      cmd_status ;;
  logs)    cmd_logs "$@" ;;
  pull)    cmd_pull "$@" ;;
  *)       usage ;;
esac
