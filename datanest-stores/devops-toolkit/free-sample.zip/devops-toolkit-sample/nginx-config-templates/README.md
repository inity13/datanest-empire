# Nginx Config Templates

**Production-ready Nginx configurations for every use case.**

> Stop copy-pasting from StackOverflow. Ship secure, optimized Nginx configs in minutes.

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Nginx](https://img.shields.io/badge/Nginx-1.24+-green.svg)](https://nginx.org/)
[![Price](https://img.shields.io/badge/Price-$19-orange.svg)](https://datanest.dev)

---

## What You Get

- **Main Nginx config** with security hardening, gzip compression, and structured logging
- **5 site configurations**: reverse proxy, static site, SPA, WordPress, API gateway
- **4 reusable snippets**: SSL/TLS, security headers, rate limiting, caching
- **Automation scripts**: Let's Encrypt setup, config testing
- **Performance tuning guide** with real-world recommendations

## File Tree

```
nginx-config-templates/
├── README.md
├── manifest.json
├── LICENSE
├── configs/
│   ├── nginx.conf                    # Main config: workers, events, http block
│   ├── sites/
│   │   ├── reverse-proxy.conf        # Reverse proxy + WebSocket + caching
│   │   ├── static-site.conf          # Static files + Brotli + cache headers
│   │   ├── spa-app.conf              # SPA + try_files + API proxy + CORS
│   │   ├── wordpress.conf            # WordPress + PHP-FPM + security
│   │   └── api-gateway.conf          # Load balancing + circuit breaker
│   └── snippets/
│       ├── ssl-params.conf           # Modern TLS + HSTS + OCSP
│       ├── security-headers.conf     # CSP + X-Frame + XSS protection
│       ├── rate-limiting.conf        # Rate limit zones and rules
│       └── caching.conf              # Proxy cache paths and zones
├── scripts/
│   ├── certbot-setup.sh              # Let's Encrypt automation
│   └── nginx-test.sh                 # Config test + reload
└── guides/
    └── nginx-performance-tuning.md   # Worker tuning, buffers, keepalive
```

## Getting Started

### 1. Copy the main config

```bash
# Back up your existing config
sudo cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak

# Install the new main config
sudo cp configs/nginx.conf /etc/nginx/nginx.conf
```

### 2. Add a site config

```bash
# Example: Set up a reverse proxy
sudo cp configs/sites/reverse-proxy.conf /etc/nginx/sites-available/myapp.conf

# Edit the server_name and proxy_pass values
sudo nano /etc/nginx/sites-available/myapp.conf

# Enable the site
sudo ln -s /etc/nginx/sites-available/myapp.conf /etc/nginx/sites-enabled/
```

### 3. Include snippets

```nginx
server {
    listen 443 ssl http2;
    server_name example.com;

    ssl_certificate     /etc/letsencrypt/live/example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/example.com/privkey.pem;

    include snippets/ssl-params.conf;
    include snippets/security-headers.conf;
    include snippets/rate-limiting.conf;
}
```

### 4. Test and reload

```bash
# Test config syntax
./scripts/nginx-test.sh

# Or set up SSL first
sudo ./scripts/certbot-setup.sh example.com
```

## Architecture

```
                    ┌─────────────────────┐
                    │   nginx.conf        │
                    │   (main config)     │
                    └─────────┬───────────┘
                              │
              ┌───────────────┼───────────────┐
              │               │               │
     ┌────────▼──────┐ ┌─────▼──────┐ ┌──────▼───────┐
     │  sites/*.conf │ │ snippets/  │ │  upstream {} │
     │  (vhosts)     │ │ (includes) │ │  (backends)  │
     └───────┬───────┘ └─────┬──────┘ └──────┬───────┘
             │               │               │
             └───────────────┼───────────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
        ┌─────▼────┐  ┌─────▼────┐  ┌─────▼────┐
        │  Static  │  │  Proxy   │  │  Cache   │
        │  Files   │  │  Pass    │  │  Layer   │
        └──────────┘  └──────────┘  └──────────┘
```

## Requirements

- **Nginx** 1.24+ (mainline recommended)
- **OpenSSL** 1.1.1+ (for TLS 1.3 support)
- **Certbot** (for Let's Encrypt automation)
- **Ubuntu 22.04+** / **Debian 12+** / **RHEL 9+** (any Linux with systemd)

## Customization

Each config file includes inline comments explaining every directive. Key values to customize:

| Directive | Location | Purpose |
|-----------|----------|---------|
| `worker_processes` | nginx.conf | Match to CPU cores |
| `server_name` | sites/*.conf | Your domain(s) |
| `proxy_pass` | sites/*.conf | Backend address |
| `ssl_certificate` | sites/*.conf | Cert path |
| `limit_req_zone` | snippets/rate-limiting.conf | Rate limit thresholds |

---

**Datanest Digital** | [datanest.dev](https://datanest.dev) | MIT License

Questions? Email support@datanest.dev
