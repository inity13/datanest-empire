#!/usr/bin/env bash
# =============================================================================
# Let's Encrypt Certificate Setup with Certbot
# Datanest Digital — nginx-config-templates v1.0.0
# =============================================================================
# Automates SSL certificate issuance and auto-renewal using Certbot.
#
# Usage:
#   sudo ./certbot-setup.sh example.com
#   sudo ./certbot-setup.sh example.com www.example.com api.example.com
# =============================================================================

set -euo pipefail

# --- Color output ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
log_error() { echo -e "${RED}[ERROR]${NC} $*"; }

# --- Validate arguments ---
if [[ $# -lt 1 ]]; then
    echo "Usage: $0 <domain> [additional domains...]"
    echo "Example: $0 example.com www.example.com"
    exit 1
fi

PRIMARY_DOMAIN="$1"
shift
ADDITIONAL_DOMAINS=("$@")

# --- Check root ---
if [[ $EUID -ne 0 ]]; then
    log_error "This script must be run as root (or with sudo)"
    exit 1
fi

# --- Install certbot if not present ---
if ! command -v certbot &>/dev/null; then
    log_info "Installing Certbot..."
    if command -v apt-get &>/dev/null; then
        apt-get update -qq
        apt-get install -y -qq certbot python3-certbot-nginx
    elif command -v dnf &>/dev/null; then
        dnf install -y -q certbot python3-certbot-nginx
    elif command -v yum &>/dev/null; then
        yum install -y -q certbot python3-certbot-nginx
    else
        log_error "Cannot detect package manager. Install certbot manually."
        exit 1
    fi
    log_info "Certbot installed successfully."
fi

# --- Create webroot directory ---
WEBROOT="/var/www/certbot"
mkdir -p "$WEBROOT"

# --- Build domain arguments ---
DOMAIN_ARGS="-d ${PRIMARY_DOMAIN}"
for domain in "${ADDITIONAL_DOMAINS[@]}"; do
    DOMAIN_ARGS+=" -d ${domain}"
done

# --- Generate DH parameters if not present ---
DH_PARAM="/etc/nginx/ssl/dhparam.pem"
if [[ ! -f "$DH_PARAM" ]]; then
    log_info "Generating DH parameters (this may take a few minutes)..."
    mkdir -p /etc/nginx/ssl
    openssl dhparam -out "$DH_PARAM" 2048
    log_info "DH parameters generated at $DH_PARAM"
fi

# --- Request certificate ---
log_info "Requesting certificate for: ${PRIMARY_DOMAIN} ${ADDITIONAL_DOMAINS[*]:-}"

# Try nginx plugin first, fall back to webroot
if nginx -t &>/dev/null; then
    log_info "Using Nginx plugin for certificate issuance..."
    certbot certonly \
        --nginx \
        ${DOMAIN_ARGS} \
        --non-interactive \
        --agree-tos \
        --email "admin@${PRIMARY_DOMAIN}" \
        --redirect \
        --staple-ocsp
else
    log_warn "Nginx config has errors. Using standalone mode..."
    certbot certonly \
        --standalone \
        ${DOMAIN_ARGS} \
        --non-interactive \
        --agree-tos \
        --email "admin@${PRIMARY_DOMAIN}"
fi

# --- Set up auto-renewal ---
log_info "Setting up auto-renewal..."

# Create renewal hook to reload Nginx after renewal
RENEWAL_HOOK="/etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh"
mkdir -p "$(dirname "$RENEWAL_HOOK")"
cat > "$RENEWAL_HOOK" << 'HOOK'
#!/bin/bash
# Reload Nginx after certificate renewal
nginx -t && systemctl reload nginx
HOOK
chmod +x "$RENEWAL_HOOK"

# Enable certbot timer (systemd)
if systemctl list-unit-files | grep -q certbot.timer; then
    systemctl enable --now certbot.timer
    log_info "Certbot auto-renewal timer enabled."
else
    # Fall back to cron
    CRON_LINE="0 3 * * * certbot renew --quiet --deploy-hook 'nginx -t && systemctl reload nginx'"
    if ! crontab -l 2>/dev/null | grep -q "certbot renew"; then
        (crontab -l 2>/dev/null; echo "$CRON_LINE") | crontab -
        log_info "Certbot renewal cron job added."
    fi
fi

# --- Test renewal ---
log_info "Testing renewal process..."
certbot renew --dry-run

# --- Summary ---
echo ""
log_info "=== Certificate Setup Complete ==="
log_info "Domain:      ${PRIMARY_DOMAIN}"
log_info "Cert path:   /etc/letsencrypt/live/${PRIMARY_DOMAIN}/fullchain.pem"
log_info "Key path:    /etc/letsencrypt/live/${PRIMARY_DOMAIN}/privkey.pem"
log_info "Auto-renewal: Enabled"
echo ""
log_info "Add these lines to your Nginx server block:"
echo "    ssl_certificate     /etc/letsencrypt/live/${PRIMARY_DOMAIN}/fullchain.pem;"
echo "    ssl_certificate_key /etc/letsencrypt/live/${PRIMARY_DOMAIN}/privkey.pem;"
