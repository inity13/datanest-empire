#!/usr/bin/env bash
# =============================================================================
# Nginx Config Test & Reload
# Datanest Digital — nginx-config-templates v1.0.0
# =============================================================================
# Tests Nginx configuration syntax and reloads if valid.
# Safe to run in production — will NOT reload if config has errors.
#
# Usage:
#   sudo ./nginx-test.sh          # Test and reload
#   sudo ./nginx-test.sh --test   # Test only (no reload)
# =============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
log_error() { echo -e "${RED}[ERROR]${NC} $*"; }
log_step()  { echo -e "${CYAN}[STEP]${NC} $*"; }

TEST_ONLY=false
if [[ "${1:-}" == "--test" ]]; then
    TEST_ONLY=true
fi

# --- Check root ---
if [[ $EUID -ne 0 ]]; then
    log_error "This script must be run as root (or with sudo)"
    exit 1
fi

# --- Check Nginx is installed ---
if ! command -v nginx &>/dev/null; then
    log_error "Nginx is not installed or not in PATH"
    exit 1
fi

echo "============================================"
echo "  Nginx Configuration Test & Reload"
echo "============================================"
echo ""

# --- Step 1: Show current status ---
log_step "Current Nginx status:"
if systemctl is-active --quiet nginx; then
    echo -e "  Status: ${GREEN}Running${NC}"
    echo "  PID:    $(cat /run/nginx.pid 2>/dev/null || echo 'unknown')"
    echo "  Uptime: $(systemctl show nginx --property=ActiveEnterTimestamp --value 2>/dev/null || echo 'unknown')"
else
    echo -e "  Status: ${RED}Stopped${NC}"
fi
echo ""

# --- Step 2: Test config syntax ---
log_step "Testing configuration syntax..."
echo ""

if nginx -t 2>&1; then
    echo ""
    log_info "Configuration syntax is OK"
else
    echo ""
    log_error "Configuration has syntax errors!"
    log_error "Fix the errors above before reloading."
    echo ""

    # Show the problematic file(s) with context
    log_step "Running detailed test with error output..."
    nginx -T 2>&1 | tail -20 || true

    exit 1
fi

echo ""

# --- Step 3: Check for common issues ---
log_step "Checking for common issues..."

# Check if sites-enabled has any configs
SITES_ENABLED="/etc/nginx/sites-enabled"
if [[ -d "$SITES_ENABLED" ]]; then
    SITE_COUNT=$(find "$SITES_ENABLED" -type f -o -type l | wc -l)
    echo "  Sites enabled: ${SITE_COUNT}"
    if [[ $SITE_COUNT -eq 0 ]]; then
        log_warn "No sites enabled in ${SITES_ENABLED}/"
    fi
fi

# Check SSL certificate expiry for each site
for cert_dir in /etc/letsencrypt/live/*/; do
    if [[ -f "${cert_dir}fullchain.pem" ]]; then
        domain=$(basename "$cert_dir")
        expiry=$(openssl x509 -enddate -noout -in "${cert_dir}fullchain.pem" 2>/dev/null | cut -d= -f2)
        expiry_epoch=$(date -d "$expiry" +%s 2>/dev/null || echo 0)
        now_epoch=$(date +%s)
        days_left=$(( (expiry_epoch - now_epoch) / 86400 ))

        if [[ $days_left -lt 7 ]]; then
            log_error "  SSL cert for ${domain} expires in ${days_left} days!"
        elif [[ $days_left -lt 30 ]]; then
            log_warn "  SSL cert for ${domain} expires in ${days_left} days"
        else
            echo "  SSL cert for ${domain}: OK (${days_left} days remaining)"
        fi
    fi
done

# Check if cache directories exist
for cache_dir in /var/cache/nginx/app /var/cache/nginx/static /var/cache/nginx/api /var/cache/nginx/wordpress; do
    if [[ ! -d "$cache_dir" ]]; then
        log_warn "Cache directory missing: ${cache_dir} (creating...)"
        mkdir -p "$cache_dir"
        chown www-data:www-data "$cache_dir"
    fi
done

echo ""

# --- Step 4: Reload (unless test-only mode) ---
if [[ "$TEST_ONLY" == true ]]; then
    log_info "Test-only mode — skipping reload."
    exit 0
fi

log_step "Reloading Nginx..."
if systemctl reload nginx; then
    log_info "Nginx reloaded successfully!"
    echo ""
    echo "  New worker processes are now serving traffic."
    echo "  Old worker processes will finish existing connections and exit."
else
    log_error "Reload failed. Check systemctl status nginx for details."
    exit 1
fi

echo ""
echo "============================================"
echo "  Done!"
echo "============================================"
