# Starter Templates Pro — Free Sample Pack

Thank you for downloading the free sample pack!

## What's Included

- **Coming Soon Template** — Pre-launch coming soon page with countdown timer, email signup, and social links....
- **Portfolio Template** — Professional portfolio website template with responsive design, dark mode, and smooth animations....

## Get the Full Collection

This sample includes a preview of what's available in Starter Templates Pro.
The full store has 10 products covering 10 Premium Website Templates. Zero Dependencies. One Price..

Visit: https://inity13.github.io/starter-templates-pro/

Use code **COMMUNITY** for 15% off your first purchase.
Students/bootcamp grads: use code **STUDENT** for 50% off.

## Contact

Questions? Reach out at megafolder122122@hotmail.com
