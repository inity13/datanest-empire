# Coming Soon Template

A pre-launch coming soon page template with countdown timer, email signup, and progress bar. Build anticipation before your product or service launches.

## Price

$15 -- one-time purchase, lifetime updates.

## Features

- **Fully responsive** -- Mobile-first design with tablet and desktop breakpoints
- **Dark/Light mode** -- Built-in theme toggle, persists to localStorage
- **No dependencies** -- Pure HTML, CSS, and vanilla JavaScript
- **Under 400KB** -- Lightweight and fast-loading
- **Scroll animations** -- Reveal-on-scroll using Intersection Observer
- **SEO ready** -- Semantic HTML5, meta tags, Open Graph tags
- **Accessible** -- ARIA labels, keyboard navigation, proper contrast ratios
- **CSS custom properties** -- Easy color, font, and spacing customization

## Sections

- Hero with product name and tagline
- Countdown timer (days, hours, minutes, seconds)
- Email signup form for early access
- Progress bar showing development status
- Feature preview teasers
- Social media links
- Footer with brand info

## What's Included

```
coming-soon-template/
├── index.html
├── style.css
├── script.js
└── assets/
```

## Installation

1. Download and unzip the template
2. Open `index.html` in your browser
3. Set your launch date in `script.js`
4. Edit the HTML content with your product details
5. Deploy to any static hosting provider

```bash
# Open locally
open index.html

# Or use a local server
python -m http.server 8000
```

## Customization

### Launch Date

Edit the countdown target in `script.js`:

```js
const launchDate = new Date('2026-06-01T00:00:00');
```

### Colors

Edit CSS custom properties in `style.css`:

```css
:root {
  --color-primary: #2563eb;
  --color-primary-light: #3b82f6;
  --color-primary-dark: #1d4ed8;
  --color-accent: #f59e0b;
}
```

### Fonts

Replace the Google Fonts `<link>` in `index.html` and update:

```css
:root {
  --font-sans: 'Your Font', sans-serif;
  --font-heading: 'Your Heading Font', sans-serif;
}
```

### Images

Replace CSS gradient placeholders with your images:

```html
<img src="assets/preview.jpg" alt="Description" loading="lazy">
```

### Dark Mode

Customize dark theme colors in the `[data-theme="dark"]` section of `style.css`.

## Deployment

Works with any static hosting provider:

| Provider | Cost |
|----------|------|
| GitHub Pages | Free |
| Netlify | Free |
| Vercel | Free |
| Cloudflare Pages | Free |

## Browser Support

- Chrome 80+
- Firefox 78+
- Safari 14+
- Edge 80+

## License

MIT License -- free for personal and commercial use.

## Support

For questions or issues, email **megafolder122122@hotmail.com**.
