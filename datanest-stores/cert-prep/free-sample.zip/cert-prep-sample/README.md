# Certification Prep Pro — Free Sample Pack

Thank you for downloading the free sample pack!

## What's Included

- **Azure Fundamentals (AZ-900) Guide** — Complete AZ-900 study material covering cloud concepts, Azure services, security, pricing, and SLA fundamentals with pra...
- **Docker DCA Certification Prep** — Docker Certified Associate study guide with image management, networking, orchestration, security, and storage exercises...

## Get the Full Collection

This sample includes a preview of what's available in Certification Prep Pro.
The full store has 11 products covering Written study guides, lab workbooks, and cheatsheets for cloud and DevOps certifications.

Visit: https://inity13.github.io/cert-prep-pro/

Use code **COMMUNITY** for 15% off your first purchase.
Students/bootcamp grads: use code **STUDENT** for 50% off.

## Contact

Questions? Reach out at megafolder122122@hotmail.com
