# Azure Fundamentals (AZ-900) Guide

Complete AZ-900 study material covering cloud concepts, Azure services, security, pricing, and SLA fundamentals with practice questions.

## Contents

- `config.example.yaml`
- `docs/checklists/pre-deployment.md`
- `docs/overview.md`
- `docs/patterns/pattern-01-standard.md`
- `templates/config.yaml`

## Quick Start

1. Extract the ZIP archive
2. Review the README and documentation
3. Customize configuration files for your environment
4. Follow the setup guide for your specific use case

## Requirements

- Python 3.10+ (for Python scripts)
- Relevant CLI tools for your platform
- Access to your target environment

## License

MIT License — see LICENSE file.

## Support

Questions or issues? Email megafolder122122@hotmail.com

---
Part of [Cert Prep](https://inity13.github.io/cert-prep-pro/)
