"""LLM Prompt Engineering Kit"""
__version__ = "1.0.0"
