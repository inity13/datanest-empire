"""Utility functions for LLM Prompt Engineering Kit."""
from typing import Any, Dict, List, Optional, Union
from pathlib import Path
import json
import hashlib
import logging

logger = logging.getLogger(__name__)


def load_json(path: Union[str, Path]) -> Dict[str, Any]:
    """Load and parse a JSON file."""
    with open(path) as f:
        return json.load(f)


def save_json(data: Any, path: Union[str, Path], indent: int = 2) -> None:
    """Save data as formatted JSON."""
    with open(path, "w") as f:
        json.dump(data, f, indent=indent, default=str)


def checksum(path: Union[str, Path], algorithm: str = "sha256") -> str:
    """Calculate file checksum."""
    h = hashlib.new(algorithm)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_dir(path: Union[str, Path]) -> Path:
    """Create directory if it doesn't exist."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def flatten_dict(d: Dict, parent_key: str = "", sep: str = ".") -> Dict[str, Any]:
    """Flatten a nested dictionary."""
    items: List = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def validate_required_fields(data: Dict[str, Any], required: List[str]) -> List[str]:
    """Check for missing required fields."""
    return [f for f in required if f not in data or data[f] is None]
